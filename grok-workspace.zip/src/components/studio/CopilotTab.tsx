import { Mic, Send, Square, Volume2 } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { t } from "@/lib/studio/i18n";
import { askPilot, listenRoute, speakRoute, useStudio } from "@/lib/studio/store";
import { Button, TextField } from "./ui";

interface SpeechRec {
  lang: string;
  interimResults: boolean;
  onresult: ((event: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void) | null;
  onend: (() => void) | null;
  onerror: (() => void) | null;
  start: () => void;
  stop: () => void;
}

function recognition(): (new () => SpeechRec) | null {
  const w = window as unknown as {
    SpeechRecognition?: new () => SpeechRec;
    webkitSpeechRecognition?: new () => SpeechRec;
  };
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
}

export function CopilotTab() {
  const studio = useStudio();
  const copy = t(studio.lang);
  const [text, setText] = useState("");
  const [listening, setListening] = useState(false);
  const [voiceLine, setVoiceLine] = useState("");
  const scroller = useRef<HTMLDivElement>(null);
  const recRef = useRef<SpeechRec | null>(null);

  useEffect(() => {
    const node = scroller.current;
    if (node) node.scrollTop = node.scrollHeight;
  }, [studio.messages, studio.thinking]);

  useEffect(() => {
    return () => recRef.current?.stop();
  }, []);

  const send = (value: string) => {
    const next = value.trim();
    if (!next) return;
    setText("");
    askPilot(next);
  };

  const toggleMic = () => {
    setVoiceLine(listenRoute());
    if (listening) {
      recRef.current?.stop();
      setListening(false);
      return;
    }
    const Ctor = recognition();
    if (!Ctor) {
      askPilot(studio.lang === "hi" ? "इस ब्राउज़र में माइक नहीं मिला।" : "This browser has no speech recognition.");
      return;
    }
    const rec = new Ctor();
    rec.lang = studio.lang === "hi" ? "hi-IN" : "en-US";
    rec.interimResults = false;
    rec.onresult = (event) => {
      const said = event.results[0]?.[0]?.transcript ?? "";
      if (said) send(said);
    };
    rec.onend = () => setListening(false);
    rec.onerror = () => setListening(false);
    recRef.current = rec;
    rec.start();
    setListening(true);
  };

  const speak = (line: string) => {
    setVoiceLine(speakRoute());
    window.speechSynthesis?.cancel();
    const utter = new SpeechSynthesisUtterance(line);
    utter.lang = studio.lang === "hi" ? "hi-IN" : "en-US";
    window.speechSynthesis?.speak(utter);
  };

  return (
    <div className="grid gap-3">
      <div ref={scroller} className="grid max-h-[28rem] gap-2 overflow-y-auto pr-1">
        {studio.messages.map((message) => (
          <article
            key={message.id}
            className={`rounded-lg px-3 py-3 text-sm ${message.role === "user" ? "ml-8 bg-surface-2" : "mr-6 glass"}`}
          >
            <p className="whitespace-pre-wrap">{message.text}</p>
            {message.role === "pilot" ? (
              <button type="button" className="mt-2 inline-flex min-h-11 items-center gap-2 text-xs text-cyan" onClick={() => speak(message.text)}>
                <Volume2 className="size-4" aria-hidden="true" />
                {copy.speak}
              </button>
            ) : null}
          </article>
        ))}
        {studio.thinking ? <p className="text-sm text-cyan">{studio.routingLine}</p> : null}
      </div>
      {voiceLine ? <p className="text-xs text-subtle">{voiceLine}</p> : null}
      {listening ? <p className="text-sm text-cyan">{copy.listening}</p> : null}
      <form
        className="grid grid-cols-[auto_1fr_auto] gap-2"
        onSubmit={(event) => {
          event.preventDefault();
          send(text);
        }}
      >
        <Button type="button" variant={listening ? "violet" : "quiet"} onClick={toggleMic} aria-pressed={listening}>
          {listening ? <Square className="size-4" aria-hidden="true" /> : <Mic className="size-4" aria-hidden="true" />}
          <span className="sr-only">{listening ? copy.stopMic : copy.mic}</span>
        </Button>
        <TextField
          value={text}
          onChange={(event) => setText(event.target.value)}
          placeholder={copy.typePilot}
          aria-label={copy.typePilot}
        />
        <Button type="submit" variant="primary" aria-label={copy.send}>
          <Send className="size-4" aria-hidden="true" />
        </Button>
      </form>
    </div>
  );
}
