import { cva, type VariantProps } from "class-variance-authority";
import type { ButtonHTMLAttributes, InputHTMLAttributes, ReactNode, SelectHTMLAttributes, TextareaHTMLAttributes } from "react";

const buttonStyles = cva(
  "inline-flex items-center justify-center gap-2 rounded-md px-4 font-semibold min-h-11 disabled:opacity-40",
  {
    variants: {
      variant: {
        primary: "bg-cyan text-ink glow-cyan",
        quiet: "glass text-fg",
        danger: "glass text-danger",
        violet: "bg-violet text-ink glow-violet",
      },
    },
    defaultVariants: { variant: "quiet" },
  },
);

export function Button({
  variant,
  className,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & VariantProps<typeof buttonStyles>) {
  return <button className={buttonStyles({ variant, className })} {...props} />;
}

export function TextArea(props: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <textarea
      {...props}
      className={`w-full rounded-lg border border-line bg-bg-elev px-3 py-3 text-base text-fg placeholder:text-subtle ${props.className ?? ""}`}
    />
  );
}

export function TextField(props: InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...props}
      className={`w-full rounded-md border border-line bg-bg-elev px-3 text-base text-fg min-h-11 placeholder:text-subtle ${props.className ?? ""}`}
    />
  );
}

export function SelectField(props: SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select
      {...props}
      className={`w-full rounded-md border border-line bg-bg-elev px-3 text-base text-fg min-h-11 ${props.className ?? ""}`}
    />
  );
}

export function Panel({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <section className={`glass rounded-xl p-4 ${className}`}>{children}</section>;
}
