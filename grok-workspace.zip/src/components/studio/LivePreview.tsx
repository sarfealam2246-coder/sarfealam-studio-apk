import { useEffect, useRef, type PointerEvent as ReactPointerEvent } from "react";
import { dealHand, rankValue } from "@/lib/studio/blueprint";
import { skillLabel, t } from "@/lib/studio/i18n";
import { patchSandbox } from "@/lib/studio/store";
import type { AdminState, Job, Lang, SandboxItem } from "@/lib/studio/types";

declare global {
  interface Window {
    __controlsTest?: {
      getYaw: () => number;
      getSpeed: () => number;
      setSteer?: (v: number) => void;
      setKeys?: (codes: string[]) => void;
    };
  }
}

function cssColor(name: string, fallback: string): string {
  const value = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  return value || fallback;
}

function useVehicleSim({
  enabled,
  onAction,
}: {
  enabled: boolean;
  onAction: (text: string) => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const held = useRef(new Set<string>());
  const gas = useRef(false);
  const brake = useRef(false);
  const steerBtn = useRef(0);
  const yaw = useRef(0);
  const speed = useRef(0);
  const offset = useRef(0);
  const enabledRef = useRef(enabled);
  enabledRef.current = enabled;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    let frame = 0;
    let last = performance.now();
    let scroll = 0;

    const probe: NonNullable<Window["__controlsTest"]> = {
      getYaw: () => yaw.current,
      getSpeed: () => speed.current,
      setSteer: (v: number) => {
        steerBtn.current = Math.max(-1, Math.min(1, v));
      },
      setKeys: (codes: string[]) => {
        held.current = new Set(codes);
      },
    };
    window.__controlsTest = probe;

    const interesting = new Set(["KeyA", "KeyD", "KeyW", "KeyS", "ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown"]);
    const onKey = (event: KeyboardEvent, down: boolean) => {
      const target = event.target as HTMLElement | null;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable)) return;
      if (!interesting.has(event.code)) return;
      event.preventDefault();
      if (down) held.current.add(event.code);
      else held.current.delete(event.code);
    };
    const down = (event: KeyboardEvent) => onKey(event, true);
    const up = (event: KeyboardEvent) => onKey(event, false);
    const clear = () => {
      held.current.clear();
      gas.current = false;
      brake.current = false;
      steerBtn.current = 0;
    };
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    window.addEventListener("blur", clear);

    const loop = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      if (enabledRef.current) {
        let steer = steerBtn.current;
        if (held.current.has("KeyA") || held.current.has("ArrowLeft")) steer += 1;
        if (held.current.has("KeyD") || held.current.has("ArrowRight")) steer -= 1;
        steer = Math.max(-1, Math.min(1, steer));
        const thrusting = held.current.has("KeyW") || held.current.has("ArrowUp") || gas.current;
        const braking = held.current.has("KeyS") || held.current.has("ArrowDown") || brake.current;
        if (thrusting) speed.current = Math.min(220, speed.current + 160 * dt);
        else speed.current = Math.max(0, speed.current - (braking ? 240 : 50) * dt);
        const moving = speed.current > 8;
        yaw.current += steer * 2.4 * (moving ? 1 : 0.2) * dt;
        offset.current += -Math.sin(yaw.current) * speed.current * dt * 0.85;
        offset.current = Math.max(-90, Math.min(90, offset.current));
        scroll += speed.current * dt;
      }
      paint(ctx, canvas, yaw.current, offset.current, scroll, speed.current);
      frame = requestAnimationFrame(loop);
    };
    frame = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
      window.removeEventListener("blur", clear);
      if (window.__controlsTest === probe) delete window.__controlsTest;
    };
  }, []);

  const hold = (which: "left" | "right" | "gas" | "brake", text: string) => ({
    onPointerDown: (event: ReactPointerEvent<HTMLButtonElement>) => {
      event.currentTarget.setPointerCapture(event.pointerId);
      if (which === "left") steerBtn.current = 1;
      if (which === "right") steerBtn.current = -1;
      if (which === "gas") gas.current = true;
      if (which === "brake") brake.current = true;
      onAction(text);
    },
    onPointerUp: () => {
      if (which === "left" || which === "right") steerBtn.current = 0;
      if (which === "gas") gas.current = false;
      if (which === "brake") brake.current = false;
    },
    onPointerCancel: () => {
      steerBtn.current = 0;
      gas.current = false;
      brake.current = false;
    },
  });

  return { canvasRef, hold };
}

function paint(
  ctx: CanvasRenderingContext2D,
  canvas: HTMLCanvasElement,
  yaw: number,
  offset: number,
  scroll: number,
  speed: number,
) {
  const dpr = Math.min(2, window.devicePixelRatio || 1);
  const width = canvas.clientWidth;
  const height = canvas.clientHeight;
  if (canvas.width !== Math.floor(width * dpr) || canvas.height !== Math.floor(height * dpr)) {
    canvas.width = Math.floor(width * dpr);
    canvas.height = Math.floor(height * dpr);
  }
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  const bg = cssColor("--color-bg", "#07090f");
  const cyan = cssColor("--color-cyan", "#3ee0ff");
  const violet = cssColor("--color-violet", "#b39bff");
  const fg = cssColor("--color-fg", "#e7eef8");
  const surface = cssColor("--color-surface", "#161a26");
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, width, height);
  const horizon = height * 0.38;
  ctx.fillStyle = surface;
  ctx.fillRect(0, 0, width, horizon);
  ctx.fillStyle = violet;
  ctx.globalAlpha = 0.35;
  ctx.fillRect(0, horizon - 2, width, 3);
  ctx.globalAlpha = 1;
  ctx.beginPath();
  ctx.moveTo(width * 0.5, horizon);
  ctx.lineTo(width * 0.08, height);
  ctx.lineTo(width * 0.92, height);
  ctx.closePath();
  ctx.fillStyle = cssColor("--color-bg-elev", "#10131c");
  ctx.fill();
  ctx.strokeStyle = cyan;
  ctx.globalAlpha = 0.7;
  ctx.stroke();
  ctx.globalAlpha = 1;
  ctx.strokeStyle = fg;
  ctx.globalAlpha = 0.45;
  ctx.setLineDash([10, 16]);
  ctx.lineDashOffset = -scroll;
  ctx.beginPath();
  ctx.moveTo(width * 0.5, horizon + 8);
  ctx.lineTo(width * 0.5 + offset * 0.2, height);
  ctx.stroke();
  ctx.setLineDash([]);
  ctx.globalAlpha = 1;

  const cx = width * 0.5 + offset;
  const cy = height * 0.78;
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(-yaw);
  ctx.fillStyle = cyan;
  ctx.beginPath();
  ctx.roundRect(-12, -18, 24, 36, 6);
  ctx.fill();
  ctx.fillStyle = violet;
  ctx.fillRect(-8, -8, 16, 12);
  ctx.fillStyle = bg;
  ctx.fillRect(-14, -6, 4, 8);
  ctx.fillRect(10, -6, 4, 8);
  ctx.fillRect(-14, 8, 4, 8);
  ctx.fillRect(10, 8, 4, 8);
  ctx.restore();

  ctx.fillStyle = fg;
  ctx.globalAlpha = 0.8;
  ctx.font = "600 12px Outfit, sans-serif";
  ctx.fillText(String(Math.round(speed)), 12, 20);
  ctx.globalAlpha = 1;
}

export function LivePreview({ job, lang, admin, notice }: { job: Job; lang: Lang; admin: AdminState; notice: string }) {
  const copy = t(lang);
  const stage = job.stage;
  const bp = job.blueprint;
  const box = job.sandbox;
  const interactive = stage >= 4 && (job.status === "assembling" || job.status === "ready" || job.status === "ok" || job.status === "export");

  return (
    <div className="overflow-hidden rounded-xl border border-line bg-bg-elev">
      <div className="flex items-center justify-between border-b border-line px-3 py-2">
        <p className="font-display text-base font-semibold tracking-tight">{bp.title}</p>
        <span className="text-xs font-medium text-cyan">{stage >= 5 ? copy.readyBadge : copy.assembling}</span>
      </div>
      {admin.banner && stage >= 1 ? (
        <p className="bg-violet px-3 py-2 text-sm font-medium text-ink">{admin.bannerText}</p>
      ) : null}
      {notice ? <p className="border-b border-line px-3 py-2 text-sm text-cyan">{notice}</p> : null}
      <div className="relative min-h-64 p-3">
        {stage < 2 ? <p className="text-sm text-muted">{bp.summary}</p> : null}
        {bp.template === "game" && stage >= 2 ? (
          <GameWorld lang={lang} interactive={interactive} lastAction={box.lastAction} />
        ) : null}
        {bp.template === "game" && stage < 2 ? <p className="text-sm text-muted">{bp.summary}</p> : null}
        {bp.template === "card" ? <CardTable lang={lang} job={job} interactive={interactive} stage={stage} /> : null}
        {bp.kind === "app" ? <AppWorld lang={lang} job={job} interactive={interactive} stage={stage} admin={admin} /> : null}
      </div>
      {stage >= 2 ? (
        <p className="border-t border-line px-3 py-2 text-xs text-subtle">
          {copy.skillsUsed}: {bp.skills.map((id) => skillLabel(id, lang)).join(" · ") || "—"}
        </p>
      ) : null}
    </div>
  );
}

function GameWorld({
  lang,
  interactive,
  lastAction,
}: {
  lang: Lang;
  interactive: boolean;
  lastAction: string;
}) {
  const copy = t(lang);
  const sim = useVehicleSim({
    enabled: interactive,
    onAction: (text) => patchSandbox({ lastAction: text }),
  });
  return (
    <div className="grid gap-3">
      <canvas ref={sim.canvasRef} className="h-56 w-full rounded-lg bg-bg" />
      {interactive ? (
        <div className="grid grid-cols-4 gap-2">
          <button type="button" className="min-h-11 rounded-md bg-surface text-fg" {...sim.hold("left", copy.left)}>
            {copy.left}
          </button>
          <button type="button" className="min-h-11 rounded-md bg-cyan text-ink" {...sim.hold("gas", copy.gas)}>
            {copy.gas}
          </button>
          <button type="button" className="min-h-11 rounded-md bg-surface text-fg" {...sim.hold("brake", copy.brake)}>
            {copy.brake}
          </button>
          <button type="button" className="min-h-11 rounded-md bg-surface text-fg" {...sim.hold("right", copy.right)}>
            {copy.right}
          </button>
        </div>
      ) : (
        <p className="text-sm text-muted">{copy.testLocked}</p>
      )}
      {lastAction ? (
        <p className="text-xs text-muted">
          {copy.lastInput}: {lastAction}
        </p>
      ) : null}
    </div>
  );
}

function CardTable({ lang, job, interactive, stage }: { lang: Lang; job: Job; interactive: boolean; stage: number }) {
  const copy = t(lang);
  const box = job.sandbox;
  const deal = () => {
    const hand = dealHand(`${job.id}-${Date.now()}`, 3);
    patchSandbox({ hand, pot: box.pot + 10, lastAction: copy.deal });
  };
  const draw = () => {
    const extra = dealHand(`${job.id}-draw-${box.hand.join("")}`, 1)[0] ?? "AS";
    const best = Math.max(...box.hand.map(rankValue), 0);
    const win = rankValue(extra) >= best;
    patchSandbox({
      hand: [...box.hand, extra].slice(-4),
      pot: Math.max(0, box.pot + (win ? 20 : -10)),
      lastAction: `${copy.draw} ${extra}`,
    });
  };
  return (
    <div className="grid gap-3">
      {stage >= 2 ? (
        <div className="rounded-lg border border-line bg-bg p-3">
          <p className="text-xs uppercase tracking-wide text-subtle">{copy.pot}</p>
          <p className="font-display text-2xl font-semibold tabular-nums text-cyan">{box.pot}</p>
          {stage >= 3 ? (
            <div className="mt-3 flex flex-wrap gap-2">
              {(box.hand.length > 0 ? box.hand : ["??", "??", "??"]).map((card, index) => (
                <span
                  key={`${card}-${index}`}
                  className={`grid h-16 w-12 place-items-center rounded-md border border-line bg-surface text-sm font-semibold ${card.endsWith("H") || card.endsWith("D") ? "text-danger" : "text-fg"}`}
                >
                  {stage >= 3 ? card : "·"}
                </span>
              ))}
            </div>
          ) : null}
        </div>
      ) : null}
      {interactive ? (
        <div className="grid grid-cols-2 gap-2">
          <button type="button" className="min-h-11 rounded-md bg-cyan text-ink font-semibold" onClick={deal}>
            {copy.deal}
          </button>
          <button type="button" className="min-h-11 rounded-md bg-surface text-fg" onClick={draw}>
            {copy.draw}
          </button>
        </div>
      ) : null}
      {box.lastAction ? (
        <p className="text-xs text-muted">
          {copy.lastInput}: {box.lastAction}
        </p>
      ) : null}
    </div>
  );
}

function AppWorld({
  lang,
  job,
  interactive,
  stage,
  admin,
}: {
  lang: Lang;
  job: Job;
  interactive: boolean;
  stage: number;
  admin: AdminState;
}) {
  const copy = t(lang);
  const bp = job.blueprint;
  const box = job.sandbox;
  const skills = bp.skills;
  if (skills.includes("otp") && !box.otpPassed) {
    return (
      <form
        className="grid gap-3"
        onSubmit={(event) => {
          event.preventDefault();
          if (!interactive) return;
          if (box.otpCode.trim() === "248163") patchSandbox({ otpPassed: true, lastAction: copy.otp });
          else patchSandbox({ lastAction: copy.demoCode });
        }}
      >
        <p className="font-medium">{copy.signIn}</p>
        <p className="text-sm text-muted">{copy.demoCode}</p>
        <input
          value={box.otpCode}
          onChange={(event) => patchSandbox({ otpCode: event.target.value })}
          placeholder={copy.codePh}
          className="min-h-11 rounded-md border border-line bg-bg px-3"
          inputMode="numeric"
        />
        {interactive ? (
          <button type="submit" className="min-h-11 rounded-md bg-cyan font-semibold text-ink">
            {copy.otp}
          </button>
        ) : null}
      </form>
    );
  }

  const filtered = box.items.filter((item) => {
    const q = box.query.trim().toLowerCase();
    if (!q) return true;
    return `${item.title} ${item.note}`.toLowerCase().includes(q);
  });

  const addItem = () => {
    const title = box.draftTitle.trim();
    if (!title) return;
    const amount = Number(box.draftAmount) || 0;
    const item: SandboxItem = { id: `n-${Date.now()}`, title, note: "new", amount };
    const items = [item, ...box.items];
    patchSandbox({
      items,
      balance: box.balance + amount,
      draftTitle: "",
      draftAmount: "",
      lastAction: title,
      cart: bp.template === "shop" ? box.cart + 1 : box.cart,
    });
  };

  return (
    <div className="grid gap-3">
      {stage >= 3 && box.tab === "home" ? <HomeBody lang={lang} job={job} filtered={filtered} /> : null}
      {stage >= 3 && box.tab === "list" ? <ListBody items={filtered} /> : null}
      {stage >= 3 && box.tab === "map" ? <MapBody lang={lang} /> : null}
      {stage >= 3 && box.tab === "wallet" ? (
        <div>
          <p className="text-xs text-subtle">{copy.balance}</p>
          <p className="font-display text-3xl font-semibold tabular-nums text-cyan">{box.balance}</p>
        </div>
      ) : null}
      {stage >= 3 && box.tab === "profile" ? (
        <div className="grid gap-2">
          <p className="font-medium">{copy.profile}</p>
          <p className="text-sm text-muted">{admin.vipNote}</p>
          {skills.includes("vip") && !box.vipOpen ? (
            <button
              type="button"
              className="min-h-11 rounded-md bg-violet font-semibold text-ink"
              disabled={!interactive}
              onClick={() => patchSandbox({ vipOpen: true, lastAction: copy.unlock })}
            >
              {copy.unlock}
            </button>
          ) : null}
          {box.vipOpen ? <p className="text-sm text-ok">{copy.unlock}</p> : null}
        </div>
      ) : null}
      {interactive && skills.includes("search") ? (
        <input
          value={box.query}
          onChange={(event) => patchSandbox({ query: event.target.value })}
          placeholder={copy.search}
          className="min-h-11 rounded-md border border-line bg-bg px-3"
        />
      ) : null}
      {interactive && (skills.includes("lists") || bp.template === "bank" || bp.template === "shop" || bp.template === "delivery") ? (
        <div className="grid grid-cols-5 gap-2">
          <input
            value={box.draftTitle}
            onChange={(event) => patchSandbox({ draftTitle: event.target.value })}
            placeholder={copy.name}
            className="col-span-2 min-h-11 rounded-md border border-line bg-bg px-3"
          />
          <input
            value={box.draftAmount}
            onChange={(event) => patchSandbox({ draftAmount: event.target.value })}
            placeholder={copy.amount}
            inputMode="decimal"
            className="col-span-2 min-h-11 rounded-md border border-line bg-bg px-3"
          />
          <button type="button" className="min-h-11 rounded-md bg-cyan font-semibold text-ink" onClick={addItem}>
            {bp.template === "shop" ? "+" : bp.template === "delivery" ? copy.book : bp.template === "fantasy" ? copy.reveal : copy.add}
          </button>
        </div>
      ) : null}
      {interactive && bp.template === "fantasy" ? (
        <button
          type="button"
          className="min-h-11 rounded-md bg-violet font-semibold text-ink"
          onClick={() => patchSandbox({ revealed: !box.revealed, lastAction: copy.reveal })}
        >
          {copy.reveal}
        </button>
      ) : null}
      {box.revealed ? <p className="text-sm text-cyan">{bp.title}</p> : null}
      {stage >= 4 && bp.screens.length > 1 ? (
        <div className="grid grid-cols-4 gap-1 rounded-lg bg-bg p-1">
          {bp.screens.slice(0, 4).map((screen) => (
            <button
              key={screen.id}
              type="button"
              className={`min-h-11 rounded-md text-xs font-medium ${box.tab === screen.id ? "bg-cyan text-ink" : "text-muted"}`}
              onClick={() => patchSandbox({ tab: screen.id, lastAction: screen.label })}
            >
              {screen.label}
            </button>
          ))}
        </div>
      ) : null}
      {box.lastAction ? (
        <p className="text-xs text-muted">
          {copy.lastInput}: {box.lastAction}
        </p>
      ) : null}
    </div>
  );
}

function HomeBody({ lang, job, filtered }: { lang: Lang; job: Job; filtered: SandboxItem[] }) {
  const copy = t(lang);
  return (
    <div className="grid gap-2">
      <p className="text-sm text-muted">{job.blueprint.summary}</p>
      {job.blueprint.template === "bank" || job.blueprint.template === "khata" ? (
        <p className="font-display text-3xl font-semibold tabular-nums text-cyan">{job.sandbox.balance}</p>
      ) : null}
      {filtered.slice(0, 4).map((item) => (
        <div key={item.id} className="flex items-center justify-between rounded-md bg-surface px-3 py-2">
          <span className="text-sm">{item.title}</span>
          <span className="text-xs tabular-nums text-muted">{item.amount}</span>
        </div>
      ))}
      {job.blueprint.template === "shop" ? (
        <p className="text-xs text-muted">
          {copy.cart}: {job.sandbox.cart}
        </p>
      ) : null}
    </div>
  );
}

function ListBody({ items }: { items: SandboxItem[] }) {
  return (
    <div className="grid gap-2">
      {items.map((item) => (
        <div key={item.id} className="rounded-md bg-surface px-3 py-2">
          <p className="text-sm font-medium">{item.title}</p>
          <p className="text-xs text-muted">
            {item.note} · <span className="tabular-nums">{item.amount}</span>
          </p>
        </div>
      ))}
    </div>
  );
}

function MapBody({ lang }: { lang: Lang }) {
  const copy = t(lang);
  const zones = ["A", "B", "C", "D"];
  return (
    <div>
      <p className="mb-2 text-xs text-subtle">{copy.zone}</p>
      <div className="grid grid-cols-2 gap-2">
        {zones.map((zone) => (
          <div key={zone} className="grid h-16 place-items-center rounded-md border border-line text-sm text-cyan">
            {zone}
          </div>
        ))}
      </div>
    </div>
  );
}
