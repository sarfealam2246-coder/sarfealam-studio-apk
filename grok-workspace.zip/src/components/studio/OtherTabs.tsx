import { useState } from "react";
import { parseFirebaseConfig } from "@/lib/studio/firebase";
import { SKILL_ORDER, skillBlurb, skillLabel, statusLabel, t } from "@/lib/studio/i18n";
import { detectProvider } from "@/lib/studio/routing";
import {
  clearFirebase,
  clearKey,
  patchAdmin,
  saveFirebase,
  saveKey,
  saveToken,
  saveVoice,
  selectJob,
  sendNotification,
  setSkill,
  useStudio,
} from "@/lib/studio/store";
import type { FirebaseSlot, KeyTag } from "@/lib/studio/types";
import { Button, Panel, SelectField, TextArea, TextField } from "./ui";

const TAGS: KeyTag[] = ["", "General", "Code", "Fast", "Vision", "Primary", "Fallback"];

export function VaultTab() {
  const studio = useStudio();
  const copy = t(studio.lang);
  return (
    <div className="grid gap-3">
      <p className="text-sm text-muted">{studio.syncNote === "synced" ? copy.syncOn : studio.syncNote === "error" ? copy.syncErr : copy.syncLocal}</p>
      {studio.jobs.length === 0 ? <p className="text-sm">{copy.emptyVault}</p> : null}
      {studio.jobs.map((job) => (
        <button
          key={job.id}
          type="button"
          className="glass rounded-lg p-4 text-left"
          onClick={() => selectJob(job.id)}
        >
          <span className="block font-medium">{job.blueprint.title}</span>
          <span className="mt-1 flex flex-wrap gap-2 text-xs text-muted">
            <span>{job.blueprint.kind === "game" ? copy.kindGame : copy.kindApp}</span>
            <span>{new Date(job.createdAt).toLocaleString()}</span>
            <span className="text-cyan">{statusLabel(job.status, studio.lang)}</span>
          </span>
        </button>
      ))}
    </div>
  );
}

export function AdminTab() {
  const studio = useStudio();
  const copy = t(studio.lang);
  const job = studio.jobs.find((item) => item.id === studio.activeJobId) ?? null;
  const admin = job ? studio.admins[job.id] : null;
  const [note, setNote] = useState("Your build is ready to test.");
  if (!job || !admin) return <p className="text-sm text-muted">{copy.noJob}</p>;
  return (
    <div className="grid gap-4">
      <p className="text-sm text-muted">{copy.adminNote}</p>
      <p className="font-medium">{job.blueprint.title}</p>
      <Panel className="grid gap-3">
        <label className="flex min-h-11 items-center justify-between gap-3">
          <span>{copy.banner}</span>
          <input
            type="checkbox"
            checked={admin.banner}
            onChange={(event) => patchAdmin({ banner: event.target.checked })}
            className="size-5"
          />
        </label>
        <TextField value={admin.bannerText} onChange={(event) => patchAdmin({ bannerText: event.target.value })} aria-label={copy.banner} />
        <TextArea rows={3} value={admin.vipNote} aria-label={copy.vip} onChange={(event) => patchAdmin({ vipNote: event.target.value })} />
        <TextField
          value={admin.apkLink}
          placeholder={copy.apk}
          aria-label={copy.apk}
          onChange={(event) => patchAdmin({ apkLink: event.target.value })}
        />
        {admin.apkLink ? <p className="truncate text-xs text-cyan">{admin.apkLink}</p> : null}
        <TextField value={note} onChange={(event) => setNote(event.target.value)} aria-label={copy.sendNote} />
        <Button type="button" variant="primary" onClick={() => sendNotification(note)}>
          {copy.sendNote}
        </Button>
      </Panel>
    </div>
  );
}

export function SkillsTab() {
  const studio = useStudio();
  const copy = t(studio.lang);
  return (
    <div className="grid gap-3">
      <p className="text-sm text-muted">{copy.skillsLead}</p>
      {SKILL_ORDER.map((id) => (
        <label key={id} className="glass flex min-h-11 items-center justify-between gap-3 rounded-lg px-3 py-3">
          <span>
            <span className="block text-sm font-medium">{skillLabel(id, studio.lang)}</span>
            <span className="block text-xs text-subtle">{id === "survivor" ? copy.survivorNote : skillBlurb(id, studio.lang)}</span>
          </span>
          <input
            type="checkbox"
            checked={studio.skills[id]}
            onChange={(event) => setSkill(id, event.target.checked)}
            className="size-5 shrink-0"
          />
        </label>
      ))}
    </div>
  );
}

export function SecretsTab() {
  const studio = useStudio();
  const copy = t(studio.lang);
  return (
    <div className="grid gap-4">
      <p className="text-sm text-muted">{copy.secretsHelp}</p>
      {studio.secrets.keys.map((key, index) => (
        <SecretRow
          key={key.id}
          label={`Key ${index + 1}`}
          value={key.value}
          tag={key.tag}
          onSave={(value, tag) => saveKey(index, value, tag)}
          onDelete={() => clearKey(index)}
        />
      ))}
      <TokenRow label={copy.token1} value={studio.secrets.tokens[0]} onSave={(value) => saveToken(0, value)} onDelete={() => saveToken(0, "")} />
      <TokenRow label={copy.token2} value={studio.secrets.tokens[1]} onSave={(value) => saveToken(1, value)} onDelete={() => saveToken(1, "")} />
      <TokenRow label={copy.voice} value={studio.secrets.voice} onSave={saveVoice} onDelete={() => saveVoice("")} />
      <FirebaseEditor which="studioFb" label={copy.studioFb} slot={studio.secrets.studioFb} />
      <FirebaseEditor which="appsFb" label={copy.appsFb} slot={studio.secrets.appsFb} />
    </div>
  );
}

function mask(value: string): string {
  if (!value) return "";
  if (value.length <= 4) return "••••";
  return `•••• ${value.slice(-4)}`;
}

function SecretRow({
  label,
  value,
  tag,
  onSave,
  onDelete,
}: {
  label: string;
  value: string;
  tag: KeyTag;
  onSave: (value: string, tag: KeyTag) => void;
  onDelete: () => void;
}) {
  const studio = useStudio();
  const copy = t(studio.lang);
  const [editing, setEditing] = useState(!value);
  const [draft, setDraft] = useState(value);
  const [draftTag, setDraftTag] = useState<KeyTag>(tag);
  const provider = detectProvider(value);
  if (!editing && value) {
    return (
      <Panel className="grid gap-2">
        <div className="flex items-center justify-between gap-2">
          <p className="font-medium">{label}</p>
          <p className="text-sm tabular-nums text-muted">{mask(value)}</p>
        </div>
        <p className="text-xs text-subtle">
          {tag || copy.none}
          {provider ? ` · ${copy.detected} ${provider}` : ` · ${copy.unrecognized}`}
        </p>
        <div className="grid grid-cols-2 gap-2">
          <Button
            type="button"
            onClick={() => {
              setDraft(value);
              setDraftTag(tag);
              setEditing(true);
            }}
          >
            {copy.edit}
          </Button>
          <Button type="button" variant="danger" onClick={onDelete}>
            {copy.del}
          </Button>
        </div>
      </Panel>
    );
  }
  return (
    <Panel className="grid gap-2">
      <p className="font-medium">{label}</p>
      <TextField value={draft} onChange={(event) => setDraft(event.target.value)} autoComplete="off" spellCheck={false} aria-label={label} />
      <SelectField value={draftTag} aria-label={copy.keyTag} onChange={(event) => setDraftTag(event.target.value as KeyTag)}>
        {TAGS.map((item) => (
          <option key={item || "none"} value={item}>
            {item || copy.keyTag}
          </option>
        ))}
      </SelectField>
      <Button
        type="button"
        variant="primary"
        onClick={() => {
          onSave(draft, draftTag);
          setEditing(false);
        }}
      >
        {copy.save}
      </Button>
    </Panel>
  );
}

function TokenRow({
  label,
  value,
  onSave,
  onDelete,
}: {
  label: string;
  value: string;
  onSave: (value: string) => void;
  onDelete: () => void;
}) {
  const studio = useStudio();
  const copy = t(studio.lang);
  const [editing, setEditing] = useState(!value);
  const [draft, setDraft] = useState(value);
  if (!editing && value) {
    return (
      <Panel className="grid gap-2">
        <div className="flex items-center justify-between gap-2">
          <p className="font-medium">{label}</p>
          <p className="text-sm text-muted">{mask(value)}</p>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <Button
            type="button"
            onClick={() => {
              setDraft(value);
              setEditing(true);
            }}
          >
            {copy.edit}
          </Button>
          <Button type="button" variant="danger" onClick={onDelete}>
            {copy.del}
          </Button>
        </div>
      </Panel>
    );
  }
  return (
    <Panel className="grid gap-2">
      <p className="font-medium">{label}</p>
      {!value ? <p className="text-xs text-subtle">{copy.emptySlot}</p> : null}
      <TextField value={draft} onChange={(event) => setDraft(event.target.value)} autoComplete="off" spellCheck={false} aria-label={label} />
      <Button
        type="button"
        variant="primary"
        onClick={() => {
          onSave(draft);
          setEditing(Boolean(draft.trim()) === false);
        }}
      >
        {copy.save}
      </Button>
    </Panel>
  );
}

function FirebaseEditor({ which, label, slot }: { which: "studioFb" | "appsFb"; label: string; slot: FirebaseSlot }) {
  const studio = useStudio();
  const copy = t(studio.lang);
  const [editing, setEditing] = useState(!slot.url && !slot.key);
  const [url, setUrl] = useState(slot.url);
  const [key, setKey] = useState(slot.key);
  const [json, setJson] = useState("");
  const saved = Boolean(slot.url || slot.key);
  return (
    <Panel className="grid gap-2">
      <p className="font-medium">{label}</p>
      {!editing && saved ? (
        <>
          <p className="truncate text-xs text-muted">{slot.url}</p>
          <p className="text-sm text-subtle">{mask(slot.key)}</p>
          <div className="grid grid-cols-2 gap-2">
            <Button
              type="button"
              onClick={() => {
                setUrl(slot.url);
                setKey(slot.key);
                setEditing(true);
              }}
            >
              {copy.edit}
            </Button>
            <Button type="button" variant="danger" onClick={() => clearFirebase(which)}>
              {copy.del}
            </Button>
          </div>
        </>
      ) : (
        <>
          <TextField value={url} onChange={(event) => setUrl(event.target.value)} placeholder={copy.url} aria-label={copy.url} />
          <TextField value={key} onChange={(event) => setKey(event.target.value)} placeholder={copy.fbKey} aria-label={copy.fbKey} autoComplete="off" />
          <TextArea rows={3} value={json} placeholder={copy.pasteJson} aria-label={copy.pasteJson} onChange={(event) => setJson(event.target.value)} />
          <Button
            type="button"
            onClick={() => {
              const parsed = parseFirebaseConfig(json);
              if (!parsed) return;
              if (parsed.url) setUrl(parsed.url);
              if (parsed.key) setKey(parsed.key);
            }}
          >
            {copy.applyJson}
          </Button>
          <Button
            type="button"
            variant="primary"
            onClick={() => {
              saveFirebase(which, url, key);
              setEditing(!(url.trim() || key.trim()));
            }}
          >
            {copy.save}
          </Button>
        </>
      )}
    </Panel>
  );
}
