import { Archive, Blocks, KeyRound, MessageCircle, Shield, SlidersHorizontal } from "lucide-react";
import { useEffect } from "react";
import { t } from "@/lib/studio/i18n";
import { ensureExportClock, hydrate, setLang, setTab, tick, useStudio } from "@/lib/studio/store";
import type { TabId } from "@/lib/studio/types";
import { BuildTab } from "./BuildTab";
import { CopilotTab } from "./CopilotTab";
import { AdminTab, SecretsTab, SkillsTab, VaultTab } from "./OtherTabs";

const TABS: { id: TabId; icon: typeof Blocks }[] = [
  { id: "pilot", icon: MessageCircle },
  { id: "build", icon: Blocks },
  { id: "vault", icon: Archive },
  { id: "admin", icon: Shield },
  { id: "skills", icon: SlidersHorizontal },
  { id: "secrets", icon: KeyRound },
];

export function StudioApp() {
  const studio = useStudio();
  const copy = t(studio.lang);

  useEffect(() => {
    hydrate();
    const timer = setInterval(() => tick(), 400);
    const onFocus = () => tick();
    window.addEventListener("focus", onFocus);
    return () => {
      clearInterval(timer);
      window.removeEventListener("focus", onFocus);
    };
  }, []);

  useEffect(() => {
    ensureExportClock();
  }, [studio.activeJobId, studio.jobs]);

  return (
    <div className="safe-pad mx-auto flex min-h-dvh w-full max-w-lg flex-col">
      <header className="px-4 pt-4">
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="font-display text-2xl font-semibold tracking-tight text-fg">{copy.wordmark}</p>
            <p className="text-sm text-cyan">{copy.product}</p>
          </div>
          <div className="flex rounded-md border border-line p-1">
            <button
              type="button"
              className={`min-h-11 rounded-sm px-3 text-sm ${studio.lang === "en" ? "bg-cyan text-ink" : "text-muted"}`}
              onClick={() => setLang("en")}
            >
              {copy.langEn}
            </button>
            <button
              type="button"
              className={`min-h-11 rounded-sm px-3 text-sm ${studio.lang === "hi" ? "bg-violet text-ink" : "text-muted"}`}
              onClick={() => setLang("hi")}
            >
              {copy.langHi}
            </button>
          </div>
        </div>
        <p className="mt-2 text-sm text-muted">{copy.tagline}</p>
      </header>
      <nav aria-label="Studio" className="mt-3 flex gap-2 overflow-x-auto px-4 pb-2">
        {TABS.map((tab) => {
          const Icon = tab.icon;
          const on = studio.tab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              aria-current={on ? "page" : undefined}
              className={`inline-flex min-h-11 shrink-0 items-center gap-2 rounded-full px-3 text-sm ${on ? "bg-cyan text-ink" : "glass text-fg"}`}
              onClick={() => setTab(tab.id)}
            >
              <Icon className="size-4" aria-hidden="true" />
              {copy.tabs[tab.id]}
            </button>
          );
        })}
      </nav>
      <main className="flex-1 px-4 pb-8">
        {studio.tab === "pilot" ? <CopilotTab /> : null}
        {studio.tab === "build" ? <BuildTab /> : null}
        {studio.tab === "vault" ? <VaultTab /> : null}
        {studio.tab === "admin" ? <AdminTab /> : null}
        {studio.tab === "skills" ? <SkillsTab /> : null}
        {studio.tab === "secrets" ? <SecretsTab /> : null}
      </main>
    </div>
  );
}
