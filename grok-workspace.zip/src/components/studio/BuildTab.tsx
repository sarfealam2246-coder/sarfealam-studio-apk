import { useEffect, useState } from "react";
import { CHIPS } from "@/lib/studio/blueprint";
import { EXPORT_FILES, downloadProject } from "@/lib/studio/export-project";
import { statusLabel, t } from "@/lib/studio/i18n";
import {
  approveExport,
  cancelBuild,
  launchBuild,
  requestFix,
  runVisionCheck,
  setDraft,
  useStudio,
} from "@/lib/studio/store";
import type { Job } from "@/lib/studio/types";
import { LivePreview } from "./LivePreview";
import { Button, Panel, TextArea } from "./ui";

export function BuildTab() {
  const studio = useStudio();
  const copy = t(studio.lang);
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);
  const job = studio.jobs.find((item) => item.id === studio.activeJobId) ?? null;
  const admin = job ? studio.admins[job.id] : undefined;
  const notice = latestNotice(admin?.notifications ?? [], now);
  const hasToken = studio.secrets.tokens[0].trim().length > 0;
  const hasApps = Boolean(studio.secrets.appsFb.url.trim() && studio.secrets.appsFb.key.trim());

  return (
    <div className="grid gap-4">
      {studio.routingLine ? (
        <p className="text-xs text-cyan">
          {copy.providerLine}: {studio.routingLine}
        </p>
      ) : null}
      {job && studio.skills.survivor && (job.status === "assembling" || job.status === "ready") ? (
        <p className="rounded-md border border-line px-3 py-2 text-sm">
          {job.status === "assembling" ? copy.resumeRun : copy.resumeReady}: {job.blueprint.title}
        </p>
      ) : null}
      <TextArea
        rows={3}
        value={studio.draftPrompt}
        placeholder={copy.promptPh}
        aria-label={copy.promptPh}
        onChange={(event) => setDraft(event.target.value)}
      />
      <div>
        <p className="mb-2 text-xs text-subtle">{copy.examples}</p>
        <div className="flex gap-2 overflow-x-auto pb-1">
          {CHIPS.map((chip) => (
            <button
              key={chip.id}
              type="button"
              className="min-h-11 shrink-0 rounded-full border border-line px-4 text-sm text-fg"
              onClick={() => setDraft(studio.lang === "hi" ? chip.promptHi : chip.promptEn)}
            >
              {studio.lang === "hi" ? chip.labelHi : chip.labelEn}
            </button>
          ))}
        </div>
      </div>
      <Button type="button" variant="primary" onClick={launchBuild}>
        {copy.launch}
      </Button>
      {job ? (
        <>
          <div className="flex flex-wrap items-center gap-2 text-sm">
            <span className="font-medium">{job.blueprint.title}</span>
            <span className="text-subtle">{job.blueprint.kind === "game" ? copy.kindGame : copy.kindApp}</span>
            <span className="text-cyan">{statusLabel(job.status, studio.lang)}</span>
          </div>
          <ol className="grid gap-2">
            {copy.stages.map((label, index) => {
              const n = index + 1;
              const done = job.stage > n || (job.stage === n && job.status !== "assembling");
              const live = job.stage === n && job.status === "assembling";
              return (
                <li
                  key={label}
                  className={`flex min-h-11 items-center gap-3 rounded-md px-3 text-sm ${done ? "bg-surface text-fg" : "text-muted"} ${live ? "stage-live text-cyan" : ""}`}
                >
                  <span className="tabular-nums">{n}</span>
                  <span>{label}</span>
                </li>
              );
            })}
          </ol>
          <p className="text-xs text-subtle">{job.routeLabel}</p>
          {admin ? <LivePreview job={job} lang={studio.lang} admin={admin} notice={notice} /> : null}
          <p className="text-sm text-muted">{job.stage >= 4 ? copy.testHint : copy.testLocked}</p>
          <div className="grid gap-2">
            {job.status === "ready" ? (
              <Button type="button" variant="primary" onClick={approveExport}>
                {copy.ok}
              </Button>
            ) : null}
            {job.status === "ready" || job.status === "ok" || job.status === "export" ? (
              <Button type="button" variant="quiet" onClick={requestFix}>
                {copy.fix}
              </Button>
            ) : null}
            {job.status === "assembling" || job.status === "ready" ? (
              <Button type="button" variant="danger" onClick={cancelBuild}>
                {copy.cancel}
              </Button>
            ) : null}
            {job.stage >= 4 ? (
              <Button type="button" variant="quiet" onClick={runVisionCheck}>
                {copy.uiCheck}
              </Button>
            ) : null}
          </div>
          {job.status === "ok" || job.status === "export" ? (
            <ExportPanel job={job} hasToken={hasToken} hasApps={hasApps} assetHint={studio.skills.assets} />
          ) : null}
        </>
      ) : null}
    </div>
  );
}

function latestNotice(notes: { text: string; at: number }[], now: number): string {
  const note = notes[0];
  if (!note || now - note.at > 8000) return "";
  return note.text;
}

function ExportPanel({
  job,
  hasToken,
  hasApps,
  assetHint,
}: {
  job: Job;
  hasToken: boolean;
  hasApps: boolean;
  assetHint: boolean;
}) {
  const studio = useStudio();
  const copy = t(studio.lang);
  const githubOn = studio.skills.github;
  return (
    <Panel className="grid gap-3">
      <h2 className="font-display text-lg font-semibold">{copy.exportTitle}</h2>
      <p className="text-sm text-muted">{hasApps ? copy.injected : copy.missingApps}</p>
      <div>
        <p className="mb-2 text-xs text-subtle">{copy.fileList}</p>
        <ul className="grid gap-1 text-sm">
          {EXPORT_FILES.filter((file) => assetHint || file !== "THIRD_PARTY.md").map((file) => {
            const stepDone = job.exportSteps.some((step) => step.id === "files" && (step.state === "done" || step.state === "run"));
            return (
              <li key={file} className="flex justify-between gap-3">
                <span className="truncate">{file}</span>
                <span className="text-cyan">{stepDone ? "ok" : "…"}</span>
              </li>
            );
          })}
        </ul>
      </div>
      <div>
        <p className="mb-2 text-xs text-subtle">{copy.githubTitle}</p>
        <ul className="grid gap-2 text-sm">
          {job.exportSteps
            .filter((step) => step.id !== "files")
            .map((step) => (
              <li key={step.id} className="flex items-start justify-between gap-3">
                <span>{step.label}</span>
                <span className={step.state === "skip" ? "text-subtle" : "text-ok"}>
                  {step.state === "skip" ? (githubOn ? (hasToken ? "skip" : "need token") : "skill off") : step.state}
                </span>
              </li>
            ))}
        </ul>
        <p className="mt-3 text-sm text-fg">
          {hasToken && githubOn
            ? "Ready to upload this project to GitHub for a real APK."
            : "Download the zip, then upload this project to GitHub for a real APK."}
        </p>
      </div>
      {assetHint ? <p className="text-xs text-subtle">{copy.assetHint}</p> : null}
      <Button
        type="button"
        variant="violet"
        onClick={() => downloadProject(job, studio.secrets.appsFb, assetHint && job.blueprint.skills.includes("assets"))}
      >
        {copy.download}
      </Button>
    </Panel>
  );
}
