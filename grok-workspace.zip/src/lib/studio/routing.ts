import type { Dept, KeyTag, Lang, Provider, RouteHit, Secrets } from "./types";

interface ModelSpec {
  label: string;
  provider: Provider;
}

const CHAINS: Record<Dept, ModelSpec[]> = {
  brain: [
    { label: "Gemini 2.5 Flash", provider: "gemini" },
    { label: "Groq gpt-oss-120b", provider: "groq" },
    { label: "Llama 3.3 70B Instruct", provider: "groq" },
    { label: "Moonshot Kimi K3.1 Pro", provider: "moonshot" },
    { label: "Cohere command-a-03-2025", provider: "cohere" },
    { label: "OpenRouter free", provider: "openrouter" },
    { label: "Mixtral 8x22B", provider: "groq" },
  ],
  code: [
    { label: "Qwen 2.5 Coder 32B", provider: "groq" },
    { label: "DeepSeek V4.1 Flash", provider: "deepseek" },
    { label: "Gemini 2.5 Flash", provider: "gemini" },
    { label: "Groq gpt-oss-120b", provider: "groq" },
    { label: "Nemotron Super 49B", provider: "nvidia" },
  ],
  fast: [
    { label: "DeepSeek V4.1 Flash", provider: "deepseek" },
    { label: "Nemotron 3.5 Lightning", provider: "nvidia" },
    { label: "Groq gpt-oss-120b", provider: "groq" },
    { label: "OpenRouter free", provider: "openrouter" },
    { label: "Mixtral 8x22B", provider: "groq" },
  ],
  vision: [
    { label: "Nemotron Nano 12B VL", provider: "nvidia" },
    { label: "Gemini 2.5 Flash vision", provider: "gemini" },
  ],
  listen: [
    { label: "Groq Whisper large-v3-turbo", provider: "groq" },
    { label: "NVIDIA Parakeet", provider: "nvidia" },
  ],
  speak: [{ label: "NVIDIA Magpie", provider: "nvidia" }],
  reason: [
    { label: "DeepSeek R1", provider: "deepseek" },
    { label: "Llama 3.3 70B", provider: "groq" },
    { label: "Nemotron Super 49B", provider: "nvidia" },
    { label: "Kimi K3.1 Pro", provider: "moonshot" },
  ],
};

const DEPT_LABEL: Record<Dept, string> = {
  brain: "Brain",
  code: "Code",
  fast: "Fast",
  vision: "Vision",
  listen: "Listen",
  speak: "Speak",
  reason: "Reason",
};

export function detectProvider(value: string): Provider | null {
  const v = value.trim();
  if (!v) return null;
  if (v.startsWith("AIza")) return "gemini";
  if (v.startsWith("gsk_")) return "groq";
  if (v.startsWith("sk-or-")) return "openrouter";
  if (v.startsWith("nvapi-")) return "nvidia";
  if (v.startsWith("cohere-") || v.startsWith("co-")) return "cohere";
  if (v.startsWith("sk-ds-") || v.startsWith("ds-")) return "deepseek";
  if (v.startsWith("sk-") && v.length > 12) return "moonshot";
  return null;
}

function tagAllows(tag: KeyTag, dept: Dept): boolean {
  if (tag === "" || tag === "Primary" || tag === "Fallback") return true;
  if (tag === "General") return dept === "brain" || dept === "reason" || dept === "fast";
  if (tag === "Code") return dept === "code";
  if (tag === "Fast") return dept === "fast";
  if (tag === "Vision") return dept === "vision";
  return false;
}

interface Usable {
  provider: Provider;
  tag: KeyTag;
}

function usableKeys(secrets: Secrets, dept: Dept): Usable[] {
  const list: Usable[] = [];
  for (const key of secrets.keys) {
    const provider = detectProvider(key.value);
    if (!provider) continue;
    if (!tagAllows(key.tag, dept)) continue;
    list.push({ provider, tag: key.tag });
  }
  if (dept === "listen" || dept === "speak") {
    const provider = detectProvider(secrets.voice);
    if (provider && (provider === "groq" || provider === "nvidia")) {
      list.push({ provider, tag: "Primary" });
    }
  }
  return list;
}

export function resolveDepartment(dept: Dept, secrets: Secrets): RouteHit {
  const chain = CHAINS[dept];
  const keys = usableKeys(secrets, dept);
  for (let i = 0; i < chain.length; i++) {
    const model = chain[i];
    if (!model) continue;
    const hit = keys.find((k) => k.provider === model.provider);
    if (hit) {
      return {
        dept,
        model: model.label,
        provider: model.provider,
        fallback: i > 0,
        mocked: false,
      };
    }
  }
  return { dept, model: "local assembler", provider: "local", fallback: false, mocked: true };
}

export function formatRoute(hit: RouteHit, lang: Lang): string {
  const name = DEPT_LABEL[hit.dept];
  if (hit.mocked) {
    return lang === "hi" ? `${name}: लोकल असेंबलर (कुंजी नहीं)` : `${name}: local assembler (no key)`;
  }
  const fb = hit.fallback ? (lang === "hi" ? " · फ़ॉलबैक" : " · fallback") : "";
  return `${name}: ${hit.model}${fb}`;
}

export function deptLabel(dept: Dept): string {
  return DEPT_LABEL[dept];
}
