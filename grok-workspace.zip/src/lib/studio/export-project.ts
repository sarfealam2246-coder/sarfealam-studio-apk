import type { FirebaseSlot, Job } from "./types";
import { zipFiles } from "./zip";

export const EXPORT_FILES = [
  "README.md",
  "package.json",
  "capacitor.config.json",
  "firebase.apps.json",
  "www/index.html",
  "www/app.js",
  "www/styles.css",
  ".github/workflows/android-apk.yml",
  "THIRD_PARTY.md",
];

export function buildProjectFiles(job: Job, apps: FirebaseSlot, assetHint: boolean): { path: string; text: string }[] {
  const cfg = {
    databaseURL: apps.url.trim(),
    apiKey: apps.key.trim(),
    purpose: "Apps Firebase — login, profile, and user data for this published app.",
  };
  const js = renderAppJs(job, cfg);
  const files: { path: string; text: string }[] = [
    { path: "README.md", text: readme(job) },
    { path: "package.json", text: pkg(job) },
    { path: "capacitor.config.json", text: capacitor(job) },
    { path: "firebase.apps.json", text: JSON.stringify(cfg, null, 2) + "\n" },
    { path: "www/index.html", text: html() },
    { path: "www/app.js", text: js },
    { path: "www/styles.css", text: css() },
    { path: ".github/workflows/android-apk.yml", text: workflow() },
  ];
  if (assetHint) {
    files.push({
      path: "THIRD_PARTY.md",
      text: "Open-source hints\n\n- Kenney assets (CC0) if you add sprites later.\n- Outfit and Syne via Google Fonts (OFL).\nKeep this file in the repo.\n",
    });
  }
  return files;
}

export function downloadProject(job: Job, apps: FirebaseSlot, assetHint: boolean): void {
  const blob = zipFiles(buildProjectFiles(job, apps, assetHint));
  const a = document.createElement("a");
  const url = URL.createObjectURL(blob);
  a.href = url;
  a.download = `${job.blueprint.slug}.zip`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function pkg(job: Job): string {
  return JSON.stringify(
    {
      name: job.blueprint.slug,
      private: true,
      scripts: {
        start: "npx serve www",
        "cap:sync": "npx cap sync android",
      },
      dependencies: {
        "@capacitor/core": "^7.0.0",
        "@capacitor/android": "^7.0.0",
      },
    },
    null,
    2,
  );
}

function capacitor(job: Job): string {
  return JSON.stringify(
    {
      appId: `app.sarfealam.${job.blueprint.slug.replace(/-/g, "")}`,
      appName: job.blueprint.title,
      webDir: "www",
    },
    null,
    2,
  );
}

function readme(job: Job): string {
  return `# ${job.blueprint.title}

Built in Sarfealam Auto-Studio.

Kind: ${job.blueprint.kind}
Template: ${job.blueprint.template}

## Test on a phone browser

Unzip, then from this folder run a static server and open \`www/index.html\` on your phone (same Wi-Fi). The page is plain HTML, CSS, and JS.

## Apps Firebase

\`firebase.apps.json\` and \`www/app.js\` use the Apps Firebase slot from the studio (not Studio Firebase). Profile saves go to \`/appdata/profile\` on that Realtime Database when URL and key are set.

## Android APK

1. Create a GitHub repo and push this folder.
2. Add the Android project once: \`npm install\` then \`npx cap add android\`.
3. Push again. The workflow \`.github/workflows/android-apk.yml\` runs \`assembleDebug\` and uploads an APK artifact.

Prompt that produced this build:

> ${job.prompt}
`;
}

function workflow(): string {
  return `name: Android APK
on:
  push:
    branches: [main]
jobs:
  apk:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 22
      - name: Sync web assets
        run: npx --yes @capacitor/cli@7 sync android || echo "Run npx cap add android once, then re-run."
      - uses: android-actions/setup-android@v3
      - name: assembleDebug
        run: |
          if [ -d android ]; then
            cd android && chmod +x ./gradlew && ./gradlew assembleDebug
          else
            echo "android/ missing — add Capacitor Android, commit, push again."
            exit 1
          fi
      - uses: actions/upload-artifact@v4
        if: always()
        with:
          name: debug-apk
          path: android/app/build/outputs/apk/debug/*.apk
          if-no-files-found: warn
`;
}

function html(): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Sarfealam build</title>
  <link rel="stylesheet" href="./styles.css" />
</head>
<body>
  <main id="app"></main>
  <script src="./app.js"></script>
</body>
</html>
`;
}

function css(): string {
  return `:root { color-scheme: dark; }
body { margin: 0; font-family: Outfit, system-ui, sans-serif; background: #07090f; color: #e7eef8; }
main { max-width: 32rem; margin: 0 auto; padding: 1.25rem; display: grid; gap: 0.75rem; }
h1 { font-size: 1.6rem; margin: 0; letter-spacing: -0.03em; }
p { color: #9aabc4; margin: 0; }
button, input { min-height: 2.75rem; border-radius: 0.7rem; border: 1px solid #2c3548; background: #161a26; color: inherit; padding: 0 0.9rem; font: inherit; }
button { background: #3ee0ff; color: #061018; font-weight: 600; }
.row { display: flex; gap: 0.5rem; }
.card { border: 1px solid #2c3548; border-radius: 1rem; padding: 0.9rem; background: #10131c; }
`;
}

function renderAppJs(
  job: Job,
  cfg: { databaseURL: string; apiKey: string; purpose: string },
): string {
  const payload = {
    title: job.blueprint.title,
    template: job.blueprint.template,
    kind: job.blueprint.kind,
    summary: job.blueprint.summary,
    skills: job.blueprint.skills,
    screens: job.blueprint.screens,
    items: job.sandbox.items,
    firebase: cfg,
  };
  return `/* Generated by Sarfealam Auto-Studio. Apps Firebase is injected below. */
const BUILD = ${JSON.stringify(payload, null, 2)};

const app = document.querySelector("#app");
const saved = localStorage.getItem("sarfealam-profile");
let profile = saved ? JSON.parse(saved) : { name: "" };

function draw() {
  app.innerHTML = "";
  const h = document.createElement("h1");
  h.textContent = BUILD.title;
  const p = document.createElement("p");
  p.textContent = BUILD.summary;
  app.append(h, p);
  const box = document.createElement("div");
  box.className = "card";
  box.textContent = BUILD.firebase.databaseURL
    ? "Apps Firebase connected for profile and user data."
    : "Apps Firebase config is empty. Paste it in the studio and export again.";
  app.append(box);
  for (const item of BUILD.items) {
    const row = document.createElement("div");
    row.className = "card";
    row.textContent = item.title + " · " + item.note;
    app.append(row);
  }
  const form = document.createElement("form");
  form.className = "row";
  const input = document.createElement("input");
  input.placeholder = "Profile name";
  input.value = profile.name || "";
  input.name = "name";
  const button = document.createElement("button");
  button.type = "submit";
  button.textContent = "Save profile";
  form.append(input, button);
  form.addEventListener("submit", function (event) {
    event.preventDefault();
    profile = { name: input.value };
    localStorage.setItem("sarfealam-profile", JSON.stringify(profile));
    saveRemote(profile);
  });
  app.append(form);
}

async function saveRemote(next) {
  const url = (BUILD.firebase.databaseURL || "").replace(/\\/+$/, "");
  const key = BUILD.firebase.apiKey || "";
  if (!url || !key) return;
  try {
    await fetch(url + "/appdata/profile.json?auth=" + encodeURIComponent(key), {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(next),
    });
  } catch (err) {
    console.warn("Apps Firebase save skipped", err);
  }
}

draw();
`;
}
