import type { Blueprint, FirebaseSlot, Kind, Sandbox, SkillId, Template } from "./types";

export interface Chip {
  id: string;
  labelEn: string;
  labelHi: string;
  promptEn: string;
  promptHi: string;
}

export const CHIPS: Chip[] = [
  {
    id: "fantasy",
    labelEn: "Fantasy app",
    labelHi: "फैंटेसी ऐप",
    promptEn: "Fantasy prediction app with a match list and reveal",
    promptHi: "फैंटेसी भविष्यवाणी ऐप, मैच सूची और रिवील",
  },
  {
    id: "vehicle",
    labelEn: "3D vehicle game",
    labelHi: "3D वाहन गेम",
    promptEn: "3D vehicle game with steering, gas and brake",
    promptHi: "3D गाड़ी गेम, स्टीयरिंग, गैस और ब्रेक",
  },
  {
    id: "khata",
    labelEn: "Khata book",
    labelHi: "खाता बही",
    promptEn: "Khata book for udhar and jama with balance",
    promptHi: "खाता बही, उधार और जमा, बैलेंस के साथ",
  },
  {
    id: "cards",
    labelEn: "Card table",
    labelHi: "कार्ड टेबल",
    promptEn: "Card table game like teen patti with deal and draw",
    promptHi: "तीन पत्ती जैसी कार्ड टेबल, डील और ड्रॉ",
  },
  {
    id: "delivery",
    labelEn: "Delivery app",
    labelHi: "डिलीवरी ऐप",
    promptEn: "Delivery app with booking, zones and order list",
    promptHi: "डिलीवरी ऐप, बुकिंग, ज़ोन और ऑर्डर सूची",
  },
];

const ALL_ON: Record<SkillId, boolean> = {
  otp: true,
  tabs: true,
  profile: true,
  search: true,
  lists: true,
  wallet: true,
  vip: true,
  maps: true,
  game3d: true,
  cards: true,
  github: true,
  assets: true,
  survivor: true,
};

export function defaultSkills(): Record<SkillId, boolean> {
  return { ...ALL_ON };
}

function has(p: string, words: string[]): boolean {
  return words.some((w) => p.includes(w));
}

export function makeBlueprint(prompt: string, toggles: Record<SkillId, boolean>): Blueprint {
  const p = prompt.toLowerCase();
  const warnings: string[] = [];

  const wantsCard = has(p, ["card", "patti", "rummy", "poker", "ताश", "पत्ती", "रम्मी", "कार्ड"]);
  const wantsGame = has(p, [
    "game",
    "3d",
    "vehicle",
    "car",
    "race",
    "steer",
    "drive",
    "गेम",
    "गाड़ी",
    "रेस",
    "कार",
    "वाहन",
  ]);

  let template: Template = "generic";
  let kind: Kind = "app";

  if (wantsCard) {
    if (toggles.cards) {
      template = "card";
      kind = "game";
    } else {
      warnings.push("cards-off");
    }
  } else if (wantsGame) {
    if (toggles.game3d) {
      template = "game";
      kind = "game";
    } else {
      warnings.push("game-off");
    }
  } else if (has(p, ["khata", "ledger", "udhar", "खाता", "खता", "उधार", "बही", "jama", "जमा"])) {
    template = "khata";
  } else if (has(p, ["deliver", "order", "rider", "booking", "डिलीवरी", "ऑर्डर", "बुकिंग"])) {
    template = "delivery";
  } else if (has(p, ["bank", "upi", "transfer", "wallet", "balance", "बैंक", "वॉलेट", "बैलेंस"])) {
    template = "bank";
  } else if (has(p, ["shop", "store", "cart", "ecommerce", "e-commerce", "दुकान", "कार्ट"])) {
    template = "shop";
  } else if (has(p, ["fantasy", "predict", "भविष्य", "फैंटेसी", "prediction"])) {
    template = "fantasy";
  }

  const skills: SkillId[] = [];
  const add = (id: SkillId, when: boolean) => {
    if (when && toggles[id] && !skills.includes(id)) skills.push(id);
  };

  if (kind === "game" && template === "game") add("game3d", true);
  if (kind === "game" && template === "card") add("cards", true);

  if (kind === "app") {
    add("tabs", true);
    add("lists", template !== "bank");
    add("search", toggles.search && (template === "shop" || template === "delivery" || template === "fantasy" || has(p, ["search", "खोज"])));
    add("profile", toggles.profile && (template !== "fantasy" || has(p, ["profile", "प्रोफाइल", "login", "account"])));
    add("wallet", template === "khata" || template === "bank" || has(p, ["wallet", "balance", "वॉलेट", "बैलेंस"]));
    add("maps", template === "delivery" || has(p, ["map", "zone", "मैप", "ज़ोन"]));
    add("vip", has(p, ["vip", "plan", "premium", "वीआईपी", "प्लान"]));
    add("otp", has(p, ["otp", "login", "sign in", "signin", "gmail", "auth", "लॉगिन", "ओटीपी"]));
    if (template === "shop") add("search", true);
    if (template === "bank" || template === "khata") add("wallet", true);
    if (template === "delivery") add("maps", true);
    if (template === "fantasy" || template === "shop" || template === "generic" || template === "khata" || template === "delivery") {
      add("lists", true);
    }
    if (!skills.includes("profile") && toggles.profile && (template === "generic" || template === "bank" || template === "shop")) {
      add("profile", true);
    }
  }

  add("github", toggles.github);
  add("assets", toggles.assets);
  add("survivor", toggles.survivor);

  const title = titleFrom(prompt, template);
  const screens = screensFor(template, skills);

  return {
    title,
    slug: slugify(title),
    kind,
    template,
    summary: summaryFor(template),
    skills,
    screens,
    warnings,
  };
}

function titleFrom(prompt: string, template: Template): string {
  const clean = prompt.replace(/\s+/g, " ").trim();
  if (clean.length > 0 && clean.length <= 48) return clean;
  if (clean.length > 48) return clean.slice(0, 46).trimEnd() + "…";
  return template;
}

function slugify(title: string): string {
  const latin = title
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 28);
  return latin || "sarfealam-app";
}

function summaryFor(template: Template): string {
  switch (template) {
    case "game":
      return "Chase-view vehicle. Steer, gas, brake.";
    case "card":
      return "Three-card table. Deal and draw.";
    case "khata":
      return "Udhar and jama with a running balance.";
    case "delivery":
      return "Orders, zones, and a booking action.";
    case "bank":
      return "Balance hero and a transfer form.";
    case "shop":
      return "Catalog, search, and cart.";
    case "fantasy":
      return "Match list and a reveal.";
    default:
      return "Shell, list, and a working form.";
  }
}

function screensFor(template: Template, skills: SkillId[]): { id: string; label: string }[] {
  if (template === "game") return [{ id: "world", label: "World" }];
  if (template === "card") return [{ id: "table", label: "Table" }];
  const screens: { id: string; label: string }[] = [{ id: "home", label: "Home" }];
  if (skills.includes("lists") || skills.includes("search")) screens.push({ id: "list", label: "List" });
  if (skills.includes("maps")) screens.push({ id: "map", label: "Map" });
  if (skills.includes("wallet")) screens.push({ id: "wallet", label: "Wallet" });
  if (skills.includes("profile")) screens.push({ id: "profile", label: "Profile" });
  return screens;
}

export function seedSandbox(bp: Blueprint): Sandbox {
  const base: Sandbox = {
    tab: bp.screens[0]?.id ?? "home",
    query: "",
    items: [],
    balance: 0,
    draftTitle: "",
    draftAmount: "",
    hand: [],
    pot: 0,
    lastAction: "",
    revealed: false,
    vipOpen: false,
    otpPassed: !bp.skills.includes("otp"),
    otpCode: "",
    cart: 0,
  };

  if (bp.template === "khata") {
    base.items = [
      { id: "k1", title: "Ravi", note: "udhar", amount: 500 },
      { id: "k2", title: "Meena", note: "jama", amount: -200 },
    ];
    base.balance = 300;
  } else if (bp.template === "delivery") {
    base.items = [
      { id: "d1", title: "Parcel · Sector 12", note: "Out for drop", amount: 80 },
      { id: "d2", title: "Parcel · Civil Lines", note: "Booked", amount: 60 },
    ];
    base.balance = 140;
  } else if (bp.template === "bank") {
    base.balance = 12450;
    base.items = [{ id: "b1", title: "Opening", note: "credit", amount: 12450 }];
  } else if (bp.template === "shop") {
    base.items = [
      { id: "s1", title: "Linen shirt", note: "Cloth", amount: 890 },
      { id: "s2", title: "Clay cup set", note: "Home", amount: 420 },
      { id: "s3", title: "Ink notebook", note: "Paper", amount: 160 },
    ];
  } else if (bp.template === "fantasy") {
    base.items = [
      { id: "f1", title: "Night derby", note: "Open", amount: 0 },
      { id: "f2", title: "River final", note: "Open", amount: 0 },
      { id: "f3", title: "City cup", note: "Locked", amount: 0 },
    ];
  } else if (bp.template === "generic") {
    base.items = [
      { id: "g1", title: "First screen", note: "Shell", amount: 0 },
      { id: "g2", title: "Main action", note: "Ready", amount: 0 },
    ];
  } else if (bp.template === "card") {
    base.pot = 40;
    base.hand = dealHand(bp.title, 3);
  }
  return base;
}

const RANKS = ["A", "K", "Q", "J", "10", "9", "8", "7", "6", "5", "4", "3", "2"];
const SUITS = ["S", "H", "D", "C"];

function hash(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

export function dealHand(seed: string, n: number): string[] {
  const used = new Set<string>();
  const cards: string[] = [];
  let x = hash(seed);
  while (cards.length < n) {
    x = (Math.imul(x, 1664525) + 1013904223) >>> 0;
    const card = `${RANKS[x % RANKS.length]}${SUITS[(x >>> 8) % SUITS.length]}`;
    if (used.has(card)) continue;
    used.add(card);
    cards.push(card);
  }
  return cards;
}

export function rankValue(card: string): number {
  const r = card.replace(/[SHDC]$/, "");
  const order = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"];
  return order.indexOf(r);
}

export function emptyFirebase(): FirebaseSlot {
  return { url: "", key: "" };
}
