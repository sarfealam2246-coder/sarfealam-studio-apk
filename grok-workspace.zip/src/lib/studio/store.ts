import { useSyncExternalStore } from "react";
import { defaultSkills, makeBlueprint, seedSandbox } from "./blueprint";
import {
  answer,
  cancelLine,
  exportLine,
  fixLine,
  launchLine,
  readyLine,
  resumeLine,
  warningLine,
  welcome,
} from "./dialogue";
import { pullStudio, pushStudio, toRemote } from "./firebase";
import { formatRoute, resolveDepartment } from "./routing";
import type {
  AdminState,
  ExportStep,
  Job,
  KeyTag,
  Lang,
  PilotMessage,
  SecretKey,
  SkillId,
  StudioState,
  TabId,
} from "./types";

const STATE_KEY = "sarfealam.studio.v1";
const SECRET_KEY = "sarfealam.secrets.v1";
const STEP_MS = 900;

function blank(): StudioState {
  return {
    lang: "en",
    welcomed: false,
    tab: "pilot",
    draftPrompt: "",
    secrets: {
      keys: emptyKeys(),
      tokens: ["", ""],
      voice: "",
      studioFb: { url: "", key: "" },
      appsFb: { url: "", key: "" },
    },
    skills: defaultSkills(),
    jobs: [],
    activeJobId: null,
    admins: {},
    messages: [],
    routingLine: "",
    thinking: false,
    syncNote: "",
    updatedAt: 0,
    booted: false,
  };
}
function emptyKeys(): SecretKey[] {
  return Array.from({ length: 7 }, (_, i) => ({ id: `k${i + 1}`, value: "", tag: "" as KeyTag }));
}

function emptyAdmin(): AdminState {
  return {
    banner: false,
    bannerText: "Live from the studio",
    vipNote: "VIP unlocks the extra plan.",
    apkLink: "",
    notifications: [],
  };
}

function initial(): StudioState {
  const base = blank();
  return {
    ...base,
    messages: [{ id: "welcome", role: "pilot", text: welcome("en"), at: 0 }],
  };
}

let state: StudioState = initial();
const serverSnapshot: StudioState = state;
const listeners = new Set<() => void>();
let remoteTimer: ReturnType<typeof setTimeout> | null = null;
let thinkTimer: ReturnType<typeof setTimeout> | null = null;
let exportTimer: ReturnType<typeof setTimeout> | null = null;
let pulling = false;

function emit() {
  for (const listener of listeners) listener();
}

function uid(prefix: string): string {
  return `${prefix}-${Math.random().toString(36).slice(2, 8)}${Date.now().toString(36).slice(-4)}`;
}

function pilot(text: string): PilotMessage {
  return { id: uid("m"), role: "pilot", text, at: Date.now() };
}

function withSecrets(base: StudioState, secrets: StudioState["secrets"]): StudioState {
  return { ...base, secrets };
}

function writeLocal(next: StudioState) {
  try {
    const { secrets, ...rest } = next;
    localStorage.setItem(STATE_KEY, JSON.stringify({ ...rest, booted: false, thinking: false }));
    localStorage.setItem(SECRET_KEY, JSON.stringify(secrets));
  } catch {
    /* private mode */
  }
}

function commit(next: StudioState, opts?: { remote?: boolean }) {
  state = { ...next, updatedAt: Date.now() };
  emit();
  if (state.booted) writeLocal(state);
  if (opts?.remote !== false && state.booted) scheduleRemote();
}

function scheduleRemote() {
  if (remoteTimer) clearTimeout(remoteTimer);
  remoteTimer = setTimeout(() => {
    remoteTimer = null;
    const slot = state.secrets.studioFb;
    if (!slot.url.trim() || !slot.key.trim()) {
      if (state.syncNote !== "local") {
        state = { ...state, syncNote: "local" };
        emit();
      }
      return;
    }
    void pushStudio(slot, toRemote(state))
      .then(() => {
        if (state.syncNote !== "synced") {
          state = { ...state, syncNote: "synced" };
          emit();
          writeLocal(state);
        }
      })
      .catch(() => {
        state = { ...state, syncNote: "error" };
        emit();
      });
  }, 700);
}

function stageAt(job: Job, now: number): number {
  if (job.status !== "assembling") return job.stage;
  return Math.min(5, 1 + Math.floor((now - job.startedAt) / STEP_MS));
}

function applyStage(job: Job, now: number, lang: Lang): { job: Job; message?: PilotMessage } {
  if (job.status !== "assembling") return { job };
  const stage = stageAt(job, now);
  if (stage < 5) {
    if (stage === job.stage) return { job };
    return { job: { ...job, stage, updatedAt: now } };
  }
  const next: Job = { ...job, stage: 5, status: "ready", updatedAt: now, announcedReady: true };
  if (job.announcedReady) return { job: next };
  return { job: next, message: pilot(readyLine(lang, job.blueprint.title)) };
}

export function activeJob(s: StudioState = state): Job | null {
  return s.jobs.find((job) => job.id === s.activeJobId) ?? null;
}

export function tick(now = Date.now()) {
  const job = activeJob();
  if (!job || job.status !== "assembling") return;
  const applied = applyStage(job, now, state.lang);
  if (applied.job === job && !applied.message) return;
  const jobs = state.jobs.map((item) => (item.id === job.id ? applied.job : item));
  const messages = applied.message ? [...state.messages, applied.message].slice(-80) : state.messages;
  commit({ ...state, jobs, messages }, { remote: Boolean(applied.message) || applied.job.status !== job.status });
}

function exportLabels(lang: Lang, hasToken: boolean, hasGithub: boolean): ExportStep[] {
  const en = lang === "en";
  const files: ExportStep[] = [
    { id: "files", label: en ? "Write project files" : "प्रोजेक्ट फाइलें लिखें", state: "wait" },
    { id: "firebase", label: en ? "Inject Apps Firebase config" : "ऐप्स फायरबेस कॉन्फिग जोड़ें", state: "wait" },
  ];
  const gh = (id: string, label: string): ExportStep => ({
    id,
    label,
    state: hasGithub ? (hasToken ? "wait" : "skip") : "skip",
  });
  return [
    ...files,
    gh("repo", en ? "Create repo" : "रिपो बनाएं"),
    gh("push", en ? "Push files" : "फाइलें पुश करें"),
    gh("apk", en ? "Actions APK checklist" : "एक्शन्स एपीके सूची"),
  ];
}

function advanceExport(job: Job, lang: Lang, hasToken: boolean): Job {
  const steps = job.exportSteps.map((step) => ({ ...step }));
  const index = steps.findIndex((step) => step.state === "run" || step.state === "wait");
  if (index === -1) return { ...job, status: "export" };
  const current = steps[index];
  if (!current) return job;
  if (current.state === "wait") {
    if (!hasToken && (current.id === "repo" || current.id === "push" || current.id === "apk")) {
      current.state = "skip";
    } else {
      current.state = "run";
    }
  } else if (current.state === "run") {
    current.state = "done";
  }
  const still = steps.some((step) => step.state === "wait" || step.state === "run");
  return { ...job, exportSteps: steps, status: still ? "ok" : "export", updatedAt: Date.now() };
}

export function tickExport() {
  const job = activeJob();
  if (!job || (job.status !== "ok" && job.status !== "export")) return;
  if (job.exportSteps.every((step) => step.state === "done" || step.state === "skip")) {
    if (job.status !== "export") {
      const jobs = state.jobs.map((item) => (item.id === job.id ? { ...item, status: "export" as const } : item));
      commit({ ...state, jobs });
    }
    if (exportTimer) {
      clearInterval(exportTimer);
      exportTimer = null;
    }
    return;
  }
  const next = advanceExport(job, state.lang, state.secrets.tokens[0].trim().length > 0);
  const jobs = state.jobs.map((item) => (item.id === job.id ? next : item));
  commit({ ...state, jobs });
}

export function hydrate() {
  let next = initial();
  try {
    const raw = localStorage.getItem(STATE_KEY);
    const secretRaw = localStorage.getItem(SECRET_KEY);
    if (raw) {
      const saved = JSON.parse(raw) as Partial<StudioState>;
      next = {
        ...next,
        ...saved,
        secrets: next.secrets,
        booted: false,
        thinking: false,
        jobs: Array.isArray(saved.jobs) ? saved.jobs : [],
        messages: Array.isArray(saved.messages) ? saved.messages : [],
        skills: { ...defaultSkills(), ...(saved.skills ?? {}) },
        admins: saved.admins ?? {},
      };
    }
    if (secretRaw) {
      const secrets = JSON.parse(secretRaw) as StudioState["secrets"];
      if (secrets && Array.isArray(secrets.keys) && secrets.keys.length === 7) {
        next = withSecrets(next, {
          keys: secrets.keys,
          tokens: secrets.tokens?.length === 2 ? secrets.tokens : ["", ""],
          voice: secrets.voice ?? "",
          studioFb: secrets.studioFb ?? { url: "", key: "" },
          appsFb: secrets.appsFb ?? { url: "", key: "" },
        });
      }
    }
  } catch {
    next = initial();
  }

  if (next.messages.length === 0) next.messages = [pilot(welcome(next.lang))];
  next.welcomed = true;

  const now = Date.now();
  const resumed: PilotMessage[] = [];
  next.jobs = next.jobs.map((job) => {
    if (job.status !== "assembling") return job;
    const applied = applyStage(job, now, next.lang);
    return applied.job;
  });
  const focus = next.jobs.find((job) => job.id === next.activeJobId);
  if (focus && next.skills.survivor && (focus.status === "assembling" || focus.status === "ready")) {
    resumed.push(pilot(resumeLine(next.lang, focus)));
    next.tab = "build";
  }
  if (resumed.length > 0) next.messages = [...next.messages, ...resumed].slice(-80);
  next.booted = true;
  next.syncNote = next.secrets.studioFb.url && next.secrets.studioFb.key ? "syncing" : "local";
  state = next;
  emit();
  writeLocal(state);
  void refreshRemote();
}

async function refreshRemote() {
  if (pulling) return;
  const slot = state.secrets.studioFb;
  if (!slot.url.trim() || !slot.key.trim()) return;
  pulling = true;
  try {
    const remote = await pullStudio(slot);
    pulling = false;
    if (!remote || remote.updatedAt <= state.updatedAt) {
      state = { ...state, syncNote: "synced" };
      emit();
      if (remote && remote.updatedAt <= state.updatedAt) void pushStudio(slot, toRemote(state));
      return;
    }
    const lang = remote.lang === "hi" ? "hi" : "en";
    let jobs = remote.jobs;
    const notes: PilotMessage[] = [];
    jobs = jobs.map((job) => {
      if (job.status !== "assembling") return job;
      const applied = applyStage(job, Date.now(), lang);
      if (state.skills.survivor) notes.push(pilot(resumeLine(lang, applied.job)));
      return applied.job;
    });
    state = {
      ...state,
      lang,
      tab: remote.tab ?? state.tab,
      draftPrompt: remote.draftPrompt ?? "",
      skills: { ...defaultSkills(), ...remote.skills },
      jobs,
      activeJobId: remote.activeJobId,
      admins: remote.admins ?? {},
      messages: [...(remote.messages ?? []), ...notes].slice(-80),
      syncNote: "synced",
      updatedAt: remote.updatedAt,
    };
    emit();
    writeLocal(state);
  } catch {
    pulling = false;
    state = { ...state, syncNote: "error" };
    emit();
  }
}

export function subscribe(listener: () => void) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

export function useStudio(): StudioState {
  return useSyncExternalStore(subscribe, () => state, () => serverSnapshot);
}

export function setTab(tab: TabId) {
  commit({ ...state, tab }, { remote: false });
}

export function setLang(lang: Lang) {
  if (state.lang === lang) return;
  const note =
    lang === "hi"
      ? "भाषा अब हिंदी है। को-पायलट यहीं से हिंदी में बात करेगा।"
      : "Language is English now. The co-pilot will stay in English.";
  commit({ ...state, lang, messages: [...state.messages, pilot(note)].slice(-80) });
}

export function setDraft(draftPrompt: string) {
  commit({ ...state, draftPrompt }, { remote: false });
}

export function setSkill(id: SkillId, on: boolean) {
  commit({ ...state, skills: { ...state.skills, [id]: on } });
}

export function launchBuild() {
  const prompt = state.draftPrompt.trim();
  if (!prompt) {
    const text =
      state.lang === "hi" ? "पहले आइडिया लिखें, फिर बिल्ड शुरू करें।" : "Write an idea first, then launch the build.";
    commit({ ...state, tab: "build", messages: [...state.messages, pilot(text)].slice(-80) });
    return;
  }
  const blueprint = makeBlueprint(prompt, state.skills);
  const route = resolveDepartment("code", state.secrets);
  const routeLabel = formatRoute(route, state.lang);
  const now = Date.now();
  const job: Job = {
    id: uid("job"),
    prompt,
    createdAt: now,
    updatedAt: now,
    startedAt: now,
    status: "assembling",
    stage: 1,
    routeLabel,
    blueprint,
    sandbox: seedSandbox(blueprint),
    exportSteps: [],
    announcedReady: false,
  };
  const messages = [pilot(launchLine(state.lang, blueprint.title, routeLabel))];
  for (const code of blueprint.warnings) {
    const line = warningLine(state.lang, code);
    if (line) messages.push(pilot(line));
  }
  commit({
    ...state,
    jobs: [job, ...state.jobs].slice(0, 30),
    activeJobId: job.id,
    tab: "build",
    routingLine: routeLabel,
    admins: { ...state.admins, [job.id]: state.admins[job.id] ?? emptyAdmin() },
    messages: [...state.messages, ...messages].slice(-80),
  });
}

export function cancelBuild() {
  const job = activeJob();
  if (!job) return;
  const next: Job = { ...job, status: "cancelled", updatedAt: Date.now() };
  commit({
    ...state,
    jobs: state.jobs.map((item) => (item.id === job.id ? next : item)),
    messages: [...state.messages, pilot(cancelLine(state.lang, job.blueprint.title))].slice(-80),
  });
}

export function requestFix() {
  commit({
    ...state,
    tab: "build",
    messages: [...state.messages, pilot(fixLine(state.lang))].slice(-80),
  });
}

export function approveExport() {
  const job = activeJob();
  if (!job || job.status !== "ready") return;
  const hasToken = state.secrets.tokens[0].trim().length > 0;
  const hasApps = Boolean(state.secrets.appsFb.url.trim() && state.secrets.appsFb.key.trim());
  const hasGithub = state.skills.github && job.blueprint.skills.includes("github");
  const steps = exportLabels(state.lang, hasToken, hasGithub);
  if (steps[0]) steps[0] = { ...steps[0], state: "run" };
  const next: Job = { ...job, status: "ok", exportSteps: steps, updatedAt: Date.now() };
  commit({
    ...state,
    jobs: state.jobs.map((item) => (item.id === job.id ? next : item)),
    messages: [
      ...state.messages,
      pilot(exportLine(state.lang, job.blueprint.title, hasToken && hasGithub, hasApps)),
    ].slice(-80),
  });
  if (exportTimer) clearInterval(exportTimer);
  exportTimer = setInterval(tickExport, 700);
}

export function selectJob(id: string) {
  commit({ ...state, activeJobId: id, tab: "build" });
}

export function patchSandbox(patch: Partial<Job["sandbox"]>) {
  const job = activeJob();
  if (!job) return;
  const next: Job = { ...job, sandbox: { ...job.sandbox, ...patch }, updatedAt: Date.now() };
  commit(
    { ...state, jobs: state.jobs.map((item) => (item.id === job.id ? next : item)) },
    { remote: false },
  );
}

export function patchAdmin(patch: Partial<AdminState>) {
  const id = state.activeJobId;
  if (!id) return;
  const current = state.admins[id] ?? emptyAdmin();
  commit({ ...state, admins: { ...state.admins, [id]: { ...current, ...patch } } });
}

export function sendNotification(text: string) {
  const id = state.activeJobId;
  if (!id) return;
  const current = state.admins[id] ?? emptyAdmin();
  const note = { id: uid("n"), text, at: Date.now() };
  commit({
    ...state,
    admins: {
      ...state.admins,
      [id]: { ...current, notifications: [note, ...current.notifications].slice(0, 8) },
    },
    tab: "build",
  });
}

export function saveKey(index: number, value: string, tag: KeyTag) {
  const keys = state.secrets.keys.map((key, i) => (i === index ? { ...key, value: value.trim(), tag } : key));
  commit({ ...state, secrets: { ...state.secrets, keys } });
}

export function clearKey(index: number) {
  saveKey(index, "", "");
}

export function saveToken(index: 0 | 1, value: string) {
  const tokens: [string, string] = [...state.secrets.tokens];
  tokens[index] = value.trim();
  commit({ ...state, secrets: { ...state.secrets, tokens } });
}

export function saveVoice(value: string) {
  commit({ ...state, secrets: { ...state.secrets, voice: value.trim() } });
}

export function saveFirebase(which: "studioFb" | "appsFb", url: string, key: string) {
  const secrets = { ...state.secrets, [which]: { url: url.trim(), key: key.trim() } };
  commit({ ...state, secrets, syncNote: which === "studioFb" ? "syncing" : state.syncNote });
  if (which === "studioFb") void refreshRemote();
}

export function clearFirebase(which: "studioFb" | "appsFb") {
  saveFirebase(which, "", "");
}

export function askPilot(text: string) {
  const q = text.trim();
  if (!q) return;
  if (thinkTimer) clearTimeout(thinkTimer);
  const route = resolveDepartment("brain", state.secrets);
  const user = { id: uid("m"), role: "user" as const, text: q, at: Date.now() };
  commit(
    {
      ...state,
      thinking: true,
      routingLine: formatRoute(route, state.lang),
      messages: [...state.messages, user].slice(-80),
    },
    { remote: false },
  );
  const lang = state.lang;
  thinkTimer = setTimeout(() => {
    thinkTimer = null;
    const result = answer(lang, q, state);
    commit({
      ...state,
      thinking: false,
      draftPrompt: result.prompt ?? state.draftPrompt,
      tab: result.prompt ? "build" : state.tab,
      messages: [...state.messages, pilot(result.reply)].slice(-80),
    });
  }, 480);
}

export function runVisionCheck() {
  const job = activeJob();
  if (!job) return;
  const route = resolveDepartment("vision", state.secrets);
  const line = formatRoute(route, state.lang);
  const note =
    state.lang === "hi"
      ? `${line}. स्थानीय जांच: कंट्रास्ट ठीक है, टेस्ट कंट्रोल स्टेज ${job.stage} पर ${job.stage >= 4 ? "खुले" : "बंद"} हैं।`
      : `${line}. Local check: contrast holds, test controls are ${job.stage >= 4 ? "open" : "locked"} at stage ${job.stage}.`;
  commit({
    ...state,
    routingLine: line,
    messages: [...state.messages, pilot(note)].slice(-80),
  });
}

export function speakRoute(): string {
  return formatRoute(resolveDepartment("speak", state.secrets), state.lang);
}

export function listenRoute(): string {
  return formatRoute(resolveDepartment("listen", state.secrets), state.lang);
}

export function ensureExportClock() {
  const job = activeJob();
  if (!job) return;
  if ((job.status === "ok" || job.status === "export") && job.exportSteps.some((s) => s.state === "wait" || s.state === "run")) {
    if (!exportTimer) exportTimer = setInterval(tickExport, 700);
  }
}
