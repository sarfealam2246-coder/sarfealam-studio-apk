import type { FirebaseSlot, StudioState } from "./types";

export interface RemoteStudio {
  lang: StudioState["lang"];
  tab: StudioState["tab"];
  draftPrompt: string;
  skills: StudioState["skills"];
  jobs: StudioState["jobs"];
  activeJobId: string | null;
  admins: StudioState["admins"];
  messages: StudioState["messages"];
  updatedAt: number;
}

export function parseFirebaseConfig(text: string): Partial<FirebaseSlot> | null {
  const raw = text.trim();
  if (!raw.startsWith("{")) return null;
  try {
    const json = JSON.parse(raw) as Record<string, unknown>;
    const url = typeof json.databaseURL === "string" ? json.databaseURL : "";
    const key = typeof json.apiKey === "string" ? json.apiKey : "";
    if (!url && !key) return null;
    return { url, key };
  } catch {
    return null;
  }
}

function endpoint(slot: FirebaseSlot, path: string): string | null {
  if (!slot.url.trim() || !slot.key.trim()) return null;
  const base = slot.url.trim().replace(/\/+$/, "").replace(/\.json$/, "");
  return `${base}/${path}.json?auth=${encodeURIComponent(slot.key.trim())}`;
}

export function toRemote(state: StudioState): RemoteStudio {
  return {
    lang: state.lang,
    tab: state.tab,
    draftPrompt: state.draftPrompt,
    skills: state.skills,
    jobs: state.jobs,
    activeJobId: state.activeJobId,
    admins: state.admins,
    messages: state.messages,
    updatedAt: state.updatedAt,
  };
}

export async function pushStudio(slot: FirebaseSlot, payload: RemoteStudio): Promise<void> {
  const url = endpoint(slot, "sarfealam/state");
  if (!url) return;
  const res = await fetch(url, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw new Error(String(res.status));
}

export async function pullStudio(slot: FirebaseSlot): Promise<RemoteStudio | null> {
  const url = endpoint(slot, "sarfealam/state");
  if (!url) return null;
  const res = await fetch(url);
  if (!res.ok) throw new Error(String(res.status));
  const data = (await res.json()) as RemoteStudio | null;
  if (!data || typeof data !== "object" || !Array.isArray(data.jobs)) return null;
  return data;
}
