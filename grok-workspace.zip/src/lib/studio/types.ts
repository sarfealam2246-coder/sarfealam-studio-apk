export type Lang = "en" | "hi";

export type TabId = "pilot" | "build" | "vault" | "admin" | "skills" | "secrets";

export type KeyTag = "" | "General" | "Code" | "Fast" | "Vision" | "Primary" | "Fallback";

export type SkillId =
  | "otp"
  | "tabs"
  | "profile"
  | "search"
  | "lists"
  | "wallet"
  | "vip"
  | "maps"
  | "game3d"
  | "cards"
  | "github"
  | "assets"
  | "survivor";

export type Template =
  | "fantasy"
  | "delivery"
  | "khata"
  | "bank"
  | "shop"
  | "generic"
  | "game"
  | "card";

export type Kind = "game" | "app";

export type JobStatus = "assembling" | "ready" | "ok" | "export" | "cancelled";

export type Provider =
  | "gemini"
  | "groq"
  | "openrouter"
  | "cohere"
  | "nvidia"
  | "moonshot"
  | "deepseek";

export type Dept = "brain" | "code" | "fast" | "vision" | "listen" | "speak" | "reason";

export interface SecretKey {
  id: string;
  value: string;
  tag: KeyTag;
}

export interface FirebaseSlot {
  url: string;
  key: string;
}

export interface Secrets {
  keys: SecretKey[];
  tokens: [string, string];
  voice: string;
  studioFb: FirebaseSlot;
  appsFb: FirebaseSlot;
}

export interface SandboxItem {
  id: string;
  title: string;
  note: string;
  amount: number;
}

export interface Sandbox {
  tab: string;
  query: string;
  items: SandboxItem[];
  balance: number;
  draftTitle: string;
  draftAmount: string;
  hand: string[];
  pot: number;
  lastAction: string;
  revealed: boolean;
  vipOpen: boolean;
  otpPassed: boolean;
  otpCode: string;
  cart: number;
}

export interface Blueprint {
  title: string;
  slug: string;
  kind: Kind;
  template: Template;
  summary: string;
  skills: SkillId[];
  screens: { id: string; label: string }[];
  warnings: string[];
}

export interface ExportStep {
  id: string;
  label: string;
  state: "wait" | "run" | "done" | "skip";
}

export interface Job {
  id: string;
  prompt: string;
  createdAt: number;
  updatedAt: number;
  startedAt: number;
  status: JobStatus;
  stage: number;
  routeLabel: string;
  blueprint: Blueprint;
  sandbox: Sandbox;
  exportSteps: ExportStep[];
  announcedReady: boolean;
}

export interface AdminState {
  banner: boolean;
  bannerText: string;
  vipNote: string;
  apkLink: string;
  notifications: { id: string; text: string; at: number }[];
}

export interface PilotMessage {
  id: string;
  role: "pilot" | "user";
  text: string;
  at: number;
}

export interface StudioState {
  lang: Lang;
  welcomed: boolean;
  tab: TabId;
  draftPrompt: string;
  secrets: Secrets;
  skills: Record<SkillId, boolean>;
  jobs: Job[];
  activeJobId: string | null;
  admins: Record<string, AdminState>;
  messages: PilotMessage[];
  routingLine: string;
  thinking: boolean;
  syncNote: string;
  updatedAt: number;
  booted: boolean;
}

export interface RouteHit {
  dept: Dept;
  model: string;
  provider: string;
  fallback: boolean;
  mocked: boolean;
}
