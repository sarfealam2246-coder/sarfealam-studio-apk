import type { Job, Lang, StudioState } from "./types";
import { skillLabel } from "./i18n";

export function welcome(lang: Lang): string {
  if (lang === "hi") {
    return "सरफेआलम ऑटो-स्टूडियो में आपका स्वागत है। आज क्या बनाना है? यहाँ बताएं, या बिल्ड में लिखें।";
  }
  return "Welcome to Sarfealam Auto-Studio. What should we build today? Tell me here, or type it in Build.";
}

export function launchLine(lang: Lang, title: string, route: string): string {
  if (lang === "hi") {
    return `“${title}” बन रहा है। ${route}. पहले शेल, फिर स्क्रीन, हीरो, और कंट्रोल। एक्सपोर्ट से पहले टेस्ट — वह कदम नहीं छूटेगा।`;
  }
  return `Building “${title}”. ${route}. Shell, then screens, hero, and controls. Test comes before export — that step is not skipped.`;
}

export function readyLine(lang: Lang, title: string): string {
  if (lang === "hi") {
    return `“${title}” टेस्ट के लिए तैयार है। स्क्रीन के कंट्रोल आज़माएं। जब सही लगे तब ठीक दबाएं।`;
  }
  return `“${title}” is ready to test. Use the on-screen controls. Press OK only when it feels right.`;
}

export function resumeLine(lang: Lang, job: Job): string {
  if (job.status === "assembling") {
    return lang === "hi"
      ? `काम अभी चल रहा है: “${job.blueprint.title}” जुड़ रहा है (स्टेज ${job.stage}/5)।`
      : `Job still running: “${job.blueprint.title}” is assembling (stage ${job.stage}/5).`;
  }
  if (job.status === "ready") {
    return lang === "hi"
      ? `नतीजा तैयार है: “${job.blueprint.title}” आपके टेस्ट का इंतज़ार कर रहा है।`
      : `Result ready: “${job.blueprint.title}” is waiting for your test.`;
  }
  return lang === "hi"
    ? `“${job.blueprint.title}” तिजोरी में है। स्थिति: ${job.status}.`
    : `“${job.blueprint.title}” is in the vault. Status: ${job.status}.`;
}

export function exportLine(lang: Lang, title: string, hasToken: boolean, hasApps: boolean): string {
  if (lang === "hi") {
    return `“${title}” एक्सपोर्ट पर है। ${hasToken ? "गिटहब सूची चल रही है।" : "रिपो, पुश और एपीके के लिए टोकन 1 जोड़ें।"} ${hasApps ? "ऐप्स फायरबेस प्रोजेक्ट कॉन्फिग में जुड़ गया है।" : "ऐप्स फायरबेस खाली है — कॉन्फिग फाइल फिर भी पड़ी है।"}`;
  }
  return `“${title}” moved to export. ${hasToken ? "GitHub checklist is running." : "Add GitHub token (Token 1) for repo, push, and APK."} ${hasApps ? "Apps Firebase is injected into the project config." : "Apps Firebase slot is empty — the config file is still included."}`;
}

export function cancelLine(lang: Lang, title: string): string {
  return lang === "hi"
    ? `“${title}” रद्द हुआ। रिकॉर्ड तिजोरी में है।`
    : `“${title}” was cancelled. The vault still keeps the record.`;
}

export function fixLine(lang: Lang): string {
  return lang === "hi"
    ? "क्या बदलना है? प्रॉम्प्ट सुधारें और फिर बिल्ड शुरू करें। पिछला वर्शन तिजोरी में रहेगा।"
    : "What should change? Edit the prompt and launch again. The last version stays in the vault.";
}

export function warningLine(lang: Lang, code: string): string {
  if (code === "cards-off") {
    return lang === "hi"
      ? "कार्ड-टेबल स्किल बंद है, इसलिए यह ऐप शेल बना। स्किल्स में चालू करें।"
      : "Card-table skill is off, so this became an app shell. Turn it on in Skills.";
  }
  if (code === "game-off") {
    return lang === "hi"
      ? "3D/गेम कंट्रोल स्किल बंद है, इसलिए स्टीयरिंग नहीं बनी। स्किल्स में चालू करें।"
      : "3D/game controls are off, so steering was not built. Turn the skill on.";
  }
  return "";
}

export function answer(lang: Lang, text: string, state: StudioState): { reply: string; prompt?: string } {
  const q = text.trim();
  const lower = q.toLowerCase();
  const job = state.jobs.find((j) => j.id === state.activeJobId) ?? null;

  if (/firebase|फायरबेस/.test(lower)) {
    return {
      reply:
        lang === "hi"
          ? "स्टूडियो फायरबेस सिर्फ स्टूडियो के रिकॉर्ड रखता है। ऐप्स फायरबेस उन ऐप्स का डेटा सर्वर है जो आप बनाते हैं। दोनों सीक्रेट्स में अलग स्लॉट हैं।"
          : "Studio Firebase keeps studio records only. Apps Firebase is the data server for apps you build. They are two different slots in Secrets.",
    };
  }

  if (/vault|तिजोरी|history|इतिहास/.test(lower)) {
    const n = state.jobs.length;
    return {
      reply:
        lang === "hi"
          ? `तिजोरी में ${n} बिल्ड हैं। कोई पंक्ति खोलें, वह बिल्ड टैब पर आ जाएगा।`
          : `The vault has ${n} build${n === 1 ? "" : "s"}. Open a row and it loads on the Build tab.`,
    };
  }

  if (/status|progress|क्या हो रहा|स्थिति|stage|स्टेज/.test(lower)) {
    if (!job) {
      return {
        reply: lang === "hi" ? "अभी कोई सक्रिय बिल्ड नहीं।" : "No active build right now.",
      };
    }
    return { reply: resumeLine(lang, job) };
  }

  if (/export|github|एक्सपोर्ट|गिटहब|apk|एपीके/.test(lower)) {
    const token = state.secrets.tokens[0].trim().length > 0;
    return {
      reply:
        lang === "hi"
          ? token
            ? "टोकन 1 सेव है। ठीक दबाने के बाद रिपो, पुश और एपीके सूची चलेगी। असली पुश के लिए ज़िप गिटहब पर डालें।"
            : "टोकन 1 खाली है। एक्सपोर्ट फाइलें फिर भी बनेंगी। गिटहब सूची के लिए टोकन सेव करें।"
          : token
            ? "Token 1 is saved. After OK you get the repo, push, and APK checklist. Upload the zip to GitHub for a real push."
            : "Token 1 is empty. Export files still build. Save the GitHub token to run the checklist.",
    };
  }

  const buildIntent =
    /build|banao|बनाओ|बनाओ|बनाइए|app|game|ऐप|गेम|खाता|delivery|card/.test(lower) && q.length > 8;
  if (buildIntent) {
    return {
      reply:
        lang === "hi"
          ? "यह आइडिया बिल्ड बॉक्स में रख दिया। बिल्ड शुरू करें — पहले असेंबली, फिर आपके टेस्ट कंट्रोल, ठीक के बाद ही एक्सपोर्ट।"
          : "I placed that idea in the build box. Launch Build — assembly first, then your test controls, and export only after OK.",
      prompt: q,
    };
  }

  if (job) {
    const skills = job.blueprint.skills.map((id) => skillLabel(id, lang)).join(", ");
    return {
      reply:
        lang === "hi"
          ? `सक्रिय काम “${job.blueprint.title}” है। स्किल्स: ${skills || "शेल"}. और बताएं, या बिल्ड टैब खोलें।`
          : `Active job is “${job.blueprint.title}”. Skills: ${skills || "shell"}. Say more, or open Build.`,
    };
  }

  return {
    reply:
      lang === "hi"
        ? "कोई भी आइडिया चलता है — गेम, खाता, डिलीवरी, कार्ड, या कुछ और। बिल्ड में लिखें और शुरू करें। मैं भाषा स्विच के साथ यही रहूँगा।"
        : "Any idea is valid — a game, a khata book, delivery, cards, or something else. Type it in Build and launch. I stay with the language switch.",
  };
}
