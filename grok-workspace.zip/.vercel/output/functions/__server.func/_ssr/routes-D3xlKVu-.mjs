import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Shield, c as MessageCircle, d as Archive, i as SlidersHorizontal, l as KeyRound, o as Send, r as Square, s as Mic, t as Volume2, u as Blocks } from "../_libs/lucide-react.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D3xlKVu-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var copy = {
	en: {
		wordmark: "Sarfealam",
		product: "Auto-Studio",
		tagline: "Type any idea. Assemble it. Test it. Then export.",
		tabs: {
			pilot: "Co-Pilot",
			build: "Build",
			vault: "Vault",
			admin: "Admin",
			skills: "Skills",
			secrets: "Secrets"
		},
		langEn: "English",
		langHi: "Hindi",
		promptPh: "Type to Build…",
		launch: "Launch Build",
		ok: "OK — Continue to Export",
		fix: "Fix / Change",
		cancel: "Cancel",
		download: "Download project zip",
		stages: [
			"Shell & theme",
			"Screens or world",
			"Hero or main UI",
			"Controls & HUD",
			"Ready to test"
		],
		examples: "Examples",
		skillsUsed: "Skills applied",
		testHint: "Test controls are live. Try them before OK.",
		testLocked: "Controls unlock at stage 4.",
		exportTitle: "Export",
		githubTitle: "GitHub path",
		emptyVault: "No builds yet. Launch one from Build.",
		syncLocal: "Saved on this device. Will sync when Studio Firebase is connected.",
		syncOn: "Studio Firebase connected. Records reload on return.",
		syncErr: "Studio Firebase did not respond. This device copy is safe.",
		secretsHelp: "Studio Firebase = studio records only. Apps Firebase = data server for apps you build. Keys/tokens saved until you delete them.",
		adminNote: "Public users get the app. You control live options here.",
		noJob: "Select a build in Vault, or launch one.",
		banner: "Banner",
		sendNote: "Send mock notification",
		vip: "VIP / plan note",
		apk: "Public APK link",
		skillsLead: "Capabilities, not brand names. The pipeline uses a skill only when it is on and the prompt asks for it.",
		survivorNote: "Progress still stays on this device either way. This switch shows the return banner.",
		listening: "Listening…",
		mic: "Mic",
		stopMic: "Stop",
		send: "Send",
		speak: "Speak",
		typePilot: "Message the co-pilot…",
		uiCheck: "Run UI check",
		lastInput: "Last input",
		gas: "Gas",
		brake: "Brake",
		left: "Left",
		right: "Right",
		deal: "Deal",
		draw: "Draw",
		add: "Add",
		search: "Search",
		amount: "Amount",
		name: "Name",
		reveal: "Reveal",
		unlock: "Unlock VIP",
		otp: "Continue",
		cart: "Add to cart",
		book: "Book slot",
		transfer: "Transfer",
		readyBadge: "Ready to test",
		assembling: "Assembling",
		kindGame: "Game",
		kindApp: "App",
		fileList: "Project files",
		injected: "Apps Firebase injected",
		missingApps: "Apps Firebase slot empty — config file is still included.",
		resumeRun: "Job still running",
		resumeReady: "Result ready",
		pasteJson: "Paste Firebase config JSON",
		applyJson: "Apply JSON",
		save: "Save",
		edit: "Edit",
		del: "Delete",
		emptySlot: "Empty — paste and save",
		detected: "Detected",
		unrecognized: "Unrecognized prefix — tag still saved, routing skips it",
		token1: "Token 1 · GitHub",
		token2: "Token 2 · optional",
		voice: "Voice",
		studioFb: "Studio Firebase",
		appsFb: "Apps Firebase",
		url: "Database URL",
		fbKey: "Key / secret",
		keyTag: "Tag",
		providerLine: "AI routing",
		none: "None yet",
		profile: "Profile",
		wallet: "Wallet",
		home: "Home",
		map: "Map",
		list: "List",
		signIn: "Phone OTP",
		codePh: "6-digit code",
		demoCode: "Demo code is 248163",
		balance: "Balance",
		zone: "Zone grid",
		hand: "Your hand",
		pot: "Pot",
		speed: "Speed",
		steer: "Steer",
		assetHint: "Open-source hint: Kenney CC0 and OFL fonts. Keep license files in the repo.",
		fixPrompt: "Edit the prompt and launch again. The previous build stays in the vault."
	},
	hi: {
		wordmark: "सरफेआलम",
		product: "ऑटो-स्टूडियो",
		tagline: "कोई भी आइडिया लिखें। जोड़ें। टेस्ट करें। फिर एक्सपोर्ट।",
		tabs: {
			pilot: "को-पायलट",
			build: "बिल्ड",
			vault: "तिजोरी",
			admin: "एडमिन",
			skills: "स्किल्स",
			secrets: "सीक्रेट्स"
		},
		langEn: "English",
		langHi: "हिंदी",
		promptPh: "बिल्ड के लिए लिखें…",
		launch: "बिल्ड शुरू करें",
		ok: "ठीक — एक्सपोर्ट पर जाएं",
		fix: "सुधार / बदलें",
		cancel: "रद्द",
		download: "प्रोजेक्ट ज़िप डाउनलोड",
		stages: [
			"शेल और थीम",
			"स्क्रीन या दुनिया",
			"हीरो या मुख्य यूआई",
			"कंट्रोल और एचयूडी",
			"टेस्ट के लिए तैयार"
		],
		examples: "उदाहरण",
		skillsUsed: "लगी हुई स्किल्स",
		testHint: "टेस्ट कंट्रोल चालू हैं। ठीक दबाने से पहले आज़माएं।",
		testLocked: "कंट्रोल स्टेज 4 पर खुलेंगे।",
		exportTitle: "एक्सपोर्ट",
		githubTitle: "गिटहब पथ",
		emptyVault: "अभी कोई बिल्ड नहीं। बिल्ड से शुरू करें।",
		syncLocal: "इस डिवाइस पर सेव है। स्टूडियो फायरबेस जुड़ने पर सिंक होगा।",
		syncOn: "स्टूडियो फायरबेस जुड़ा है। वापसी पर रिकॉर्ड लोड होंगे।",
		syncErr: "स्टूडियो फायरबेस ने जवाब नहीं दिया। डिवाइस कॉपी सुरक्षित है।",
		secretsHelp: "Studio Firebase = studio records only. Apps Firebase = data server for apps you build. Keys/tokens saved until you delete them.",
		adminNote: "पब्लिक यूज़र को ऐप मिलता है। लाइव विकल्प यहीं आपके पास हैं।",
		noJob: "तिजोरी से बिल्ड चुनें, या नया शुरू करें।",
		banner: "बैनर",
		sendNote: "नकली सूचना भेजें",
		vip: "वीआईपी / प्लान नोट",
		apk: "पब्लिक एपीके लिंक",
		skillsLead: "ये क्षमताएं हैं, मशहूर ऐप के नाम नहीं। स्किल तभी लगेगी जब वह चालू हो और प्रॉम्प्ट मांगे।",
		survivorNote: "प्रगति दोनों हालत में इस डिवाइस पर रहती है। यह स्विच वापसी का बैनर दिखाता है।",
		listening: "सुन रहा है…",
		mic: "माइक",
		stopMic: "रोकें",
		send: "भेजें",
		speak: "बोलें",
		typePilot: "को-पायलट को लिखें…",
		uiCheck: "यूआई जांच",
		lastInput: "आखिरी इनपुट",
		gas: "गैस",
		brake: "ब्रेक",
		left: "बाएं",
		right: "दाएं",
		deal: "डील",
		draw: "कार्ड खींचें",
		add: "जोड़ें",
		search: "खोज",
		amount: "रकम",
		name: "नाम",
		reveal: "खोलें",
		unlock: "वीआईपी खोलें",
		otp: "आगे बढ़ें",
		cart: "कार्ट में डालें",
		book: "स्लॉट बुक करें",
		transfer: "ट्रांसफर",
		readyBadge: "टेस्ट के लिए तैयार",
		assembling: "जुड़ रहा है",
		kindGame: "गेम",
		kindApp: "ऐप",
		fileList: "प्रोजेक्ट फाइलें",
		injected: "ऐप्स फायरबेस जोड़ दिया गया",
		missingApps: "ऐप्स फायरबेस खाली है — कॉन्फिग फाइल फिर भी शामिल है।",
		resumeRun: "काम अभी चल रहा है",
		resumeReady: "नतीजा तैयार है",
		pasteJson: "फायरबेस कॉन्फिग JSON चिपकाएं",
		applyJson: "JSON लगाएं",
		save: "सेव",
		edit: "एडिट",
		del: "हटाएं",
		emptySlot: "खाली — चिपकाएं और सेव करें",
		detected: "पहचाना",
		unrecognized: "अनजाना प्रीफिक्स — टैग सेव है, रूटिंग इसे छोड़ देगी",
		token1: "टोकन 1 · गिटहब",
		token2: "टोकन 2 · वैकल्पिक",
		voice: "वॉइस",
		studioFb: "स्टूडियो फायरबेस",
		appsFb: "ऐप्स फायरबेस",
		url: "डेटाबेस URL",
		fbKey: "की / सीक्रेट",
		keyTag: "टैग",
		providerLine: "एआई रूटिंग",
		none: "अभी कुछ नहीं",
		profile: "प्रोफाइल",
		wallet: "वॉलेट",
		home: "होम",
		map: "मैप",
		list: "सूची",
		signIn: "फोन ओटीपी",
		codePh: "6 अंकों का कोड",
		demoCode: "डेमो कोड 248163 है",
		balance: "बैलेंस",
		zone: "ज़ोन ग्रिड",
		hand: "आपके कार्ड",
		pot: "पॉट",
		speed: "स्पीड",
		steer: "स्टीयर",
		assetHint: "ओपन-सोर्स संकेत: Kenney CC0 और OFL फॉन्ट। लाइसेंस फाइलें रिपो में रखें।",
		fixPrompt: "प्रॉम्प्ट बदलकर फिर लॉन्च करें। पिछला बिल्ड तिजोरी में रहेगा।"
	}
};
function t(lang) {
	return copy[lang];
}
var skillNames = {
	otp: {
		en: "Gmail / phone OTP auth",
		hi: "जीमेल / फोन ओटीपी",
		blurbEn: "A gate before the main screens.",
		blurbHi: "मुख्य स्क्रीन से पहले एक गेट।"
	},
	tabs: {
		en: "Bottom navigation",
		hi: "निचला नेविगेशन",
		blurbEn: "Thumb-reach tabs on app shells.",
		blurbHi: "ऐप शेल पर अंगूठे वाले टैब।"
	},
	profile: {
		en: "Profile",
		hi: "प्रोफाइल",
		blurbEn: "Name and plan on a profile screen.",
		blurbHi: "प्रोफाइल स्क्रीन पर नाम और प्लान।"
	},
	search: {
		en: "Search",
		hi: "खोज",
		blurbEn: "Filter lists from a search field.",
		blurbHi: "खोज से सूचियां छानें।"
	},
	lists: {
		en: "Lists & forms",
		hi: "सूचियां और फॉर्म",
		blurbEn: "Add and scan rows.",
		blurbHi: "पंक्तियां जोड़ें और देखें।"
	},
	wallet: {
		en: "Wallet / balance",
		hi: "वॉलेट / बैलेंस",
		blurbEn: "A balance that changes when you act.",
		blurbHi: "काम करने पर बदलने वाला बैलेंस।"
	},
	vip: {
		en: "VIP-plan unlock",
		hi: "वीआईपी प्लान",
		blurbEn: "A locked plan the owner can note in Admin.",
		blurbHi: "बंद प्लान, एडमिन में नोट के साथ।"
	},
	maps: {
		en: "Maps / booking style",
		hi: "मैप / बुकिंग",
		blurbEn: "Zones and a booking action.",
		blurbHi: "ज़ोन और बुकिंग बटन।"
	},
	game3d: {
		en: "3D / game preview controls",
		hi: "3D / गेम कंट्रोल",
		blurbEn: "Steer, gas, and brake on a chase view.",
		blurbHi: "चेज़ व्यू पर स्टीयर, गैस, ब्रेक।"
	},
	cards: {
		en: "Card-table logic",
		hi: "कार्ड टेबल",
		blurbEn: "Deal and draw on a table.",
		blurbHi: "टेबल पर डील और ड्रॉ।"
	},
	github: {
		en: "GitHub export",
		hi: "गिटहब एक्सपोर्ट",
		blurbEn: "Repo, push, and APK checklist after OK.",
		blurbHi: "ठीक के बाद रिपो, पुश, और एपीके सूची।"
	},
	assets: {
		en: "Open-source asset hint",
		hi: "ओपन-सोर्स संकेत",
		blurbEn: "License reminder inside the export.",
		blurbHi: "एक्सपोर्ट में लाइसेंस याददिलाना।"
	},
	survivor: {
		en: "Background job survivor",
		hi: "बैकग्राउंड जॉब",
		blurbEn: "Show a banner when a job is still running.",
		blurbHi: "चलते काम पर वापसी का बैनर।"
	}
};
function skillLabel(id, lang) {
	return lang === "hi" ? skillNames[id].hi : skillNames[id].en;
}
function skillBlurb(id, lang) {
	return lang === "hi" ? skillNames[id].blurbHi : skillNames[id].blurbEn;
}
var SKILL_ORDER = [
	"otp",
	"tabs",
	"profile",
	"search",
	"lists",
	"wallet",
	"vip",
	"maps",
	"game3d",
	"cards",
	"github",
	"assets",
	"survivor"
];
function statusLabel(status, lang) {
	const map = {
		assembling: ["Assembling", "जुड़ रहा है"],
		ready: ["Ready to test", "टेस्ट के लिए तैयार"],
		ok: ["OK", "ठीक"],
		export: ["Export ready", "एक्सपोर्ट तैयार"],
		cancelled: ["Cancelled", "रद्द"]
	};
	return lang === "hi" ? map[status][1] : map[status][0];
}
var CHIPS = [
	{
		id: "fantasy",
		labelEn: "Fantasy app",
		labelHi: "फैंटेसी ऐप",
		promptEn: "Fantasy prediction app with a match list and reveal",
		promptHi: "फैंटेसी भविष्यवाणी ऐप, मैच सूची और रिवील"
	},
	{
		id: "vehicle",
		labelEn: "3D vehicle game",
		labelHi: "3D वाहन गेम",
		promptEn: "3D vehicle game with steering, gas and brake",
		promptHi: "3D गाड़ी गेम, स्टीयरिंग, गैस और ब्रेक"
	},
	{
		id: "khata",
		labelEn: "Khata book",
		labelHi: "खाता बही",
		promptEn: "Khata book for udhar and jama with balance",
		promptHi: "खाता बही, उधार और जमा, बैलेंस के साथ"
	},
	{
		id: "cards",
		labelEn: "Card table",
		labelHi: "कार्ड टेबल",
		promptEn: "Card table game like teen patti with deal and draw",
		promptHi: "तीन पत्ती जैसी कार्ड टेबल, डील और ड्रॉ"
	},
	{
		id: "delivery",
		labelEn: "Delivery app",
		labelHi: "डिलीवरी ऐप",
		promptEn: "Delivery app with booking, zones and order list",
		promptHi: "डिलीवरी ऐप, बुकिंग, ज़ोन और ऑर्डर सूची"
	}
];
var ALL_ON = {
	otp: true,
	tabs: true,
	profile: true,
	search: true,
	lists: true,
	wallet: true,
	vip: true,
	maps: true,
	game3d: true,
	cards: true,
	github: true,
	assets: true,
	survivor: true
};
function defaultSkills() {
	return { ...ALL_ON };
}
function has(p, words) {
	return words.some((w) => p.includes(w));
}
function makeBlueprint(prompt, toggles) {
	const p = prompt.toLowerCase();
	const warnings = [];
	const wantsCard = has(p, [
		"card",
		"patti",
		"rummy",
		"poker",
		"ताश",
		"पत्ती",
		"रम्मी",
		"कार्ड"
	]);
	const wantsGame = has(p, [
		"game",
		"3d",
		"vehicle",
		"car",
		"race",
		"steer",
		"drive",
		"गेम",
		"गाड़ी",
		"रेस",
		"कार",
		"वाहन"
	]);
	let template = "generic";
	let kind = "app";
	if (wantsCard) {
		if (toggles.cards) {
			template = "card";
			kind = "game";
		} else warnings.push("cards-off");
	} else if (wantsGame) {
		if (toggles.game3d) {
			template = "game";
			kind = "game";
		} else warnings.push("game-off");
	} else if (has(p, [
		"khata",
		"ledger",
		"udhar",
		"खाता",
		"खता",
		"उधार",
		"बही",
		"jama",
		"जमा"
	])) template = "khata";
	else if (has(p, [
		"deliver",
		"order",
		"rider",
		"booking",
		"डिलीवरी",
		"ऑर्डर",
		"बुकिंग"
	])) template = "delivery";
	else if (has(p, [
		"bank",
		"upi",
		"transfer",
		"wallet",
		"balance",
		"बैंक",
		"वॉलेट",
		"बैलेंस"
	])) template = "bank";
	else if (has(p, [
		"shop",
		"store",
		"cart",
		"ecommerce",
		"e-commerce",
		"दुकान",
		"कार्ट"
	])) template = "shop";
	else if (has(p, [
		"fantasy",
		"predict",
		"भविष्य",
		"फैंटेसी",
		"prediction"
	])) template = "fantasy";
	const skills = [];
	const add = (id, when) => {
		if (when && toggles[id] && !skills.includes(id)) skills.push(id);
	};
	if (kind === "game" && template === "game") add("game3d", true);
	if (kind === "game" && template === "card") add("cards", true);
	if (kind === "app") {
		add("tabs", true);
		add("lists", template !== "bank");
		add("search", toggles.search && (template === "shop" || template === "delivery" || template === "fantasy" || has(p, ["search", "खोज"])));
		add("profile", toggles.profile && (template !== "fantasy" || has(p, [
			"profile",
			"प्रोफाइल",
			"login",
			"account"
		])));
		add("wallet", template === "khata" || template === "bank" || has(p, [
			"wallet",
			"balance",
			"वॉलेट",
			"बैलेंस"
		]));
		add("maps", template === "delivery" || has(p, [
			"map",
			"zone",
			"मैप",
			"ज़ोन"
		]));
		add("vip", has(p, [
			"vip",
			"plan",
			"premium",
			"वीआईपी",
			"प्लान"
		]));
		add("otp", has(p, [
			"otp",
			"login",
			"sign in",
			"signin",
			"gmail",
			"auth",
			"लॉगिन",
			"ओटीपी"
		]));
		if (template === "shop") add("search", true);
		if (template === "bank" || template === "khata") add("wallet", true);
		if (template === "delivery") add("maps", true);
		if (template === "fantasy" || template === "shop" || template === "generic" || template === "khata" || template === "delivery") add("lists", true);
		if (!skills.includes("profile") && toggles.profile && (template === "generic" || template === "bank" || template === "shop")) add("profile", true);
	}
	add("github", toggles.github);
	add("assets", toggles.assets);
	add("survivor", toggles.survivor);
	const title = titleFrom(prompt, template);
	const screens = screensFor(template, skills);
	return {
		title,
		slug: slugify(title),
		kind,
		template,
		summary: summaryFor(template),
		skills,
		screens,
		warnings
	};
}
function titleFrom(prompt, template) {
	const clean = prompt.replace(/\s+/g, " ").trim();
	if (clean.length > 0 && clean.length <= 48) return clean;
	if (clean.length > 48) return clean.slice(0, 46).trimEnd() + "…";
	return template;
}
function slugify(title) {
	return title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 28) || "sarfealam-app";
}
function summaryFor(template) {
	switch (template) {
		case "game": return "Chase-view vehicle. Steer, gas, brake.";
		case "card": return "Three-card table. Deal and draw.";
		case "khata": return "Udhar and jama with a running balance.";
		case "delivery": return "Orders, zones, and a booking action.";
		case "bank": return "Balance hero and a transfer form.";
		case "shop": return "Catalog, search, and cart.";
		case "fantasy": return "Match list and a reveal.";
		default: return "Shell, list, and a working form.";
	}
}
function screensFor(template, skills) {
	if (template === "game") return [{
		id: "world",
		label: "World"
	}];
	if (template === "card") return [{
		id: "table",
		label: "Table"
	}];
	const screens = [{
		id: "home",
		label: "Home"
	}];
	if (skills.includes("lists") || skills.includes("search")) screens.push({
		id: "list",
		label: "List"
	});
	if (skills.includes("maps")) screens.push({
		id: "map",
		label: "Map"
	});
	if (skills.includes("wallet")) screens.push({
		id: "wallet",
		label: "Wallet"
	});
	if (skills.includes("profile")) screens.push({
		id: "profile",
		label: "Profile"
	});
	return screens;
}
function seedSandbox(bp) {
	const base = {
		tab: bp.screens[0]?.id ?? "home",
		query: "",
		items: [],
		balance: 0,
		draftTitle: "",
		draftAmount: "",
		hand: [],
		pot: 0,
		lastAction: "",
		revealed: false,
		vipOpen: false,
		otpPassed: !bp.skills.includes("otp"),
		otpCode: "",
		cart: 0
	};
	if (bp.template === "khata") {
		base.items = [{
			id: "k1",
			title: "Ravi",
			note: "udhar",
			amount: 500
		}, {
			id: "k2",
			title: "Meena",
			note: "jama",
			amount: -200
		}];
		base.balance = 300;
	} else if (bp.template === "delivery") {
		base.items = [{
			id: "d1",
			title: "Parcel · Sector 12",
			note: "Out for drop",
			amount: 80
		}, {
			id: "d2",
			title: "Parcel · Civil Lines",
			note: "Booked",
			amount: 60
		}];
		base.balance = 140;
	} else if (bp.template === "bank") {
		base.balance = 12450;
		base.items = [{
			id: "b1",
			title: "Opening",
			note: "credit",
			amount: 12450
		}];
	} else if (bp.template === "shop") base.items = [
		{
			id: "s1",
			title: "Linen shirt",
			note: "Cloth",
			amount: 890
		},
		{
			id: "s2",
			title: "Clay cup set",
			note: "Home",
			amount: 420
		},
		{
			id: "s3",
			title: "Ink notebook",
			note: "Paper",
			amount: 160
		}
	];
	else if (bp.template === "fantasy") base.items = [
		{
			id: "f1",
			title: "Night derby",
			note: "Open",
			amount: 0
		},
		{
			id: "f2",
			title: "River final",
			note: "Open",
			amount: 0
		},
		{
			id: "f3",
			title: "City cup",
			note: "Locked",
			amount: 0
		}
	];
	else if (bp.template === "generic") base.items = [{
		id: "g1",
		title: "First screen",
		note: "Shell",
		amount: 0
	}, {
		id: "g2",
		title: "Main action",
		note: "Ready",
		amount: 0
	}];
	else if (bp.template === "card") {
		base.pot = 40;
		base.hand = dealHand(bp.title, 3);
	}
	return base;
}
var RANKS = [
	"A",
	"K",
	"Q",
	"J",
	"10",
	"9",
	"8",
	"7",
	"6",
	"5",
	"4",
	"3",
	"2"
];
var SUITS = [
	"S",
	"H",
	"D",
	"C"
];
function hash(s) {
	let h = 2166136261;
	for (let i = 0; i < s.length; i++) {
		h ^= s.charCodeAt(i);
		h = Math.imul(h, 16777619);
	}
	return h >>> 0;
}
function dealHand(seed, n) {
	const used = /* @__PURE__ */ new Set();
	const cards = [];
	let x = hash(seed);
	while (cards.length < n) {
		x = Math.imul(x, 1664525) + 1013904223 >>> 0;
		const card = `${RANKS[x % RANKS.length]}${SUITS[(x >>> 8) % SUITS.length]}`;
		if (used.has(card)) continue;
		used.add(card);
		cards.push(card);
	}
	return cards;
}
function rankValue(card) {
	const r = card.replace(/[SHDC]$/, "");
	return [
		"2",
		"3",
		"4",
		"5",
		"6",
		"7",
		"8",
		"9",
		"10",
		"J",
		"Q",
		"K",
		"A"
	].indexOf(r);
}
function welcome(lang) {
	if (lang === "hi") return "सरफेआलम ऑटो-स्टूडियो में आपका स्वागत है। आज क्या बनाना है? यहाँ बताएं, या बिल्ड में लिखें।";
	return "Welcome to Sarfealam Auto-Studio. What should we build today? Tell me here, or type it in Build.";
}
function launchLine(lang, title, route) {
	if (lang === "hi") return `“${title}” बन रहा है। ${route}. पहले शेल, फिर स्क्रीन, हीरो, और कंट्रोल। एक्सपोर्ट से पहले टेस्ट — वह कदम नहीं छूटेगा।`;
	return `Building “${title}”. ${route}. Shell, then screens, hero, and controls. Test comes before export — that step is not skipped.`;
}
function readyLine(lang, title) {
	if (lang === "hi") return `“${title}” टेस्ट के लिए तैयार है। स्क्रीन के कंट्रोल आज़माएं। जब सही लगे तब ठीक दबाएं।`;
	return `“${title}” is ready to test. Use the on-screen controls. Press OK only when it feels right.`;
}
function resumeLine(lang, job) {
	if (job.status === "assembling") return lang === "hi" ? `काम अभी चल रहा है: “${job.blueprint.title}” जुड़ रहा है (स्टेज ${job.stage}/5)।` : `Job still running: “${job.blueprint.title}” is assembling (stage ${job.stage}/5).`;
	if (job.status === "ready") return lang === "hi" ? `नतीजा तैयार है: “${job.blueprint.title}” आपके टेस्ट का इंतज़ार कर रहा है।` : `Result ready: “${job.blueprint.title}” is waiting for your test.`;
	return lang === "hi" ? `“${job.blueprint.title}” तिजोरी में है। स्थिति: ${job.status}.` : `“${job.blueprint.title}” is in the vault. Status: ${job.status}.`;
}
function exportLine(lang, title, hasToken, hasApps) {
	if (lang === "hi") return `“${title}” एक्सपोर्ट पर है। ${hasToken ? "गिटहब सूची चल रही है।" : "रिपो, पुश और एपीके के लिए टोकन 1 जोड़ें।"} ${hasApps ? "ऐप्स फायरबेस प्रोजेक्ट कॉन्फिग में जुड़ गया है।" : "ऐप्स फायरबेस खाली है — कॉन्फिग फाइल फिर भी पड़ी है।"}`;
	return `“${title}” moved to export. ${hasToken ? "GitHub checklist is running." : "Add GitHub token (Token 1) for repo, push, and APK."} ${hasApps ? "Apps Firebase is injected into the project config." : "Apps Firebase slot is empty — the config file is still included."}`;
}
function cancelLine(lang, title) {
	return lang === "hi" ? `“${title}” रद्द हुआ। रिकॉर्ड तिजोरी में है।` : `“${title}” was cancelled. The vault still keeps the record.`;
}
function fixLine(lang) {
	return lang === "hi" ? "क्या बदलना है? प्रॉम्प्ट सुधारें और फिर बिल्ड शुरू करें। पिछला वर्शन तिजोरी में रहेगा।" : "What should change? Edit the prompt and launch again. The last version stays in the vault.";
}
function warningLine(lang, code) {
	if (code === "cards-off") return lang === "hi" ? "कार्ड-टेबल स्किल बंद है, इसलिए यह ऐप शेल बना। स्किल्स में चालू करें।" : "Card-table skill is off, so this became an app shell. Turn it on in Skills.";
	if (code === "game-off") return lang === "hi" ? "3D/गेम कंट्रोल स्किल बंद है, इसलिए स्टीयरिंग नहीं बनी। स्किल्स में चालू करें।" : "3D/game controls are off, so steering was not built. Turn the skill on.";
	return "";
}
function answer(lang, text, state) {
	const q = text.trim();
	const lower = q.toLowerCase();
	const job = state.jobs.find((j) => j.id === state.activeJobId) ?? null;
	if (/firebase|फायरबेस/.test(lower)) return { reply: lang === "hi" ? "स्टूडियो फायरबेस सिर्फ स्टूडियो के रिकॉर्ड रखता है। ऐप्स फायरबेस उन ऐप्स का डेटा सर्वर है जो आप बनाते हैं। दोनों सीक्रेट्स में अलग स्लॉट हैं।" : "Studio Firebase keeps studio records only. Apps Firebase is the data server for apps you build. They are two different slots in Secrets." };
	if (/vault|तिजोरी|history|इतिहास/.test(lower)) {
		const n = state.jobs.length;
		return { reply: lang === "hi" ? `तिजोरी में ${n} बिल्ड हैं। कोई पंक्ति खोलें, वह बिल्ड टैब पर आ जाएगा।` : `The vault has ${n} build${n === 1 ? "" : "s"}. Open a row and it loads on the Build tab.` };
	}
	if (/status|progress|क्या हो रहा|स्थिति|stage|स्टेज/.test(lower)) {
		if (!job) return { reply: lang === "hi" ? "अभी कोई सक्रिय बिल्ड नहीं।" : "No active build right now." };
		return { reply: resumeLine(lang, job) };
	}
	if (/export|github|एक्सपोर्ट|गिटहब|apk|एपीके/.test(lower)) {
		const token = state.secrets.tokens[0].trim().length > 0;
		return { reply: lang === "hi" ? token ? "टोकन 1 सेव है। ठीक दबाने के बाद रिपो, पुश और एपीके सूची चलेगी। असली पुश के लिए ज़िप गिटहब पर डालें।" : "टोकन 1 खाली है। एक्सपोर्ट फाइलें फिर भी बनेंगी। गिटहब सूची के लिए टोकन सेव करें।" : token ? "Token 1 is saved. After OK you get the repo, push, and APK checklist. Upload the zip to GitHub for a real push." : "Token 1 is empty. Export files still build. Save the GitHub token to run the checklist." };
	}
	if (/build|banao|बनाओ|बनाओ|बनाइए|app|game|ऐप|गेम|खाता|delivery|card/.test(lower) && q.length > 8) return {
		reply: lang === "hi" ? "यह आइडिया बिल्ड बॉक्स में रख दिया। बिल्ड शुरू करें — पहले असेंबली, फिर आपके टेस्ट कंट्रोल, ठीक के बाद ही एक्सपोर्ट।" : "I placed that idea in the build box. Launch Build — assembly first, then your test controls, and export only after OK.",
		prompt: q
	};
	if (job) {
		const skills = job.blueprint.skills.map((id) => skillLabel(id, lang)).join(", ");
		return { reply: lang === "hi" ? `सक्रिय काम “${job.blueprint.title}” है। स्किल्स: ${skills || "शेल"}. और बताएं, या बिल्ड टैब खोलें।` : `Active job is “${job.blueprint.title}”. Skills: ${skills || "shell"}. Say more, or open Build.` };
	}
	return { reply: lang === "hi" ? "कोई भी आइडिया चलता है — गेम, खाता, डिलीवरी, कार्ड, या कुछ और। बिल्ड में लिखें और शुरू करें। मैं भाषा स्विच के साथ यही रहूँगा।" : "Any idea is valid — a game, a khata book, delivery, cards, or something else. Type it in Build and launch. I stay with the language switch." };
}
function parseFirebaseConfig(text) {
	const raw = text.trim();
	if (!raw.startsWith("{")) return null;
	try {
		const json = JSON.parse(raw);
		const url = typeof json.databaseURL === "string" ? json.databaseURL : "";
		const key = typeof json.apiKey === "string" ? json.apiKey : "";
		if (!url && !key) return null;
		return {
			url,
			key
		};
	} catch {
		return null;
	}
}
function endpoint(slot, path) {
	if (!slot.url.trim() || !slot.key.trim()) return null;
	return `${slot.url.trim().replace(/\/+$/, "").replace(/\.json$/, "")}/${path}.json?auth=${encodeURIComponent(slot.key.trim())}`;
}
function toRemote(state) {
	return {
		lang: state.lang,
		tab: state.tab,
		draftPrompt: state.draftPrompt,
		skills: state.skills,
		jobs: state.jobs,
		activeJobId: state.activeJobId,
		admins: state.admins,
		messages: state.messages,
		updatedAt: state.updatedAt
	};
}
async function pushStudio(slot, payload) {
	const url = endpoint(slot, "sarfealam/state");
	if (!url) return;
	const res = await fetch(url, {
		method: "PUT",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(payload)
	});
	if (!res.ok) throw new Error(String(res.status));
}
async function pullStudio(slot) {
	const url = endpoint(slot, "sarfealam/state");
	if (!url) return null;
	const res = await fetch(url);
	if (!res.ok) throw new Error(String(res.status));
	const data = await res.json();
	if (!data || typeof data !== "object" || !Array.isArray(data.jobs)) return null;
	return data;
}
var CHAINS = {
	brain: [
		{
			label: "Gemini 2.5 Flash",
			provider: "gemini"
		},
		{
			label: "Groq gpt-oss-120b",
			provider: "groq"
		},
		{
			label: "Llama 3.3 70B Instruct",
			provider: "groq"
		},
		{
			label: "Moonshot Kimi K3.1 Pro",
			provider: "moonshot"
		},
		{
			label: "Cohere command-a-03-2025",
			provider: "cohere"
		},
		{
			label: "OpenRouter free",
			provider: "openrouter"
		},
		{
			label: "Mixtral 8x22B",
			provider: "groq"
		}
	],
	code: [
		{
			label: "Qwen 2.5 Coder 32B",
			provider: "groq"
		},
		{
			label: "DeepSeek V4.1 Flash",
			provider: "deepseek"
		},
		{
			label: "Gemini 2.5 Flash",
			provider: "gemini"
		},
		{
			label: "Groq gpt-oss-120b",
			provider: "groq"
		},
		{
			label: "Nemotron Super 49B",
			provider: "nvidia"
		}
	],
	fast: [
		{
			label: "DeepSeek V4.1 Flash",
			provider: "deepseek"
		},
		{
			label: "Nemotron 3.5 Lightning",
			provider: "nvidia"
		},
		{
			label: "Groq gpt-oss-120b",
			provider: "groq"
		},
		{
			label: "OpenRouter free",
			provider: "openrouter"
		},
		{
			label: "Mixtral 8x22B",
			provider: "groq"
		}
	],
	vision: [{
		label: "Nemotron Nano 12B VL",
		provider: "nvidia"
	}, {
		label: "Gemini 2.5 Flash vision",
		provider: "gemini"
	}],
	listen: [{
		label: "Groq Whisper large-v3-turbo",
		provider: "groq"
	}, {
		label: "NVIDIA Parakeet",
		provider: "nvidia"
	}],
	speak: [{
		label: "NVIDIA Magpie",
		provider: "nvidia"
	}],
	reason: [
		{
			label: "DeepSeek R1",
			provider: "deepseek"
		},
		{
			label: "Llama 3.3 70B",
			provider: "groq"
		},
		{
			label: "Nemotron Super 49B",
			provider: "nvidia"
		},
		{
			label: "Kimi K3.1 Pro",
			provider: "moonshot"
		}
	]
};
var DEPT_LABEL = {
	brain: "Brain",
	code: "Code",
	fast: "Fast",
	vision: "Vision",
	listen: "Listen",
	speak: "Speak",
	reason: "Reason"
};
function detectProvider(value) {
	const v = value.trim();
	if (!v) return null;
	if (v.startsWith("AIza")) return "gemini";
	if (v.startsWith("gsk_")) return "groq";
	if (v.startsWith("sk-or-")) return "openrouter";
	if (v.startsWith("nvapi-")) return "nvidia";
	if (v.startsWith("cohere-") || v.startsWith("co-")) return "cohere";
	if (v.startsWith("sk-ds-") || v.startsWith("ds-")) return "deepseek";
	if (v.startsWith("sk-") && v.length > 12) return "moonshot";
	return null;
}
function tagAllows(tag, dept) {
	if (tag === "" || tag === "Primary" || tag === "Fallback") return true;
	if (tag === "General") return dept === "brain" || dept === "reason" || dept === "fast";
	if (tag === "Code") return dept === "code";
	if (tag === "Fast") return dept === "fast";
	if (tag === "Vision") return dept === "vision";
	return false;
}
function usableKeys(secrets, dept) {
	const list = [];
	for (const key of secrets.keys) {
		const provider = detectProvider(key.value);
		if (!provider) continue;
		if (!tagAllows(key.tag, dept)) continue;
		list.push({
			provider,
			tag: key.tag
		});
	}
	if (dept === "listen" || dept === "speak") {
		const provider = detectProvider(secrets.voice);
		if (provider && (provider === "groq" || provider === "nvidia")) list.push({
			provider,
			tag: "Primary"
		});
	}
	return list;
}
function resolveDepartment(dept, secrets) {
	const chain = CHAINS[dept];
	const keys = usableKeys(secrets, dept);
	for (let i = 0; i < chain.length; i++) {
		const model = chain[i];
		if (!model) continue;
		if (keys.find((k) => k.provider === model.provider)) return {
			dept,
			model: model.label,
			provider: model.provider,
			fallback: i > 0,
			mocked: false
		};
	}
	return {
		dept,
		model: "local assembler",
		provider: "local",
		fallback: false,
		mocked: true
	};
}
function formatRoute(hit, lang) {
	const name = DEPT_LABEL[hit.dept];
	if (hit.mocked) return lang === "hi" ? `${name}: लोकल असेंबलर (कुंजी नहीं)` : `${name}: local assembler (no key)`;
	const fb = hit.fallback ? lang === "hi" ? " · फ़ॉलबैक" : " · fallback" : "";
	return `${name}: ${hit.model}${fb}`;
}
var STATE_KEY = "sarfealam.studio.v1";
var SECRET_KEY = "sarfealam.secrets.v1";
var STEP_MS = 900;
function blank() {
	return {
		lang: "en",
		welcomed: false,
		tab: "pilot",
		draftPrompt: "",
		secrets: {
			keys: emptyKeys(),
			tokens: ["", ""],
			voice: "",
			studioFb: {
				url: "",
				key: ""
			},
			appsFb: {
				url: "",
				key: ""
			}
		},
		skills: defaultSkills(),
		jobs: [],
		activeJobId: null,
		admins: {},
		messages: [],
		routingLine: "",
		thinking: false,
		syncNote: "",
		updatedAt: 0,
		booted: false
	};
}
function emptyKeys() {
	return Array.from({ length: 7 }, (_, i) => ({
		id: `k${i + 1}`,
		value: "",
		tag: ""
	}));
}
function emptyAdmin() {
	return {
		banner: false,
		bannerText: "Live from the studio",
		vipNote: "VIP unlocks the extra plan.",
		apkLink: "",
		notifications: []
	};
}
function initial() {
	return {
		...blank(),
		messages: [{
			id: "welcome",
			role: "pilot",
			text: welcome("en"),
			at: 0
		}]
	};
}
var state = initial();
var serverSnapshot = state;
var listeners = /* @__PURE__ */ new Set();
var remoteTimer = null;
var thinkTimer = null;
var exportTimer = null;
var pulling = false;
function emit() {
	for (const listener of listeners) listener();
}
function uid(prefix) {
	return `${prefix}-${Math.random().toString(36).slice(2, 8)}${Date.now().toString(36).slice(-4)}`;
}
function pilot(text) {
	return {
		id: uid("m"),
		role: "pilot",
		text,
		at: Date.now()
	};
}
function withSecrets(base, secrets) {
	return {
		...base,
		secrets
	};
}
function writeLocal(next) {
	try {
		const { secrets, ...rest } = next;
		localStorage.setItem(STATE_KEY, JSON.stringify({
			...rest,
			booted: false,
			thinking: false
		}));
		localStorage.setItem(SECRET_KEY, JSON.stringify(secrets));
	} catch {}
}
function commit(next, opts) {
	state = {
		...next,
		updatedAt: Date.now()
	};
	emit();
	if (state.booted) writeLocal(state);
	if (opts?.remote !== false && state.booted) scheduleRemote();
}
function scheduleRemote() {
	if (remoteTimer) clearTimeout(remoteTimer);
	remoteTimer = setTimeout(() => {
		remoteTimer = null;
		const slot = state.secrets.studioFb;
		if (!slot.url.trim() || !slot.key.trim()) {
			if (state.syncNote !== "local") {
				state = {
					...state,
					syncNote: "local"
				};
				emit();
			}
			return;
		}
		pushStudio(slot, toRemote(state)).then(() => {
			if (state.syncNote !== "synced") {
				state = {
					...state,
					syncNote: "synced"
				};
				emit();
				writeLocal(state);
			}
		}).catch(() => {
			state = {
				...state,
				syncNote: "error"
			};
			emit();
		});
	}, 700);
}
function stageAt(job, now) {
	if (job.status !== "assembling") return job.stage;
	return Math.min(5, 1 + Math.floor((now - job.startedAt) / STEP_MS));
}
function applyStage(job, now, lang) {
	if (job.status !== "assembling") return { job };
	const stage = stageAt(job, now);
	if (stage < 5) {
		if (stage === job.stage) return { job };
		return { job: {
			...job,
			stage,
			updatedAt: now
		} };
	}
	const next = {
		...job,
		stage: 5,
		status: "ready",
		updatedAt: now,
		announcedReady: true
	};
	if (job.announcedReady) return { job: next };
	return {
		job: next,
		message: pilot(readyLine(lang, job.blueprint.title))
	};
}
function activeJob(s = state) {
	return s.jobs.find((job) => job.id === s.activeJobId) ?? null;
}
function tick(now = Date.now()) {
	const job = activeJob();
	if (!job || job.status !== "assembling") return;
	const applied = applyStage(job, now, state.lang);
	if (applied.job === job && !applied.message) return;
	const jobs = state.jobs.map((item) => item.id === job.id ? applied.job : item);
	const messages = applied.message ? [...state.messages, applied.message].slice(-80) : state.messages;
	commit({
		...state,
		jobs,
		messages
	}, { remote: Boolean(applied.message) || applied.job.status !== job.status });
}
function exportLabels(lang, hasToken, hasGithub) {
	const en = lang === "en";
	const files = [{
		id: "files",
		label: en ? "Write project files" : "प्रोजेक्ट फाइलें लिखें",
		state: "wait"
	}, {
		id: "firebase",
		label: en ? "Inject Apps Firebase config" : "ऐप्स फायरबेस कॉन्फिग जोड़ें",
		state: "wait"
	}];
	const gh = (id, label) => ({
		id,
		label,
		state: hasGithub ? hasToken ? "wait" : "skip" : "skip"
	});
	return [
		...files,
		gh("repo", en ? "Create repo" : "रिपो बनाएं"),
		gh("push", en ? "Push files" : "फाइलें पुश करें"),
		gh("apk", en ? "Actions APK checklist" : "एक्शन्स एपीके सूची")
	];
}
function advanceExport(job, lang, hasToken) {
	const steps = job.exportSteps.map((step) => ({ ...step }));
	const index = steps.findIndex((step) => step.state === "run" || step.state === "wait");
	if (index === -1) return {
		...job,
		status: "export"
	};
	const current = steps[index];
	if (!current) return job;
	if (current.state === "wait") {
		if (!hasToken && (current.id === "repo" || current.id === "push" || current.id === "apk")) current.state = "skip";
		else current.state = "run";
	} else if (current.state === "run") current.state = "done";
	const still = steps.some((step) => step.state === "wait" || step.state === "run");
	return {
		...job,
		exportSteps: steps,
		status: still ? "ok" : "export",
		updatedAt: Date.now()
	};
}
function tickExport() {
	const job = activeJob();
	if (!job || job.status !== "ok" && job.status !== "export") return;
	if (job.exportSteps.every((step) => step.state === "done" || step.state === "skip")) {
		if (job.status !== "export") {
			const jobs = state.jobs.map((item) => item.id === job.id ? {
				...item,
				status: "export"
			} : item);
			commit({
				...state,
				jobs
			});
		}
		if (exportTimer) {
			clearInterval(exportTimer);
			exportTimer = null;
		}
		return;
	}
	const next = advanceExport(job, state.lang, state.secrets.tokens[0].trim().length > 0);
	const jobs = state.jobs.map((item) => item.id === job.id ? next : item);
	commit({
		...state,
		jobs
	});
}
function hydrate() {
	let next = initial();
	try {
		const raw = localStorage.getItem(STATE_KEY);
		const secretRaw = localStorage.getItem(SECRET_KEY);
		if (raw) {
			const saved = JSON.parse(raw);
			next = {
				...next,
				...saved,
				secrets: next.secrets,
				booted: false,
				thinking: false,
				jobs: Array.isArray(saved.jobs) ? saved.jobs : [],
				messages: Array.isArray(saved.messages) ? saved.messages : [],
				skills: {
					...defaultSkills(),
					...saved.skills ?? {}
				},
				admins: saved.admins ?? {}
			};
		}
		if (secretRaw) {
			const secrets = JSON.parse(secretRaw);
			if (secrets && Array.isArray(secrets.keys) && secrets.keys.length === 7) next = withSecrets(next, {
				keys: secrets.keys,
				tokens: secrets.tokens?.length === 2 ? secrets.tokens : ["", ""],
				voice: secrets.voice ?? "",
				studioFb: secrets.studioFb ?? {
					url: "",
					key: ""
				},
				appsFb: secrets.appsFb ?? {
					url: "",
					key: ""
				}
			});
		}
	} catch {
		next = initial();
	}
	if (next.messages.length === 0) next.messages = [pilot(welcome(next.lang))];
	next.welcomed = true;
	const now = Date.now();
	const resumed = [];
	next.jobs = next.jobs.map((job) => {
		if (job.status !== "assembling") return job;
		return applyStage(job, now, next.lang).job;
	});
	const focus = next.jobs.find((job) => job.id === next.activeJobId);
	if (focus && next.skills.survivor && (focus.status === "assembling" || focus.status === "ready")) {
		resumed.push(pilot(resumeLine(next.lang, focus)));
		next.tab = "build";
	}
	if (resumed.length > 0) next.messages = [...next.messages, ...resumed].slice(-80);
	next.booted = true;
	next.syncNote = next.secrets.studioFb.url && next.secrets.studioFb.key ? "syncing" : "local";
	state = next;
	emit();
	writeLocal(state);
	refreshRemote();
}
async function refreshRemote() {
	if (pulling) return;
	const slot = state.secrets.studioFb;
	if (!slot.url.trim() || !slot.key.trim()) return;
	pulling = true;
	try {
		const remote = await pullStudio(slot);
		pulling = false;
		if (!remote || remote.updatedAt <= state.updatedAt) {
			state = {
				...state,
				syncNote: "synced"
			};
			emit();
			if (remote && remote.updatedAt <= state.updatedAt) pushStudio(slot, toRemote(state));
			return;
		}
		const lang = remote.lang === "hi" ? "hi" : "en";
		let jobs = remote.jobs;
		const notes = [];
		jobs = jobs.map((job) => {
			if (job.status !== "assembling") return job;
			const applied = applyStage(job, Date.now(), lang);
			if (state.skills.survivor) notes.push(pilot(resumeLine(lang, applied.job)));
			return applied.job;
		});
		state = {
			...state,
			lang,
			tab: remote.tab ?? state.tab,
			draftPrompt: remote.draftPrompt ?? "",
			skills: {
				...defaultSkills(),
				...remote.skills
			},
			jobs,
			activeJobId: remote.activeJobId,
			admins: remote.admins ?? {},
			messages: [...remote.messages ?? [], ...notes].slice(-80),
			syncNote: "synced",
			updatedAt: remote.updatedAt
		};
		emit();
		writeLocal(state);
	} catch {
		pulling = false;
		state = {
			...state,
			syncNote: "error"
		};
		emit();
	}
}
function subscribe(listener) {
	listeners.add(listener);
	return () => listeners.delete(listener);
}
function useStudio() {
	return (0, import_react.useSyncExternalStore)(subscribe, () => state, () => serverSnapshot);
}
function setTab(tab) {
	commit({
		...state,
		tab
	}, { remote: false });
}
function setLang(lang) {
	if (state.lang === lang) return;
	const note = lang === "hi" ? "भाषा अब हिंदी है। को-पायलट यहीं से हिंदी में बात करेगा।" : "Language is English now. The co-pilot will stay in English.";
	commit({
		...state,
		lang,
		messages: [...state.messages, pilot(note)].slice(-80)
	});
}
function setDraft(draftPrompt) {
	commit({
		...state,
		draftPrompt
	}, { remote: false });
}
function setSkill(id, on) {
	commit({
		...state,
		skills: {
			...state.skills,
			[id]: on
		}
	});
}
function launchBuild() {
	const prompt = state.draftPrompt.trim();
	if (!prompt) {
		const text = state.lang === "hi" ? "पहले आइडिया लिखें, फिर बिल्ड शुरू करें।" : "Write an idea first, then launch the build.";
		commit({
			...state,
			tab: "build",
			messages: [...state.messages, pilot(text)].slice(-80)
		});
		return;
	}
	const blueprint = makeBlueprint(prompt, state.skills);
	const routeLabel = formatRoute(resolveDepartment("code", state.secrets), state.lang);
	const now = Date.now();
	const job = {
		id: uid("job"),
		prompt,
		createdAt: now,
		updatedAt: now,
		startedAt: now,
		status: "assembling",
		stage: 1,
		routeLabel,
		blueprint,
		sandbox: seedSandbox(blueprint),
		exportSteps: [],
		announcedReady: false
	};
	const messages = [pilot(launchLine(state.lang, blueprint.title, routeLabel))];
	for (const code of blueprint.warnings) {
		const line = warningLine(state.lang, code);
		if (line) messages.push(pilot(line));
	}
	commit({
		...state,
		jobs: [job, ...state.jobs].slice(0, 30),
		activeJobId: job.id,
		tab: "build",
		routingLine: routeLabel,
		admins: {
			...state.admins,
			[job.id]: state.admins[job.id] ?? emptyAdmin()
		},
		messages: [...state.messages, ...messages].slice(-80)
	});
}
function cancelBuild() {
	const job = activeJob();
	if (!job) return;
	const next = {
		...job,
		status: "cancelled",
		updatedAt: Date.now()
	};
	commit({
		...state,
		jobs: state.jobs.map((item) => item.id === job.id ? next : item),
		messages: [...state.messages, pilot(cancelLine(state.lang, job.blueprint.title))].slice(-80)
	});
}
function requestFix() {
	commit({
		...state,
		tab: "build",
		messages: [...state.messages, pilot(fixLine(state.lang))].slice(-80)
	});
}
function approveExport() {
	const job = activeJob();
	if (!job || job.status !== "ready") return;
	const hasToken = state.secrets.tokens[0].trim().length > 0;
	const hasApps = Boolean(state.secrets.appsFb.url.trim() && state.secrets.appsFb.key.trim());
	const hasGithub = state.skills.github && job.blueprint.skills.includes("github");
	const steps = exportLabels(state.lang, hasToken, hasGithub);
	if (steps[0]) steps[0] = {
		...steps[0],
		state: "run"
	};
	const next = {
		...job,
		status: "ok",
		exportSteps: steps,
		updatedAt: Date.now()
	};
	commit({
		...state,
		jobs: state.jobs.map((item) => item.id === job.id ? next : item),
		messages: [...state.messages, pilot(exportLine(state.lang, job.blueprint.title, hasToken && hasGithub, hasApps))].slice(-80)
	});
	if (exportTimer) clearInterval(exportTimer);
	exportTimer = setInterval(tickExport, 700);
}
function selectJob(id) {
	commit({
		...state,
		activeJobId: id,
		tab: "build"
	});
}
function patchSandbox(patch) {
	const job = activeJob();
	if (!job) return;
	const next = {
		...job,
		sandbox: {
			...job.sandbox,
			...patch
		},
		updatedAt: Date.now()
	};
	commit({
		...state,
		jobs: state.jobs.map((item) => item.id === job.id ? next : item)
	}, { remote: false });
}
function patchAdmin(patch) {
	const id = state.activeJobId;
	if (!id) return;
	const current = state.admins[id] ?? emptyAdmin();
	commit({
		...state,
		admins: {
			...state.admins,
			[id]: {
				...current,
				...patch
			}
		}
	});
}
function sendNotification(text) {
	const id = state.activeJobId;
	if (!id) return;
	const current = state.admins[id] ?? emptyAdmin();
	const note = {
		id: uid("n"),
		text,
		at: Date.now()
	};
	commit({
		...state,
		admins: {
			...state.admins,
			[id]: {
				...current,
				notifications: [note, ...current.notifications].slice(0, 8)
			}
		},
		tab: "build"
	});
}
function saveKey(index, value, tag) {
	const keys = state.secrets.keys.map((key, i) => i === index ? {
		...key,
		value: value.trim(),
		tag
	} : key);
	commit({
		...state,
		secrets: {
			...state.secrets,
			keys
		}
	});
}
function clearKey(index) {
	saveKey(index, "", "");
}
function saveToken(index, value) {
	const tokens = [...state.secrets.tokens];
	tokens[index] = value.trim();
	commit({
		...state,
		secrets: {
			...state.secrets,
			tokens
		}
	});
}
function saveVoice(value) {
	commit({
		...state,
		secrets: {
			...state.secrets,
			voice: value.trim()
		}
	});
}
function saveFirebase(which, url, key) {
	const secrets = {
		...state.secrets,
		[which]: {
			url: url.trim(),
			key: key.trim()
		}
	};
	commit({
		...state,
		secrets,
		syncNote: which === "studioFb" ? "syncing" : state.syncNote
	});
	if (which === "studioFb") refreshRemote();
}
function clearFirebase(which) {
	saveFirebase(which, "", "");
}
function askPilot(text) {
	const q = text.trim();
	if (!q) return;
	if (thinkTimer) clearTimeout(thinkTimer);
	const route = resolveDepartment("brain", state.secrets);
	const user = {
		id: uid("m"),
		role: "user",
		text: q,
		at: Date.now()
	};
	commit({
		...state,
		thinking: true,
		routingLine: formatRoute(route, state.lang),
		messages: [...state.messages, user].slice(-80)
	}, { remote: false });
	const lang = state.lang;
	thinkTimer = setTimeout(() => {
		thinkTimer = null;
		const result = answer(lang, q, state);
		commit({
			...state,
			thinking: false,
			draftPrompt: result.prompt ?? state.draftPrompt,
			tab: result.prompt ? "build" : state.tab,
			messages: [...state.messages, pilot(result.reply)].slice(-80)
		});
	}, 480);
}
function runVisionCheck() {
	const job = activeJob();
	if (!job) return;
	const line = formatRoute(resolveDepartment("vision", state.secrets), state.lang);
	const note = state.lang === "hi" ? `${line}. स्थानीय जांच: कंट्रास्ट ठीक है, टेस्ट कंट्रोल स्टेज ${job.stage} पर ${job.stage >= 4 ? "खुले" : "बंद"} हैं।` : `${line}. Local check: contrast holds, test controls are ${job.stage >= 4 ? "open" : "locked"} at stage ${job.stage}.`;
	commit({
		...state,
		routingLine: line,
		messages: [...state.messages, pilot(note)].slice(-80)
	});
}
function speakRoute() {
	return formatRoute(resolveDepartment("speak", state.secrets), state.lang);
}
function listenRoute() {
	return formatRoute(resolveDepartment("listen", state.secrets), state.lang);
}
function ensureExportClock() {
	const job = activeJob();
	if (!job) return;
	if ((job.status === "ok" || job.status === "export") && job.exportSteps.some((s) => s.state === "wait" || s.state === "run")) {
		if (!exportTimer) exportTimer = setInterval(tickExport, 700);
	}
}
var CRC = makeCrc();
function makeCrc() {
	const table = /* @__PURE__ */ new Uint32Array(256);
	for (let n = 0; n < 256; n++) {
		let c = n;
		for (let k = 0; k < 8; k++) c = c & 1 ? 3988292384 ^ c >>> 1 : c >>> 1;
		table[n] = c >>> 0;
	}
	return table;
}
function crc32(data) {
	let c = 4294967295;
	for (let i = 0; i < data.length; i++) {
		const byte = data[i] ?? 0;
		c = (CRC[(c ^ byte) & 255] ?? 0) ^ c >>> 8;
	}
	return (c ^ 4294967295) >>> 0;
}
function dosTime(d) {
	return {
		time: d.getHours() << 11 | d.getMinutes() << 5 | Math.floor(d.getSeconds() / 2),
		date: d.getFullYear() - 1980 << 9 | d.getMonth() + 1 << 5 | d.getDate()
	};
}
function zipFiles(files) {
	const enc = new TextEncoder();
	const now = dosTime(/* @__PURE__ */ new Date());
	const parts = [];
	const central = [];
	let offset = 0;
	for (const file of files) {
		const name = enc.encode(file.path);
		const data = enc.encode(file.text);
		const crc = crc32(data);
		const local = new Uint8Array(30 + name.length);
		const view = new DataView(local.buffer);
		view.setUint32(0, 67324752, true);
		view.setUint16(4, 20, true);
		view.setUint16(6, 2048, true);
		view.setUint16(8, 0, true);
		view.setUint16(10, now.time, true);
		view.setUint16(12, now.date, true);
		view.setUint32(14, crc, true);
		view.setUint32(18, data.length, true);
		view.setUint32(22, data.length, true);
		view.setUint16(26, name.length, true);
		view.setUint16(28, 0, true);
		local.set(name, 30);
		parts.push(local, data);
		const cen = new Uint8Array(46 + name.length);
		const cv = new DataView(cen.buffer);
		cv.setUint32(0, 33639248, true);
		cv.setUint16(4, 20, true);
		cv.setUint16(6, 20, true);
		cv.setUint16(8, 2048, true);
		cv.setUint16(10, 0, true);
		cv.setUint16(12, now.time, true);
		cv.setUint16(14, now.date, true);
		cv.setUint32(16, crc, true);
		cv.setUint32(20, data.length, true);
		cv.setUint32(24, data.length, true);
		cv.setUint16(28, name.length, true);
		cv.setUint16(30, 0, true);
		cv.setUint16(32, 0, true);
		cv.setUint16(34, 0, true);
		cv.setUint16(36, 0, true);
		cv.setUint32(38, 0, true);
		cv.setUint32(42, offset, true);
		cen.set(name, 46);
		central.push(cen);
		offset += local.length + data.length;
	}
	const centralStart = offset;
	let centralSize = 0;
	for (const c of central) centralSize += c.length;
	const end = /* @__PURE__ */ new Uint8Array(22);
	const ev = new DataView(end.buffer);
	ev.setUint32(0, 101010256, true);
	ev.setUint16(4, 0, true);
	ev.setUint16(6, 0, true);
	ev.setUint16(8, files.length, true);
	ev.setUint16(10, files.length, true);
	ev.setUint32(12, centralSize, true);
	ev.setUint32(16, centralStart, true);
	ev.setUint16(20, 0, true);
	const blobParts = [];
	for (const p of parts) blobParts.push(p);
	for (const c of central) blobParts.push(c);
	blobParts.push(end);
	return new Blob(blobParts, { type: "application/zip" });
}
var EXPORT_FILES = [
	"README.md",
	"package.json",
	"capacitor.config.json",
	"firebase.apps.json",
	"www/index.html",
	"www/app.js",
	"www/styles.css",
	".github/workflows/android-apk.yml",
	"THIRD_PARTY.md"
];
function buildProjectFiles(job, apps, assetHint) {
	const cfg = {
		databaseURL: apps.url.trim(),
		apiKey: apps.key.trim(),
		purpose: "Apps Firebase — login, profile, and user data for this published app."
	};
	const js = renderAppJs(job, cfg);
	const files = [
		{
			path: "README.md",
			text: readme(job)
		},
		{
			path: "package.json",
			text: pkg(job)
		},
		{
			path: "capacitor.config.json",
			text: capacitor(job)
		},
		{
			path: "firebase.apps.json",
			text: JSON.stringify(cfg, null, 2) + "\n"
		},
		{
			path: "www/index.html",
			text: html()
		},
		{
			path: "www/app.js",
			text: js
		},
		{
			path: "www/styles.css",
			text: css()
		},
		{
			path: ".github/workflows/android-apk.yml",
			text: workflow()
		}
	];
	if (assetHint) files.push({
		path: "THIRD_PARTY.md",
		text: "Open-source hints\n\n- Kenney assets (CC0) if you add sprites later.\n- Outfit and Syne via Google Fonts (OFL).\nKeep this file in the repo.\n"
	});
	return files;
}
function downloadProject(job, apps, assetHint) {
	const blob = zipFiles(buildProjectFiles(job, apps, assetHint));
	const a = document.createElement("a");
	const url = URL.createObjectURL(blob);
	a.href = url;
	a.download = `${job.blueprint.slug}.zip`;
	document.body.appendChild(a);
	a.click();
	a.remove();
	URL.revokeObjectURL(url);
}
function pkg(job) {
	return JSON.stringify({
		name: job.blueprint.slug,
		private: true,
		scripts: {
			start: "npx serve www",
			"cap:sync": "npx cap sync android"
		},
		dependencies: {
			"@capacitor/core": "^7.0.0",
			"@capacitor/android": "^7.0.0"
		}
	}, null, 2);
}
function capacitor(job) {
	return JSON.stringify({
		appId: `app.sarfealam.${job.blueprint.slug.replace(/-/g, "")}`,
		appName: job.blueprint.title,
		webDir: "www"
	}, null, 2);
}
function readme(job) {
	return `# ${job.blueprint.title}

Built in Sarfealam Auto-Studio.

Kind: ${job.blueprint.kind}
Template: ${job.blueprint.template}

## Test on a phone browser

Unzip, then from this folder run a static server and open \`www/index.html\` on your phone (same Wi-Fi). The page is plain HTML, CSS, and JS.

## Apps Firebase

\`firebase.apps.json\` and \`www/app.js\` use the Apps Firebase slot from the studio (not Studio Firebase). Profile saves go to \`/appdata/profile\` on that Realtime Database when URL and key are set.

## Android APK

1. Create a GitHub repo and push this folder.
2. Add the Android project once: \`npm install\` then \`npx cap add android\`.
3. Push again. The workflow \`.github/workflows/android-apk.yml\` runs \`assembleDebug\` and uploads an APK artifact.

Prompt that produced this build:

> ${job.prompt}
`;
}
function workflow() {
	return `name: Android APK
on:
  push:
    branches: [main]
jobs:
  apk:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 22
      - name: Sync web assets
        run: npx --yes @capacitor/cli@7 sync android || echo "Run npx cap add android once, then re-run."
      - uses: android-actions/setup-android@v3
      - name: assembleDebug
        run: |
          if [ -d android ]; then
            cd android && chmod +x ./gradlew && ./gradlew assembleDebug
          else
            echo "android/ missing — add Capacitor Android, commit, push again."
            exit 1
          fi
      - uses: actions/upload-artifact@v4
        if: always()
        with:
          name: debug-apk
          path: android/app/build/outputs/apk/debug/*.apk
          if-no-files-found: warn
`;
}
function html() {
	return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Sarfealam build</title>
  <link rel="stylesheet" href="./styles.css" />
</head>
<body>
  <main id="app"></main>
  <script src="./app.js"><\/script>
</body>
</html>
`;
}
function css() {
	return `:root { color-scheme: dark; }
body { margin: 0; font-family: Outfit, system-ui, sans-serif; background: #07090f; color: #e7eef8; }
main { max-width: 32rem; margin: 0 auto; padding: 1.25rem; display: grid; gap: 0.75rem; }
h1 { font-size: 1.6rem; margin: 0; letter-spacing: -0.03em; }
p { color: #9aabc4; margin: 0; }
button, input { min-height: 2.75rem; border-radius: 0.7rem; border: 1px solid #2c3548; background: #161a26; color: inherit; padding: 0 0.9rem; font: inherit; }
button { background: #3ee0ff; color: #061018; font-weight: 600; }
.row { display: flex; gap: 0.5rem; }
.card { border: 1px solid #2c3548; border-radius: 1rem; padding: 0.9rem; background: #10131c; }
`;
}
function renderAppJs(job, cfg) {
	const payload = {
		title: job.blueprint.title,
		template: job.blueprint.template,
		kind: job.blueprint.kind,
		summary: job.blueprint.summary,
		skills: job.blueprint.skills,
		screens: job.blueprint.screens,
		items: job.sandbox.items,
		firebase: cfg
	};
	return `/* Generated by Sarfealam Auto-Studio. Apps Firebase is injected below. */
const BUILD = ${JSON.stringify(payload, null, 2)};

const app = document.querySelector("#app");
const saved = localStorage.getItem("sarfealam-profile");
let profile = saved ? JSON.parse(saved) : { name: "" };

function draw() {
  app.innerHTML = "";
  const h = document.createElement("h1");
  h.textContent = BUILD.title;
  const p = document.createElement("p");
  p.textContent = BUILD.summary;
  app.append(h, p);
  const box = document.createElement("div");
  box.className = "card";
  box.textContent = BUILD.firebase.databaseURL
    ? "Apps Firebase connected for profile and user data."
    : "Apps Firebase config is empty. Paste it in the studio and export again.";
  app.append(box);
  for (const item of BUILD.items) {
    const row = document.createElement("div");
    row.className = "card";
    row.textContent = item.title + " · " + item.note;
    app.append(row);
  }
  const form = document.createElement("form");
  form.className = "row";
  const input = document.createElement("input");
  input.placeholder = "Profile name";
  input.value = profile.name || "";
  input.name = "name";
  const button = document.createElement("button");
  button.type = "submit";
  button.textContent = "Save profile";
  form.append(input, button);
  form.addEventListener("submit", function (event) {
    event.preventDefault();
    profile = { name: input.value };
    localStorage.setItem("sarfealam-profile", JSON.stringify(profile));
    saveRemote(profile);
  });
  app.append(form);
}

async function saveRemote(next) {
  const url = (BUILD.firebase.databaseURL || "").replace(/\\/+$/, "");
  const key = BUILD.firebase.apiKey || "";
  if (!url || !key) return;
  try {
    await fetch(url + "/appdata/profile.json?auth=" + encodeURIComponent(key), {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(next),
    });
  } catch (err) {
    console.warn("Apps Firebase save skipped", err);
  }
}

draw();
`;
}
function cssColor(name, fallback) {
	return getComputedStyle(document.documentElement).getPropertyValue(name).trim() || fallback;
}
function useVehicleSim({ enabled, onAction }) {
	const canvasRef = (0, import_react.useRef)(null);
	const held = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	const gas = (0, import_react.useRef)(false);
	const brake = (0, import_react.useRef)(false);
	const steerBtn = (0, import_react.useRef)(0);
	const yaw = (0, import_react.useRef)(0);
	const speed = (0, import_react.useRef)(0);
	const offset = (0, import_react.useRef)(0);
	const enabledRef = (0, import_react.useRef)(enabled);
	enabledRef.current = enabled;
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		let frame = 0;
		let last = performance.now();
		let scroll = 0;
		const probe = {
			getYaw: () => yaw.current,
			getSpeed: () => speed.current,
			setSteer: (v) => {
				steerBtn.current = Math.max(-1, Math.min(1, v));
			},
			setKeys: (codes) => {
				held.current = new Set(codes);
			}
		};
		window.__controlsTest = probe;
		const interesting = /* @__PURE__ */ new Set([
			"KeyA",
			"KeyD",
			"KeyW",
			"KeyS",
			"ArrowLeft",
			"ArrowRight",
			"ArrowUp",
			"ArrowDown"
		]);
		const onKey = (event, down) => {
			const target = event.target;
			if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable)) return;
			if (!interesting.has(event.code)) return;
			event.preventDefault();
			if (down) held.current.add(event.code);
			else held.current.delete(event.code);
		};
		const down = (event) => onKey(event, true);
		const up = (event) => onKey(event, false);
		const clear = () => {
			held.current.clear();
			gas.current = false;
			brake.current = false;
			steerBtn.current = 0;
		};
		window.addEventListener("keydown", down);
		window.addEventListener("keyup", up);
		window.addEventListener("blur", clear);
		const loop = (now) => {
			const dt = Math.min(.05, (now - last) / 1e3);
			last = now;
			if (enabledRef.current) {
				let steer = steerBtn.current;
				if (held.current.has("KeyA") || held.current.has("ArrowLeft")) steer += 1;
				if (held.current.has("KeyD") || held.current.has("ArrowRight")) steer -= 1;
				steer = Math.max(-1, Math.min(1, steer));
				const thrusting = held.current.has("KeyW") || held.current.has("ArrowUp") || gas.current;
				const braking = held.current.has("KeyS") || held.current.has("ArrowDown") || brake.current;
				if (thrusting) speed.current = Math.min(220, speed.current + 160 * dt);
				else speed.current = Math.max(0, speed.current - (braking ? 240 : 50) * dt);
				const moving = speed.current > 8;
				yaw.current += steer * 2.4 * (moving ? 1 : .2) * dt;
				offset.current += -Math.sin(yaw.current) * speed.current * dt * .85;
				offset.current = Math.max(-90, Math.min(90, offset.current));
				scroll += speed.current * dt;
			}
			paint(ctx, canvas, yaw.current, offset.current, scroll, speed.current);
			frame = requestAnimationFrame(loop);
		};
		frame = requestAnimationFrame(loop);
		return () => {
			cancelAnimationFrame(frame);
			window.removeEventListener("keydown", down);
			window.removeEventListener("keyup", up);
			window.removeEventListener("blur", clear);
			if (window.__controlsTest === probe) delete window.__controlsTest;
		};
	}, []);
	const hold = (which, text) => ({
		onPointerDown: (event) => {
			event.currentTarget.setPointerCapture(event.pointerId);
			if (which === "left") steerBtn.current = 1;
			if (which === "right") steerBtn.current = -1;
			if (which === "gas") gas.current = true;
			if (which === "brake") brake.current = true;
			onAction(text);
		},
		onPointerUp: () => {
			if (which === "left" || which === "right") steerBtn.current = 0;
			if (which === "gas") gas.current = false;
			if (which === "brake") brake.current = false;
		},
		onPointerCancel: () => {
			steerBtn.current = 0;
			gas.current = false;
			brake.current = false;
		}
	});
	return {
		canvasRef,
		hold
	};
}
function paint(ctx, canvas, yaw, offset, scroll, speed) {
	const dpr = Math.min(2, window.devicePixelRatio || 1);
	const width = canvas.clientWidth;
	const height = canvas.clientHeight;
	if (canvas.width !== Math.floor(width * dpr) || canvas.height !== Math.floor(height * dpr)) {
		canvas.width = Math.floor(width * dpr);
		canvas.height = Math.floor(height * dpr);
	}
	ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
	const bg = cssColor("--color-bg", "#07090f");
	const cyan = cssColor("--color-cyan", "#3ee0ff");
	const violet = cssColor("--color-violet", "#b39bff");
	const fg = cssColor("--color-fg", "#e7eef8");
	const surface = cssColor("--color-surface", "#161a26");
	ctx.fillStyle = bg;
	ctx.fillRect(0, 0, width, height);
	const horizon = height * .38;
	ctx.fillStyle = surface;
	ctx.fillRect(0, 0, width, horizon);
	ctx.fillStyle = violet;
	ctx.globalAlpha = .35;
	ctx.fillRect(0, horizon - 2, width, 3);
	ctx.globalAlpha = 1;
	ctx.beginPath();
	ctx.moveTo(width * .5, horizon);
	ctx.lineTo(width * .08, height);
	ctx.lineTo(width * .92, height);
	ctx.closePath();
	ctx.fillStyle = cssColor("--color-bg-elev", "#10131c");
	ctx.fill();
	ctx.strokeStyle = cyan;
	ctx.globalAlpha = .7;
	ctx.stroke();
	ctx.globalAlpha = 1;
	ctx.strokeStyle = fg;
	ctx.globalAlpha = .45;
	ctx.setLineDash([10, 16]);
	ctx.lineDashOffset = -scroll;
	ctx.beginPath();
	ctx.moveTo(width * .5, horizon + 8);
	ctx.lineTo(width * .5 + offset * .2, height);
	ctx.stroke();
	ctx.setLineDash([]);
	ctx.globalAlpha = 1;
	const cx = width * .5 + offset;
	const cy = height * .78;
	ctx.save();
	ctx.translate(cx, cy);
	ctx.rotate(-yaw);
	ctx.fillStyle = cyan;
	ctx.beginPath();
	ctx.roundRect(-12, -18, 24, 36, 6);
	ctx.fill();
	ctx.fillStyle = violet;
	ctx.fillRect(-8, -8, 16, 12);
	ctx.fillStyle = bg;
	ctx.fillRect(-14, -6, 4, 8);
	ctx.fillRect(10, -6, 4, 8);
	ctx.fillRect(-14, 8, 4, 8);
	ctx.fillRect(10, 8, 4, 8);
	ctx.restore();
	ctx.fillStyle = fg;
	ctx.globalAlpha = .8;
	ctx.font = "600 12px Outfit, sans-serif";
	ctx.fillText(String(Math.round(speed)), 12, 20);
	ctx.globalAlpha = 1;
}
function LivePreview({ job, lang, admin, notice }) {
	const copy = t(lang);
	const stage = job.stage;
	const bp = job.blueprint;
	const box = job.sandbox;
	const interactive = stage >= 4 && (job.status === "assembling" || job.status === "ready" || job.status === "ok" || job.status === "export");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "overflow-hidden rounded-xl border border-line bg-bg-elev",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between border-b border-line px-3 py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-base font-semibold tracking-tight",
					children: bp.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-medium text-cyan",
					children: stage >= 5 ? copy.readyBadge : copy.assembling
				})]
			}),
			admin.banner && stage >= 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "bg-violet px-3 py-2 text-sm font-medium text-ink",
				children: admin.bannerText
			}) : null,
			notice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "border-b border-line px-3 py-2 text-sm text-cyan",
				children: notice
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative min-h-64 p-3",
				children: [
					stage < 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: bp.summary
					}) : null,
					bp.template === "game" && stage >= 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameWorld, {
						lang,
						interactive,
						lastAction: box.lastAction
					}) : null,
					bp.template === "game" && stage < 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: bp.summary
					}) : null,
					bp.template === "card" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTable, {
						lang,
						job,
						interactive,
						stage
					}) : null,
					bp.kind === "app" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppWorld, {
						lang,
						job,
						interactive,
						stage,
						admin
					}) : null
				]
			}),
			stage >= 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "border-t border-line px-3 py-2 text-xs text-subtle",
				children: [
					copy.skillsUsed,
					": ",
					bp.skills.map((id) => skillLabel(id, lang)).join(" · ") || "—"
				]
			}) : null
		]
	});
}
function GameWorld({ lang, interactive, lastAction }) {
	const copy = t(lang);
	const sim = useVehicleSim({
		enabled: interactive,
		onAction: (text) => patchSandbox({ lastAction: text })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: sim.canvasRef,
				className: "h-56 w-full rounded-lg bg-bg"
			}),
			interactive ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-4 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-11 rounded-md bg-surface text-fg",
						...sim.hold("left", copy.left),
						children: copy.left
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-11 rounded-md bg-cyan text-ink",
						...sim.hold("gas", copy.gas),
						children: copy.gas
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-11 rounded-md bg-surface text-fg",
						...sim.hold("brake", copy.brake),
						children: copy.brake
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-11 rounded-md bg-surface text-fg",
						...sim.hold("right", copy.right),
						children: copy.right
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: copy.testLocked
			}),
			lastAction ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted",
				children: [
					copy.lastInput,
					": ",
					lastAction
				]
			}) : null
		]
	});
}
function CardTable({ lang, job, interactive, stage }) {
	const copy = t(lang);
	const box = job.sandbox;
	const deal = () => {
		patchSandbox({
			hand: dealHand(`${job.id}-${Date.now()}`, 3),
			pot: box.pot + 10,
			lastAction: copy.deal
		});
	};
	const draw = () => {
		const extra = dealHand(`${job.id}-draw-${box.hand.join("")}`, 1)[0] ?? "AS";
		const best = Math.max(...box.hand.map(rankValue), 0);
		const win = rankValue(extra) >= best;
		patchSandbox({
			hand: [...box.hand, extra].slice(-4),
			pot: Math.max(0, box.pot + (win ? 20 : -10)),
			lastAction: `${copy.draw} ${extra}`
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3",
		children: [
			stage >= 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg border border-line bg-bg p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-wide text-subtle",
						children: copy.pot
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl font-semibold tabular-nums text-cyan",
						children: box.pot
					}),
					stage >= 3 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: (box.hand.length > 0 ? box.hand : [
							"??",
							"??",
							"??"
						]).map((card, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `grid h-16 w-12 place-items-center rounded-md border border-line bg-surface text-sm font-semibold ${card.endsWith("H") || card.endsWith("D") ? "text-danger" : "text-fg"}`,
							children: stage >= 3 ? card : "·"
						}, `${card}-${index}`))
					}) : null
				]
			}) : null,
			interactive ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "min-h-11 rounded-md bg-cyan text-ink font-semibold",
					onClick: deal,
					children: copy.deal
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "min-h-11 rounded-md bg-surface text-fg",
					onClick: draw,
					children: copy.draw
				})]
			}) : null,
			box.lastAction ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted",
				children: [
					copy.lastInput,
					": ",
					box.lastAction
				]
			}) : null
		]
	});
}
function AppWorld({ lang, job, interactive, stage, admin }) {
	const copy = t(lang);
	const bp = job.blueprint;
	const box = job.sandbox;
	const skills = bp.skills;
	if (skills.includes("otp") && !box.otpPassed) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "grid gap-3",
		onSubmit: (event) => {
			event.preventDefault();
			if (!interactive) return;
			if (box.otpCode.trim() === "248163") patchSandbox({
				otpPassed: true,
				lastAction: copy.otp
			});
			else patchSandbox({ lastAction: copy.demoCode });
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-medium",
				children: copy.signIn
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: copy.demoCode
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: box.otpCode,
				onChange: (event) => patchSandbox({ otpCode: event.target.value }),
				placeholder: copy.codePh,
				className: "min-h-11 rounded-md border border-line bg-bg px-3",
				inputMode: "numeric"
			}),
			interactive ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "submit",
				className: "min-h-11 rounded-md bg-cyan font-semibold text-ink",
				children: copy.otp
			}) : null
		]
	});
	const filtered = box.items.filter((item) => {
		const q = box.query.trim().toLowerCase();
		if (!q) return true;
		return `${item.title} ${item.note}`.toLowerCase().includes(q);
	});
	const addItem = () => {
		const title = box.draftTitle.trim();
		if (!title) return;
		const amount = Number(box.draftAmount) || 0;
		patchSandbox({
			items: [{
				id: `n-${Date.now()}`,
				title,
				note: "new",
				amount
			}, ...box.items],
			balance: box.balance + amount,
			draftTitle: "",
			draftAmount: "",
			lastAction: title,
			cart: bp.template === "shop" ? box.cart + 1 : box.cart
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3",
		children: [
			stage >= 3 && box.tab === "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeBody, {
				lang,
				job,
				filtered
			}) : null,
			stage >= 3 && box.tab === "list" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListBody, { items: filtered }) : null,
			stage >= 3 && box.tab === "map" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapBody, { lang }) : null,
			stage >= 3 && box.tab === "wallet" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-subtle",
				children: copy.balance
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-3xl font-semibold tabular-nums text-cyan",
				children: box.balance
			})] }) : null,
			stage >= 3 && box.tab === "profile" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: copy.profile
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: admin.vipNote
					}),
					skills.includes("vip") && !box.vipOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-11 rounded-md bg-violet font-semibold text-ink",
						disabled: !interactive,
						onClick: () => patchSandbox({
							vipOpen: true,
							lastAction: copy.unlock
						}),
						children: copy.unlock
					}) : null,
					box.vipOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-ok",
						children: copy.unlock
					}) : null
				]
			}) : null,
			interactive && skills.includes("search") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: box.query,
				onChange: (event) => patchSandbox({ query: event.target.value }),
				placeholder: copy.search,
				className: "min-h-11 rounded-md border border-line bg-bg px-3"
			}) : null,
			interactive && (skills.includes("lists") || bp.template === "bank" || bp.template === "shop" || bp.template === "delivery") ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-5 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: box.draftTitle,
						onChange: (event) => patchSandbox({ draftTitle: event.target.value }),
						placeholder: copy.name,
						className: "col-span-2 min-h-11 rounded-md border border-line bg-bg px-3"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: box.draftAmount,
						onChange: (event) => patchSandbox({ draftAmount: event.target.value }),
						placeholder: copy.amount,
						inputMode: "decimal",
						className: "col-span-2 min-h-11 rounded-md border border-line bg-bg px-3"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-11 rounded-md bg-cyan font-semibold text-ink",
						onClick: addItem,
						children: bp.template === "shop" ? "+" : bp.template === "delivery" ? copy.book : bp.template === "fantasy" ? copy.reveal : copy.add
					})
				]
			}) : null,
			interactive && bp.template === "fantasy" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "min-h-11 rounded-md bg-violet font-semibold text-ink",
				onClick: () => patchSandbox({
					revealed: !box.revealed,
					lastAction: copy.reveal
				}),
				children: copy.reveal
			}) : null,
			box.revealed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-cyan",
				children: bp.title
			}) : null,
			stage >= 4 && bp.screens.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-4 gap-1 rounded-lg bg-bg p-1",
				children: bp.screens.slice(0, 4).map((screen) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: `min-h-11 rounded-md text-xs font-medium ${box.tab === screen.id ? "bg-cyan text-ink" : "text-muted"}`,
					onClick: () => patchSandbox({
						tab: screen.id,
						lastAction: screen.label
					}),
					children: screen.label
				}, screen.id))
			}) : null,
			box.lastAction ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted",
				children: [
					copy.lastInput,
					": ",
					box.lastAction
				]
			}) : null
		]
	});
}
function HomeBody({ lang, job, filtered }) {
	const copy = t(lang);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: job.blueprint.summary
			}),
			job.blueprint.template === "bank" || job.blueprint.template === "khata" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-3xl font-semibold tabular-nums text-cyan",
				children: job.sandbox.balance
			}) : null,
			filtered.slice(0, 4).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between rounded-md bg-surface px-3 py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm",
					children: item.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs tabular-nums text-muted",
					children: item.amount
				})]
			}, item.id)),
			job.blueprint.template === "shop" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted",
				children: [
					copy.cart,
					": ",
					job.sandbox.cart
				]
			}) : null
		]
	});
}
function ListBody({ items }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-2",
		children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-md bg-surface px-3 py-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium",
				children: item.title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted",
				children: [
					item.note,
					" · ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums",
						children: item.amount
					})
				]
			})]
		}, item.id))
	});
}
function MapBody({ lang }) {
	const copy = t(lang);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mb-2 text-xs text-subtle",
		children: copy.zone
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-2 gap-2",
		children: [
			"A",
			"B",
			"C",
			"D"
		].map((zone) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid h-16 place-items-center rounded-md border border-line text-sm text-cyan",
			children: zone
		}, zone))
	})] });
}
var buttonStyles = cva("inline-flex items-center justify-center gap-2 rounded-md px-4 font-semibold min-h-11 disabled:opacity-40", {
	variants: { variant: {
		primary: "bg-cyan text-ink glow-cyan",
		quiet: "glass text-fg",
		danger: "glass text-danger",
		violet: "bg-violet text-ink glow-violet"
	} },
	defaultVariants: { variant: "quiet" }
});
function Button({ variant, className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		className: buttonStyles({
			variant,
			className
		}),
		...props
	});
}
function TextArea(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		...props,
		className: `w-full rounded-lg border border-line bg-bg-elev px-3 py-3 text-base text-fg placeholder:text-subtle ${props.className ?? ""}`
	});
}
function TextField(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		...props,
		className: `w-full rounded-md border border-line bg-bg-elev px-3 text-base text-fg min-h-11 placeholder:text-subtle ${props.className ?? ""}`
	});
}
function SelectField(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
		...props,
		className: `w-full rounded-md border border-line bg-bg-elev px-3 text-base text-fg min-h-11 ${props.className ?? ""}`
	});
}
function Panel({ children, className = "" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: `glass rounded-xl p-4 ${className}`,
		children
	});
}
function BuildTab() {
	const studio = useStudio();
	const copy = t(studio.lang);
	const [now, setNow] = (0, import_react.useState)(() => Date.now());
	(0, import_react.useEffect)(() => {
		const timer = setInterval(() => setNow(Date.now()), 1e3);
		return () => clearInterval(timer);
	}, []);
	const job = studio.jobs.find((item) => item.id === studio.activeJobId) ?? null;
	const admin = job ? studio.admins[job.id] : void 0;
	const notice = latestNotice(admin?.notifications ?? [], now);
	const hasToken = studio.secrets.tokens[0].trim().length > 0;
	const hasApps = Boolean(studio.secrets.appsFb.url.trim() && studio.secrets.appsFb.key.trim());
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			studio.routingLine ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-cyan",
				children: [
					copy.providerLine,
					": ",
					studio.routingLine
				]
			}) : null,
			job && studio.skills.survivor && (job.status === "assembling" || job.status === "ready") ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "rounded-md border border-line px-3 py-2 text-sm",
				children: [
					job.status === "assembling" ? copy.resumeRun : copy.resumeReady,
					": ",
					job.blueprint.title
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextArea, {
				rows: 3,
				value: studio.draftPrompt,
				placeholder: copy.promptPh,
				"aria-label": copy.promptPh,
				onChange: (event) => setDraft(event.target.value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-xs text-subtle",
				children: copy.examples
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2 overflow-x-auto pb-1",
				children: CHIPS.map((chip) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "min-h-11 shrink-0 rounded-full border border-line px-4 text-sm text-fg",
					onClick: () => setDraft(studio.lang === "hi" ? chip.promptHi : chip.promptEn),
					children: studio.lang === "hi" ? chip.labelHi : chip.labelEn
				}, chip.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "primary",
				onClick: launchBuild,
				children: copy.launch
			}),
			job ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: job.blueprint.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-subtle",
							children: job.blueprint.kind === "game" ? copy.kindGame : copy.kindApp
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-cyan",
							children: statusLabel(job.status, studio.lang)
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "grid gap-2",
					children: copy.stages.map((label, index) => {
						const n = index + 1;
						const done = job.stage > n || job.stage === n && job.status !== "assembling";
						const live = job.stage === n && job.status === "assembling";
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: `flex min-h-11 items-center gap-3 rounded-md px-3 text-sm ${done ? "bg-surface text-fg" : "text-muted"} ${live ? "stage-live text-cyan" : ""}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums",
								children: n
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label })]
						}, label);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-subtle",
					children: job.routeLabel
				}),
				admin ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LivePreview, {
					job,
					lang: studio.lang,
					admin,
					notice
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: job.stage >= 4 ? copy.testHint : copy.testLocked
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2",
					children: [
						job.status === "ready" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "primary",
							onClick: approveExport,
							children: copy.ok
						}) : null,
						job.status === "ready" || job.status === "ok" || job.status === "export" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "quiet",
							onClick: requestFix,
							children: copy.fix
						}) : null,
						job.status === "assembling" || job.status === "ready" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "danger",
							onClick: cancelBuild,
							children: copy.cancel
						}) : null,
						job.stage >= 4 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "quiet",
							onClick: runVisionCheck,
							children: copy.uiCheck
						}) : null
					]
				}),
				job.status === "ok" || job.status === "export" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportPanel, {
					job,
					hasToken,
					hasApps,
					assetHint: studio.skills.assets
				}) : null
			] }) : null
		]
	});
}
function latestNotice(notes, now) {
	const note = notes[0];
	if (!note || now - note.at > 8e3) return "";
	return note.text;
}
function ExportPanel({ job, hasToken, hasApps, assetHint }) {
	const studio = useStudio();
	const copy = t(studio.lang);
	const githubOn = studio.skills.github;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		className: "grid gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-lg font-semibold",
				children: copy.exportTitle
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: hasApps ? copy.injected : copy.missingApps
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-xs text-subtle",
				children: copy.fileList
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid gap-1 text-sm",
				children: EXPORT_FILES.filter((file) => assetHint || file !== "THIRD_PARTY.md").map((file) => {
					const stepDone = job.exportSteps.some((step) => step.id === "files" && (step.state === "done" || step.state === "run"));
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate",
							children: file
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-cyan",
							children: stepDone ? "ok" : "…"
						})]
					}, file);
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-xs text-subtle",
					children: copy.githubTitle
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid gap-2 text-sm",
					children: job.exportSteps.filter((step) => step.id !== "files").map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: step.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: step.state === "skip" ? "text-subtle" : "text-ok",
							children: step.state === "skip" ? githubOn ? hasToken ? "skip" : "need token" : "skill off" : step.state
						})]
					}, step.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-fg",
					children: hasToken && githubOn ? "Ready to upload this project to GitHub for a real APK." : "Download the zip, then upload this project to GitHub for a real APK."
				})
			] }),
			assetHint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-subtle",
				children: copy.assetHint
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "violet",
				onClick: () => downloadProject(job, studio.secrets.appsFb, assetHint && job.blueprint.skills.includes("assets")),
				children: copy.download
			})
		]
	});
}
function recognition() {
	const w = window;
	return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
}
function CopilotTab() {
	const studio = useStudio();
	const copy = t(studio.lang);
	const [text, setText] = (0, import_react.useState)("");
	const [listening, setListening] = (0, import_react.useState)(false);
	const [voiceLine, setVoiceLine] = (0, import_react.useState)("");
	const scroller = (0, import_react.useRef)(null);
	const recRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const node = scroller.current;
		if (node) node.scrollTop = node.scrollHeight;
	}, [studio.messages, studio.thinking]);
	(0, import_react.useEffect)(() => {
		return () => recRef.current?.stop();
	}, []);
	const send = (value) => {
		const next = value.trim();
		if (!next) return;
		setText("");
		askPilot(next);
	};
	const toggleMic = () => {
		setVoiceLine(listenRoute());
		if (listening) {
			recRef.current?.stop();
			setListening(false);
			return;
		}
		const Ctor = recognition();
		if (!Ctor) {
			askPilot(studio.lang === "hi" ? "इस ब्राउज़र में माइक नहीं मिला।" : "This browser has no speech recognition.");
			return;
		}
		const rec = new Ctor();
		rec.lang = studio.lang === "hi" ? "hi-IN" : "en-US";
		rec.interimResults = false;
		rec.onresult = (event) => {
			const said = event.results[0]?.[0]?.transcript ?? "";
			if (said) send(said);
		};
		rec.onend = () => setListening(false);
		rec.onerror = () => setListening(false);
		recRef.current = rec;
		rec.start();
		setListening(true);
	};
	const speak = (line) => {
		setVoiceLine(speakRoute());
		window.speechSynthesis?.cancel();
		const utter = new SpeechSynthesisUtterance(line);
		utter.lang = studio.lang === "hi" ? "hi-IN" : "en-US";
		window.speechSynthesis?.speak(utter);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				ref: scroller,
				className: "grid max-h-[28rem] gap-2 overflow-y-auto pr-1",
				children: [studio.messages.map((message) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: `rounded-lg px-3 py-3 text-sm ${message.role === "user" ? "ml-8 bg-surface-2" : "mr-6 glass"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "whitespace-pre-wrap",
						children: message.text
					}), message.role === "pilot" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "mt-2 inline-flex min-h-11 items-center gap-2 text-xs text-cyan",
						onClick: () => speak(message.text),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, {
							className: "size-4",
							"aria-hidden": "true"
						}), copy.speak]
					}) : null]
				}, message.id)), studio.thinking ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-cyan",
					children: studio.routingLine
				}) : null]
			}),
			voiceLine ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-subtle",
				children: voiceLine
			}) : null,
			listening ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-cyan",
				children: copy.listening
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "grid grid-cols-[auto_1fr_auto] gap-2",
				onSubmit: (event) => {
					event.preventDefault();
					send(text);
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: listening ? "violet" : "quiet",
						onClick: toggleMic,
						"aria-pressed": listening,
						children: [listening ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, {
							className: "size-4",
							"aria-hidden": "true"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, {
							className: "size-4",
							"aria-hidden": "true"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "sr-only",
							children: listening ? copy.stopMic : copy.mic
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
						value: text,
						onChange: (event) => setText(event.target.value),
						placeholder: copy.typePilot,
						"aria-label": copy.typePilot
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						variant: "primary",
						"aria-label": copy.send,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, {
							className: "size-4",
							"aria-hidden": "true"
						})
					})
				]
			})
		]
	});
}
var TAGS = [
	"",
	"General",
	"Code",
	"Fast",
	"Vision",
	"Primary",
	"Fallback"
];
function VaultTab() {
	const studio = useStudio();
	const copy = t(studio.lang);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: studio.syncNote === "synced" ? copy.syncOn : studio.syncNote === "error" ? copy.syncErr : copy.syncLocal
			}),
			studio.jobs.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm",
				children: copy.emptyVault
			}) : null,
			studio.jobs.map((job) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "glass rounded-lg p-4 text-left",
				onClick: () => selectJob(job.id),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block font-medium",
					children: job.blueprint.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "mt-1 flex flex-wrap gap-2 text-xs text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: job.blueprint.kind === "game" ? copy.kindGame : copy.kindApp }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: new Date(job.createdAt).toLocaleString() }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-cyan",
							children: statusLabel(job.status, studio.lang)
						})
					]
				})]
			}, job.id))
		]
	});
}
function AdminTab() {
	const studio = useStudio();
	const copy = t(studio.lang);
	const job = studio.jobs.find((item) => item.id === studio.activeJobId) ?? null;
	const admin = job ? studio.admins[job.id] : null;
	const [note, setNote] = (0, import_react.useState)("Your build is ready to test.");
	if (!job || !admin) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: copy.noJob
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: copy.adminNote
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-medium",
				children: job.blueprint.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "grid gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex min-h-11 items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: copy.banner }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: admin.banner,
							onChange: (event) => patchAdmin({ banner: event.target.checked }),
							className: "size-5"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
						value: admin.bannerText,
						onChange: (event) => patchAdmin({ bannerText: event.target.value }),
						"aria-label": copy.banner
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextArea, {
						rows: 3,
						value: admin.vipNote,
						"aria-label": copy.vip,
						onChange: (event) => patchAdmin({ vipNote: event.target.value })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
						value: admin.apkLink,
						placeholder: copy.apk,
						"aria-label": copy.apk,
						onChange: (event) => patchAdmin({ apkLink: event.target.value })
					}),
					admin.apkLink ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-xs text-cyan",
						children: admin.apkLink
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
						value: note,
						onChange: (event) => setNote(event.target.value),
						"aria-label": copy.sendNote
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "primary",
						onClick: () => sendNotification(note),
						children: copy.sendNote
					})
				]
			})
		]
	});
}
function SkillsTab() {
	const studio = useStudio();
	const copy = t(studio.lang);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: copy.skillsLead
		}), SKILL_ORDER.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "glass flex min-h-11 items-center justify-between gap-3 rounded-lg px-3 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block text-sm font-medium",
				children: skillLabel(id, studio.lang)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block text-xs text-subtle",
				children: id === "survivor" ? copy.survivorNote : skillBlurb(id, studio.lang)
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "checkbox",
				checked: studio.skills[id],
				onChange: (event) => setSkill(id, event.target.checked),
				className: "size-5 shrink-0"
			})]
		}, id))]
	});
}
function SecretsTab() {
	const studio = useStudio();
	const copy = t(studio.lang);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: copy.secretsHelp
			}),
			studio.secrets.keys.map((key, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecretRow, {
				label: `Key ${index + 1}`,
				value: key.value,
				tag: key.tag,
				onSave: (value, tag) => saveKey(index, value, tag),
				onDelete: () => clearKey(index)
			}, key.id)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TokenRow, {
				label: copy.token1,
				value: studio.secrets.tokens[0],
				onSave: (value) => saveToken(0, value),
				onDelete: () => saveToken(0, "")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TokenRow, {
				label: copy.token2,
				value: studio.secrets.tokens[1],
				onSave: (value) => saveToken(1, value),
				onDelete: () => saveToken(1, "")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TokenRow, {
				label: copy.voice,
				value: studio.secrets.voice,
				onSave: saveVoice,
				onDelete: () => saveVoice("")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FirebaseEditor, {
				which: "studioFb",
				label: copy.studioFb,
				slot: studio.secrets.studioFb
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FirebaseEditor, {
				which: "appsFb",
				label: copy.appsFb,
				slot: studio.secrets.appsFb
			})
		]
	});
}
function mask(value) {
	if (!value) return "";
	if (value.length <= 4) return "••••";
	return `•••• ${value.slice(-4)}`;
}
function SecretRow({ label, value, tag, onSave, onDelete }) {
	const copy = t(useStudio().lang);
	const [editing, setEditing] = (0, import_react.useState)(!value);
	const [draft, setDraft] = (0, import_react.useState)(value);
	const [draftTag, setDraftTag] = (0, import_react.useState)(tag);
	const provider = detectProvider(value);
	if (!editing && value) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		className: "grid gap-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-medium",
					children: label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm tabular-nums text-muted",
					children: mask(value)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-subtle",
				children: [tag || copy.none, provider ? ` · ${copy.detected} ${provider}` : ` · ${copy.unrecognized}`]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					onClick: () => {
						setDraft(value);
						setDraftTag(tag);
						setEditing(true);
					},
					children: copy.edit
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "danger",
					onClick: onDelete,
					children: copy.del
				})]
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		className: "grid gap-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-medium",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
				value: draft,
				onChange: (event) => setDraft(event.target.value),
				autoComplete: "off",
				spellCheck: false,
				"aria-label": label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectField, {
				value: draftTag,
				"aria-label": copy.keyTag,
				onChange: (event) => setDraftTag(event.target.value),
				children: TAGS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: item,
					children: item || copy.keyTag
				}, item || "none"))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "primary",
				onClick: () => {
					onSave(draft, draftTag);
					setEditing(false);
				},
				children: copy.save
			})
		]
	});
}
function TokenRow({ label, value, onSave, onDelete }) {
	const copy = t(useStudio().lang);
	const [editing, setEditing] = (0, import_react.useState)(!value);
	const [draft, setDraft] = (0, import_react.useState)(value);
	if (!editing && value) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		className: "grid gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-medium",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: mask(value)
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-2 gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				onClick: () => {
					setDraft(value);
					setEditing(true);
				},
				children: copy.edit
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "danger",
				onClick: onDelete,
				children: copy.del
			})]
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		className: "grid gap-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-medium",
				children: label
			}),
			!value ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-subtle",
				children: copy.emptySlot
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
				value: draft,
				onChange: (event) => setDraft(event.target.value),
				autoComplete: "off",
				spellCheck: false,
				"aria-label": label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "primary",
				onClick: () => {
					onSave(draft);
					setEditing(Boolean(draft.trim()) === false);
				},
				children: copy.save
			})
		]
	});
}
function FirebaseEditor({ which, label, slot }) {
	const copy = t(useStudio().lang);
	const [editing, setEditing] = (0, import_react.useState)(!slot.url && !slot.key);
	const [url, setUrl] = (0, import_react.useState)(slot.url);
	const [key, setKey] = (0, import_react.useState)(slot.key);
	const [json, setJson] = (0, import_react.useState)("");
	const saved = Boolean(slot.url || slot.key);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		className: "grid gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-medium",
			children: label
		}), !editing && saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "truncate text-xs text-muted",
				children: slot.url
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-subtle",
				children: mask(slot.key)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					onClick: () => {
						setUrl(slot.url);
						setKey(slot.key);
						setEditing(true);
					},
					children: copy.edit
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "danger",
					onClick: () => clearFirebase(which),
					children: copy.del
				})]
			})
		] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
				value: url,
				onChange: (event) => setUrl(event.target.value),
				placeholder: copy.url,
				"aria-label": copy.url
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
				value: key,
				onChange: (event) => setKey(event.target.value),
				placeholder: copy.fbKey,
				"aria-label": copy.fbKey,
				autoComplete: "off"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextArea, {
				rows: 3,
				value: json,
				placeholder: copy.pasteJson,
				"aria-label": copy.pasteJson,
				onChange: (event) => setJson(event.target.value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				onClick: () => {
					const parsed = parseFirebaseConfig(json);
					if (!parsed) return;
					if (parsed.url) setUrl(parsed.url);
					if (parsed.key) setKey(parsed.key);
				},
				children: copy.applyJson
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "primary",
				onClick: () => {
					saveFirebase(which, url, key);
					setEditing(!(url.trim() || key.trim()));
				},
				children: copy.save
			})
		] })]
	});
}
var TABS = [
	{
		id: "pilot",
		icon: MessageCircle
	},
	{
		id: "build",
		icon: Blocks
	},
	{
		id: "vault",
		icon: Archive
	},
	{
		id: "admin",
		icon: Shield
	},
	{
		id: "skills",
		icon: SlidersHorizontal
	},
	{
		id: "secrets",
		icon: KeyRound
	}
];
function StudioApp() {
	const studio = useStudio();
	const copy = t(studio.lang);
	(0, import_react.useEffect)(() => {
		hydrate();
		const timer = setInterval(() => tick(), 400);
		const onFocus = () => tick();
		window.addEventListener("focus", onFocus);
		return () => {
			clearInterval(timer);
			window.removeEventListener("focus", onFocus);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		ensureExportClock();
	}, [studio.activeJobId, studio.jobs]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "safe-pad mx-auto flex min-h-dvh w-full max-w-lg flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "px-4 pt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl font-semibold tracking-tight text-fg",
						children: copy.wordmark
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-cyan",
						children: copy.product
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex rounded-md border border-line p-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: `min-h-11 rounded-sm px-3 text-sm ${studio.lang === "en" ? "bg-cyan text-ink" : "text-muted"}`,
							onClick: () => setLang("en"),
							children: copy.langEn
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: `min-h-11 rounded-sm px-3 text-sm ${studio.lang === "hi" ? "bg-violet text-ink" : "text-muted"}`,
							onClick: () => setLang("hi"),
							children: copy.langHi
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: copy.tagline
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				"aria-label": "Studio",
				className: "mt-3 flex gap-2 overflow-x-auto px-4 pb-2",
				children: TABS.map((tab) => {
					const Icon = tab.icon;
					const on = studio.tab === tab.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						"aria-current": on ? "page" : void 0,
						className: `inline-flex min-h-11 shrink-0 items-center gap-2 rounded-full px-3 text-sm ${on ? "bg-cyan text-ink" : "glass text-fg"}`,
						onClick: () => setTab(tab.id),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							className: "size-4",
							"aria-hidden": "true"
						}), copy.tabs[tab.id]]
					}, tab.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "flex-1 px-4 pb-8",
				children: [
					studio.tab === "pilot" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopilotTab, {}) : null,
					studio.tab === "build" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuildTab, {}) : null,
					studio.tab === "vault" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VaultTab, {}) : null,
					studio.tab === "admin" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminTab, {}) : null,
					studio.tab === "skills" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkillsTab, {}) : null,
					studio.tab === "secrets" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecretsTab, {}) : null
				]
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioApp, {});
}
//#endregion
export { Home as component };
